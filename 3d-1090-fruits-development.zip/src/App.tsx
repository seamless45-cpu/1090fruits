import { useEffect, useRef, useState } from 'react';
import { Game } from './game/Game';
import HUD from './ui/HUD';
import { DEFAULT_SETTINGS, type GraphicsSettings } from './game/types';

function loadSettings(): Partial<GraphicsSettings> {
  try { const s = localStorage.getItem('fruits1090.gfx'); return s ? { ...DEFAULT_SETTINGS, ...JSON.parse(s) } : {}; } catch { return {}; }
}

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [intro, setIntro] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!host.current) return;
    let g: Game | null = null;
    try { g = new Game(host.current, loadSettings()); setGame(g); (window as any).__game = g; }
    catch (e) { setErr(String(e)); }
    return () => { g?.dispose(); };
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#02040a]" style={{ cursor: 'crosshair' }}>
      <div ref={host} className="absolute inset-0" />
      {game && <HUD g={game} />}
      {err && <div className="absolute inset-0 flex items-center justify-center"><div className="sf-panel p-6 text-red-300 font-orb text-sm">WEBGL INIT FAILURE: {err}</div></div>}
      {intro && game && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-[radial-gradient(ellipse_at_center,rgba(4,20,36,.75),rgba(0,0,0,.92))]" onPointerDown={() => setIntro(false)}>
          <div className="sf-panel px-8 py-7 max-w-[92vw] w-[560px] text-center hex-grid-bg">
            <div className="font-orb text-[10px] tracking-[0.6em] text-cyan-300/70">COMBAT SIMULATION</div>
            <div className="font-orb text-4xl sm:text-5xl font-black mt-2 tracking-[0.12em] text-transparent bg-clip-text bg-gradient-to-b from-white to-cyan-300 sf-glow">1090 FRUITS</div>
            <div className="font-orb text-[11px] tracking-[0.4em] text-cyan-200/80 mt-1">3D ARENA</div>
            <div className="mt-5 grid grid-cols-2 gap-2 text-left text-[12px] text-cyan-50/80">
              <div><span className="font-orb text-[10px] text-cyan-300">7 FRUITS</span><br />Gravity · Lightning · Quake · Alarm · Rimefracture · Wildfire · Cloud</div>
              <div><span className="font-orb text-[10px] text-cyan-300">4 SWORDS</span><br />Gravity Blade · Pole · Bisento · Alarm Sword</div>
            </div>
            <div className="mt-4 text-[11px] text-cyan-100/60 leading-relaxed">Equip from the bottom slots (1–9, 0, -). Skills: Z X C V B F G N M L K J. Aim with the mouse. Right-drag to orbit, wheel to zoom up to 300 m.</div>
            <button className="sf-btn mt-5 px-8 py-2 text-sm sf-pulse" onClick={() => setIntro(false)}>ENGAGE</button>
          </div>
        </div>
      )}
    </div>
  );
}
