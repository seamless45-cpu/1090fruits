import * as THREE from 'three';
import type { Game } from './Game';
import type { Enemy } from './Enemies';
import { GEO, TEX, glowMat, fresnelMat, rand, setOpacity, sharedMat } from './Effects';

export const B = 1000; // base damage unit
export const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const rockMat = sharedMat(new THREE.MeshStandardMaterial({ color: 0x3b302a, roughness: 0.9, flatShading: true, emissive: 0x551800, emissiveIntensity: 0.6 }));

export function randAround(p: THREE.Vector3, r: number) { const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * r; return V(p.x + Math.cos(a) * d, 0, p.z + Math.sin(a) * d); }
export function aliveTargets(g: Game, p: THREE.Vector3, r: number) { return g.enemies.inRadius(p, r, []); }
/** pick distinct random enemies; re-allow survivors once pool exhausted */
export function distinctPicker(g: Game, center: () => THREE.Vector3, r: number) {
  const used = new Set<Enemy>();
  return () => {
    let pool = g.enemies.inRadius(center(), r, []).filter((e) => !used.has(e));
    if (!pool.length) { used.forEach((e) => { if (!e.alive) used.delete(e); }); pool = g.enemies.inRadius(center(), r, []).filter((e) => e.alive); used.clear(); }
    if (!pool.length) return null;
    const e = pool[Math.floor(Math.random() * pool.length)]; used.add(e); return e;
  };
}

/** giant falling asteroid with fiery trail */
export function asteroid(g: Game, target: THREE.Vector3, o: { size?: number; radius: number; dmg: number; onLand?: (p: THREE.Vector3) => void; color?: number; time?: number; shake?: number }) {
  const size = o.size ?? 7; const t = o.time ?? 1.1;
  const start = V(target.x + rand(-60, 60), 220, target.z + rand(-60, 60));
  const m = new THREE.Mesh(GEO.ico, rockMat); m.scale.setScalar(size); m.castShadow = true;
  const aura = new THREE.Mesh(GEO.sphere, fresnelMat(o.color ?? 0xff6a1a, 1, 1.5)); aura.scale.setScalar(1.35); m.add(aura);
  const vel = target.clone().sub(start).divideScalar(t);
  const col = new THREE.Color(o.color ?? 0xff7a2a), smokeC = new THREE.Color(0x2a2422);
  g.projectile({
    obj: m, pos: start, vel, life: t + 1, radius: size, noEnemyHit: true,
    onTick: (p, dt) => {
      m.rotation.x += dt * 2; m.rotation.y += dt * 1.3;
      for (let i = 0; i < g.fx.sparks.n(8); i++) g.fx.sparks.emit(p.x + rand(-size, size) * 0.6, p.y + rand(-size, size) * 0.6, p.z + rand(-size, size) * 0.6, -vel.x * 0.15 + rand(-4, 4), -vel.y * 0.15 + rand(-4, 4), -vel.z * 0.15 + rand(-4, 4), col, rand(0.4, 0.9), rand(1.5, 3.5));
      for (let i = 0; i < g.fx.smoke.n(2); i++) g.fx.smoke.emit(p.x, p.y, p.z, rand(-2, 2), rand(-1, 2), rand(-2, 2), smokeC, rand(1.5, 3), size * rand(0.8, 1.4), 0, 0.5, 0.5, 1.5);
    },
    onHit: (p) => {
      const r = g.aoe(o.radius);
      g.fx.explosion(p, r, { core: 0xffe08a, edge: o.color ?? 0xff5a14, debris: 70, debrisColor: 0x4a382c, shards: 30, shardColor: 0xff8a2a, shake: o.shake ?? 16 });
      g.dmgArea(p, r, o.dmg, { knock: 16, up: 10 });
      o.onLand?.(p);
    },
  });
}

/** burning pit decal that ticks % max HP damage */
export function firePit(g: Game, p: THREE.Vector3, r: number, dur: number, pct: number, o: { color?: number; tick?: number; tex?: THREE.Texture; onTickHit?: (e: Enemy) => void; flame?: number } = {}) {
  const m = new THREE.Mesh(GEO.disc, glowMat(o.color ?? 0xff6a1a, 0.9, o.tex ?? TEX.lava)); m.position.set(p.x, 0.06 + Math.random() * 0.03, p.z); m.scale.setScalar(r); m.rotation.y = Math.random() * 6;
  g.scene.add(m); const tick = o.tick ?? 0.25; let acc = 0; const fc = new THREE.Color(o.flame ?? 0xff8a2a);
  const lim = g.fx.sparks.n(Math.min(10, 2 + r * 0.2));
  g.task((dt, t) => {
    const k = t < 0.2 ? t / 0.2 : Math.min(1, (dur - t) / 0.8);
    setOpacity(m.material as THREE.Material, 0.9 * k * (0.85 + Math.sin(t * 9) * 0.15)); m.rotation.y += dt * 0.1;
    for (let i = 0; i < lim; i++) { const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * r; g.fx.sparks.emit(p.x + Math.cos(a) * d, 0.3, p.z + Math.sin(a) * d, 0, rand(3, 9), 0, fc, rand(0.4, 1), rand(0.6, 1.8), -2); }
    acc += dt;
    if (acc >= tick) { acc = 0; for (const e of g.enemies.inRadius(p, r, [])) { if (e.pos.y > 4) continue; g.dmg(e, e.maxHp * pct, { color: '#ff9a3a', small: true }); o.onTickHit?.(e); } }
    if (t >= dur) { g.scene.remove(m); (m.material as THREE.Material).dispose(); return false; }
  });
}

/** curved crescent slash flash */
export function slashFx(g: Game, p: THREE.Vector3, dir: THREE.Vector3, size: number, color: THREE.ColorRepresentation, o: { tilt?: number; life?: number; move?: number } = {}) {
  const m = new THREE.Mesh(GEO.crescent, new THREE.MeshBasicMaterial({ color, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
  m.position.copy(p); m.scale.setScalar(size);
  m.lookAt(p.clone().add(dir)); m.rotateY(-Math.PI / 2); m.rotateX(o.tilt ?? rand(-0.9, 0.9));
  const life = o.life ?? 0.22; const mv = dir.clone().multiplyScalar(o.move ?? 0);
  g.fx.add(m, life, (obj, k, dt) => { obj.scale.setScalar(size * (1 + (1 - k) * 0.35)); obj.rotateY(dt * 9); obj.position.addScaledVector(mv, dt); setOpacity((obj as THREE.Mesh).material as THREE.Material, k * 1.4); });
  return m;
}

/** straight laser beam (cylinder) */
export function laser(g: Game, from: THREE.Vector3, to: THREE.Vector3, color: number, width = 0.4, life = 0.35) {
  const len = from.distanceTo(to); const mid = from.clone().add(to).multiplyScalar(0.5);
  const grp = new THREE.Group(); grp.position.copy(mid); grp.lookAt(to);
  const core = new THREE.Mesh(GEO.cylSolid, glowMat(0xffffff, 1)); core.rotation.x = Math.PI / 2; core.scale.set(width * 0.35, len, width * 0.35);
  const glow = new THREE.Mesh(GEO.cylSolid, glowMat(color, 0.6)); glow.rotation.x = Math.PI / 2; glow.scale.set(width, len, width);
  grp.add(core, glow);
  g.fx.add(grp, life, (_o, k) => { const w = 0.3 + k * 0.7; core.scale.x = core.scale.z = width * 0.35 * w; glow.scale.x = glow.scale.z = width * w * (0.8 + Math.random() * 0.4); setOpacity(core.material as THREE.Material, k); setOpacity(glow.material as THREE.Material, 0.6 * k); });
  g.fx.disc(to, width * 4, color, life, { op: 0.8 });
}

/** tall vertical beam column */
export function pillarBeam(g: Game, p: THREE.Vector3, color: number, h: number, w: number, life: number) {
  const grp = new THREE.Group(); grp.position.set(p.x, h / 2, p.z);
  const c = new THREE.Mesh(GEO.cylSolid, glowMat(0xffffff, 1)); c.scale.set(w * 0.3, h, w * 0.3);
  const o = new THREE.Mesh(GEO.cyl, fresnelMat(color, 1, 1.2, 0.2)); o.scale.set(w, h, w);
  grp.add(c, o);
  g.fx.add(grp, life, (_o, k) => { const s = k < 0.85 ? 1 : (1 - k) / 0.15; c.scale.x = c.scale.z = w * 0.3 * (k); o.scale.x = o.scale.z = w * (1.3 - k * 0.3) * s + 0.01; setOpacity(c.material as THREE.Material, k); setOpacity(o.material as THREE.Material, k); });
  g.fx.ring(p, w, w * 4, color, life * 0.8);
}

/** neon blue quake cracks: lightning re-used flat on ground */
export function quakeCracks(g: Game, p: THREE.Vector3, r: number, n: number, color = 0x2ec8ff, life = 1.4, y = 0.12) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + rand(-0.2, 0.2); const len = r * rand(0.55, 1);
    const from = V(p.x, y, p.z); const to = V(p.x + Math.cos(a) * len, y, p.z + Math.sin(a) * len);
    g.fx.bolt(from, to, { color, core: 0xd8f6ff, width: Math.max(0.35, r * 0.03), life: life * rand(0.8, 1.2), flat: true, branches: 3, jag: len * 0.06 });
  }
}
/** cracks in the air around a point (vertical-ish, short) */
export function airCracks(g: Game, p: THREE.Vector3, r: number, n: number, color = 0x2ec8ff, life = 0.5) {
  for (let i = 0; i < n; i++) {
    const d = V(rand(-1, 1), rand(-1, 1), rand(-1, 1)).normalize().multiplyScalar(r * rand(0.5, 1));
    g.fx.bolt(p.clone(), p.clone().add(d), { color, core: 0xe8faff, width: 0.18, life: life * rand(0.7, 1.2), branches: 2, segs: 8 });
  }
}

/** a tsunami wall travelling along dir, can hit enemies multiple times */
export function tsunami(g: Game, start: THREE.Vector3, dir: THREE.Vector3, o: { width: number; height: number; speed: number; dist: number; dmg: number; color?: number; knock?: number; hitEvery?: number }) {
  const grp = new THREE.Group(); grp.position.copy(start); grp.lookAt(start.clone().add(dir));
  const mat = new THREE.MeshStandardMaterial({ color: o.color ?? 0x1d6fa8, transparent: true, opacity: 0.82, roughness: 0.15, metalness: 0.3, emissive: 0x0a3050, side: THREE.DoubleSide });
  const w = new THREE.Mesh(GEO.wave, mat); w.scale.set(o.width, o.height, o.height); w.rotation.y = Math.PI; grp.add(w);
  const foamM = new THREE.Mesh(GEO.wave, new THREE.MeshBasicMaterial({ color: 0xdff6ff, transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthWrite: false }));
  foamM.scale.set(o.width * 1.01, o.height * 1.03, o.height * 1.05); foamM.rotation.y = Math.PI; grp.add(foamM);
  g.scene.add(grp);
  const foam = new THREE.Color(0xe6f8ff); const hitT = new Map<Enemy, number>(); const every = o.hitEvery ?? 0.35;
  const right = V(dir.z, 0, -dir.x); const dur = o.dist / o.speed;
  g.task((dt, t) => {
    grp.position.addScaledVector(dir, o.speed * dt);
    const k = Math.min(1, t / 0.3, (dur - t) / 0.5); grp.scale.set(1, Math.max(0.01, k), 1); mat.opacity = 0.82 * Math.max(0, k);
    for (let i = 0; i < g.fx.smoke.n(Math.min(12, o.width / 4)); i++) { const s = rand(-0.5, 0.5) * o.width; const q = grp.position.clone().addScaledVector(right, s); g.fx.smoke.emit(q.x, o.height * k * rand(0.6, 1.05), q.z, dir.x * o.speed * 0.6 + rand(-2, 2), rand(1, 5), dir.z * o.speed * 0.6 + rand(-2, 2), foam, rand(0.5, 1.2), rand(1, 3) * (o.height / 8), 12, 0.6, 0.7, 1); }
    for (const e of g.enemies.list) {
      if (!e.alive) continue; const rel = e.pos.clone().sub(grp.position); const along = rel.dot(dir), side = rel.dot(right);
      if (Math.abs(along) < Math.max(3, o.height * 0.4) && Math.abs(side) < o.width / 2) {
        const last = hitT.get(e) ?? -9; if (t - last >= every) { hitT.set(e, t); g.dmg(e, o.dmg); e.knock(dir, o.knock ?? 14, 4); }
      }
    }
    if (t >= dur) { g.scene.remove(grp); mat.dispose(); (foamM.material as THREE.Material).dispose(); return false; }
  });
}

/** small fast meteor */
export function smallMeteor(g: Game, target: THREE.Vector3, o: { speed: number; radius: number; dmg: number; color?: number; size?: number; shake?: number; debris?: number }) {
  const start = V(target.x + rand(-25, 25), rand(140, 180), target.z + rand(-25, 25));
  const dir = target.clone().sub(start).normalize();
  const m = new THREE.Mesh(GEO.rock, rockMat); m.scale.setScalar(o.size ?? 1.6);
  const tr = new THREE.Mesh(GEO.sphereLo, glowMat(o.color ?? 0xff8a3a, 0.8)); tr.scale.setScalar(1.6); m.add(tr);
  const c = new THREE.Color(o.color ?? 0xff8a3a);
  g.projectile({
    obj: m, pos: start, vel: dir.multiplyScalar(o.speed), life: 4, radius: 1, noEnemyHit: true,
    onTick: (p) => { for (let i = 0; i < g.fx.sparks.n(3); i++) g.fx.sparks.emit(p.x, p.y, p.z, rand(-2, 2), rand(2, 6), rand(-2, 2), c, rand(0.2, 0.5), rand(1, 2)); },
    onHit: (p) => { const r = g.aoe(o.radius); g.fx.explosion(p, r, { core: 0xffe7a0, edge: o.color ?? 0xff6a1a, debris: o.debris ?? 12, shake: o.shake ?? 5, sparks: 30 }); g.dmgArea(p, r, o.dmg, { knock: 8, up: 5 }); },
  });
}

/** player-anchored pulsing aura ring stack */
export function auraRings(g: Game, color: number, until: () => boolean, scale = 1.6) {
  const grp = new THREE.Group();
  for (let i = 0; i < 3; i++) { const r = new THREE.Mesh(GEO.torus, glowMat(color, 0.7)); r.scale.setScalar(scale * (1 + i * 0.3)); r.position.y = 0.4 + i * 0.9; grp.add(r); }
  const sh = new THREE.Mesh(GEO.sphere, fresnelMat(color, 0.6, 2.5)); sh.scale.set(1.6 * scale * 0.8, 2.2 * scale * 0.8, 1.6 * scale * 0.8); sh.position.y = 1.4; grp.add(sh);
  g.addAura(grp, until, (o, dt) => { o.children.forEach((c, i) => { if (i < 3) { c.rotation.z += dt * (1 + i); c.rotation.x = Math.sin(g.time * 2 + i) * 0.3; c.position.y = 0.4 + i * 0.9 + Math.sin(g.time * 3 + i) * 0.2; } }); });
}
