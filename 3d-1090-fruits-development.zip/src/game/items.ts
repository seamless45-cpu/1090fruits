import type { ItemDef } from './types';
import { gravityFruit, gravityBlade } from './items/gravity';
import { lightningFruit, pole } from './items/lightning';
import { quakeFruit, bisento } from './items/quake';
import { alarmFruit, alarmSword } from './items/alarm';
import { rimeFruit, wildfireFruit } from './items/guns';
import { cloudFruit } from './items/cloud';

/** Fruits and swords are separate items — each equips/unequips on its own inventory slot. */
export const ITEMS: ItemDef[] = [
  gravityFruit, lightningFruit, quakeFruit, alarmFruit, rimeFruit, wildfireFruit, cloudFruit,
  gravityBlade, pole, bisento, alarmSword,
];
