import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { FX, rand } from './Effects';
import { Enemy, EnemyManager } from './Enemies';
import type { GraphicsSettings, ItemDef, SkillState } from './types';
import { DEFAULT_SETTINGS, SKILL_KEYS } from './types';
import { ITEMS } from './items';

export interface DmgOpts { crit?: boolean; color?: string; raw?: boolean; small?: boolean; noProc?: boolean; big?: boolean }
export interface AreaOpts extends DmgOpts { knock?: number; up?: number; stun?: number; freeze?: number; burn?: [number, number]; lift?: [number, number]; from?: THREE.Vector3; filter?: (e: Enemy) => boolean }
interface Task { fn: (dt: number, t: number) => boolean | void; t: number }
interface ShakeSrc { p: THREE.Vector3; i: number; d: number; t: number; global?: boolean }
export interface ProjOpts { obj: THREE.Object3D; pos: THREE.Vector3; vel: THREE.Vector3; life: number; radius: number; pierce?: boolean; gravity?: number; homing?: Enemy | null; homingRate?: number; hitGround?: boolean; noEnemyHit?: boolean; onHit?: (p: THREE.Vector3, e: Enemy | null) => void; onTick?: (p: THREE.Vector3, dt: number, t: number) => void; onEnd?: (p: THREE.Vector3) => void; faceVel?: boolean }

const MAX_ZOOM = 300, MIN_ZOOM = 4;
const _v = new THREE.Vector3(), _v2 = new THREE.Vector3();

export class Game {
  container: HTMLElement; renderer: THREE.WebGLRenderer; scene = new THREE.Scene(); camera: THREE.PerspectiveCamera;
  composer: EffectComposer; bloom: UnrealBloomPass; sun: THREE.DirectionalLight; fx: FX; enemies: EnemyManager;
  settings: GraphicsSettings; time = 0; worldPause = 0; raf = 0; disposed = false; clock = new THREE.Clock();
  // camera
  yaw = Math.PI; pitch = 0.32; zoom = 22; zoomTarget = 22; camTarget = new THREE.Vector3(); shakes: ShakeSrc[] = []; shakeOffset = new THREE.Vector3();
  // player
  player = { pos: new THREE.Vector3(0, 0, 20), vel: new THREE.Vector3(), yaw: 0, hp: 1000, maxHp: 1000, invT: 0, ground: true, deadT: 0 };
  playerObj = new THREE.Group(); parts: Record<string, THREE.Object3D> = {}; handSlot = new THREE.Group(); anim = { kind: '', t: 0, d: 0 }; walkT = 0; glowT = 0;
  // input
  keys = new Set<string>(); mouse = new THREE.Vector2(); mouseIn = false; aim = new THREE.Vector3(); raycaster = new THREE.Raycaster(); ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  joy = { x: 0, y: 0 }; touchMode = false; m1Held = false; m1Queued = false; dragging = false; lastPtr = { x: 0, y: 0 }; pinch = 0; touches = new Map<number, { x: number; y: number }>();
  gpPrev: boolean[] = []; gpSkillSel = 0;
  // items
  items: ItemDef[] = ITEMS; equipped = -1; skillStates: Record<string, SkillState[]> = {}; m1Next = 0; combo = 0; lastM1 = 0;
  buffs = { alarm: 0, ice: 0, fire: 0 }; bladeCharge = 50; supercellType = 1; kills = 0; totalDmg = 0; spawning = true;
  tasks: Task[] = []; floods: { p: THREE.Vector3; r: number; level: number }[] = []; clouds = 0;
  // ui
  numLayer: HTMLDivElement; nums: { el: HTMLDivElement; p: THREE.Vector3; t: number; life: number; active: boolean }[] = []; numCur = 0;
  overlay: HTMLDivElement; overlayState = { r: 0, g: 0, b: 0, a: 0, decay: 1 }; redTint = 0;
  fps = 60; fpsAcc = 0; fpsN = 0; onUi?: (ev: string) => void;
  auras: THREE.Object3D[] = [];

  constructor(container: HTMLElement, settings?: Partial<GraphicsSettings>) {
    this.container = container; this.settings = { ...DEFAULT_SETTINGS, ...settings };
    this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none;';
    this.camera = new THREE.PerspectiveCamera(this.settings.fov, 1, 0.1, 60000);
    const rt = new THREE.WebGLRenderTarget(2, 2, { type: THREE.HalfFloatType, samples: 4 });
    this.composer = new EffectComposer(this.renderer, rt);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(512, 512), 0.9, 0.55, 0.82);
    this.composer.addPass(this.bloom); this.composer.addPass(new OutputPass());
    this.sun = new THREE.DirectionalLight(0xbfdcff, 2.2);
    this.fx = new FX(this.scene, this.camera);
    this.fx.onShake = (p, i, d) => this.shake(p, i, d);
    this.enemies = new EnemyManager(this);
    this.numLayer = document.createElement('div'); this.numLayer.style.cssText = 'position:absolute;inset:0;pointer-events:none;overflow:hidden;';
    container.appendChild(this.numLayer);
    for (let i = 0; i < 70; i++) { const el = document.createElement('div'); el.className = 'dmg-num'; el.style.opacity = '0'; this.numLayer.appendChild(el); this.nums.push({ el, p: new THREE.Vector3(), t: 0, life: 1, active: false }); }
    this.overlay = document.createElement('div'); this.overlay.style.cssText = 'position:absolute;inset:0;pointer-events:none;opacity:0;';
    container.appendChild(this.overlay);
    for (const it of this.items) this.skillStates[it.id] = it.skills.map((s) => ({ cdEnd: 0, cdTotal: 1, holding: false, charges: s.charges?.max ?? 0, chargeTimer: 0, data: {} }));
    this.buildWorld(); this.buildPlayer(); this.bindInput(); this.applySettings(this.settings); this.resize();
    window.addEventListener('resize', this.resize);
    this.touchMode = this.settings.touchControls === 'on' || (this.settings.touchControls === 'auto' && matchMedia('(pointer: coarse)').matches);
    for (let i = 0; i < 18; i++) this.enemies.spawn(Math.random() < 0.1 ? 'elite' : 'normal');
    this.loop();
  }

  /* ---------------------------------------------------------------- world */
  buildWorld() {
    const s = this.scene;
    s.background = new THREE.Color(0x03060d);
    const sky = new THREE.Mesh(new THREE.SphereGeometry(50000, 32, 16), new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: {}, vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }',
      fragmentShader: `varying vec3 vP; void main(){ float h = vP.y; vec3 top = vec3(0.01,0.02,0.06); vec3 hor = vec3(0.05,0.16,0.26); vec3 bot = vec3(0.01,0.02,0.04);
        vec3 c = h>0. ? mix(hor, top, pow(h,0.45)) : mix(hor, bot, pow(-h,0.3)); c += vec3(0.0,0.25,0.35)*exp(-abs(h)*18.)*0.5; gl_FragColor = vec4(c,1.); }`,
    }));
    sky.renderOrder = -10; s.add(sky);
    // stars
    const sg = new THREE.BufferGeometry(); const sp: number[] = [];
    for (let i = 0; i < 2500; i++) { const a = Math.random() * 6.28, e = Math.random() * 1.4 + 0.08; sp.push(Math.cos(a) * Math.cos(e) * 40000, Math.sin(e) * 40000, Math.sin(a) * Math.cos(e) * 40000); }
    sg.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3));
    s.add(new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xbfe8ff, size: 2, sizeAttenuation: false, fog: false })));
    s.add(new THREE.HemisphereLight(0x6fa8ff, 0x0a0f18, 0.9));
    s.add(new THREE.AmbientLight(0x223344, 0.6));
    this.sun.position.set(80, 140, 40); this.sun.castShadow = true;
    const sc = this.sun.shadow.camera; sc.left = -90; sc.right = 90; sc.top = 90; sc.bottom = -90; sc.near = 1; sc.far = 400;
    this.sun.shadow.bias = -0.0005; s.add(this.sun); s.add(this.sun.target);
    // ground grid texture
    const cv = document.createElement('canvas'); cv.width = cv.height = 512; const c = cv.getContext('2d')!;
    c.fillStyle = '#0a121c'; c.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 400; i++) { c.fillStyle = `rgba(${20 + Math.random() * 20},${30 + Math.random() * 25},${45 + Math.random() * 25},0.5)`; const x = Math.random() * 512, y = Math.random() * 512; c.fillRect(x, y, Math.random() * 60, Math.random() * 60); }
    c.strokeStyle = 'rgba(80,200,255,0.55)'; c.lineWidth = 3; c.strokeRect(0, 0, 512, 512);
    c.strokeStyle = 'rgba(80,200,255,0.18)'; c.lineWidth = 1; for (let i = 64; i < 512; i += 64) { c.beginPath(); c.moveTo(i, 0); c.lineTo(i, 512); c.moveTo(0, i); c.lineTo(512, i); c.stroke(); }
    const tex = new THREE.CanvasTexture(cv); tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(600, 600); tex.anisotropy = 8; tex.colorSpace = THREE.SRGBColorSpace;
    const emi = new THREE.CanvasTexture((() => { const e = document.createElement('canvas'); e.width = e.height = 512; const x = e.getContext('2d')!; x.fillStyle = '#000'; x.fillRect(0, 0, 512, 512); x.strokeStyle = '#1b8fc4'; x.lineWidth = 3; x.strokeRect(0, 0, 512, 512); return e; })());
    emi.wrapS = emi.wrapT = THREE.RepeatWrapping; emi.repeat.set(600, 600);
    const g = new THREE.Mesh(new THREE.PlaneGeometry(24000, 24000), new THREE.MeshStandardMaterial({ map: tex, emissiveMap: emi, emissive: 0x2aa8ff, emissiveIntensity: 0.6, roughness: 0.55, metalness: 0.5 }));
    g.rotation.x = -Math.PI / 2; g.receiveShadow = true; s.add(g);
    // arena rings
    for (const [r, col] of [[60, 0x2ee6ff], [200, 0x1b6fff], [480, 0x8a3dff]] as [number, number][]) {
      const m = new THREE.Mesh(new THREE.RingGeometry(r - 0.5, r, 128).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: col, toneMapped: false, transparent: true, opacity: 0.8 }));
      m.position.y = 0.03; s.add(m);
    }
    const core = new THREE.Mesh(new THREE.CylinderGeometry(8, 9, 0.6, 6), new THREE.MeshStandardMaterial({ color: 0x0d1a26, metalness: 0.9, roughness: 0.3, emissive: 0x0a3a55 }));
    core.position.y = 0.3; core.receiveShadow = true; s.add(core);
    // pylons
    const pyGeo = new THREE.BoxGeometry(4, 70, 4); const pyMat = new THREE.MeshStandardMaterial({ color: 0x0c1520, metalness: 0.8, roughness: 0.35 });
    const stripGeo = new THREE.BoxGeometry(0.5, 60, 4.2); const stripMat = new THREE.MeshBasicMaterial({ color: 0x33e0ff, toneMapped: false });
    for (let i = 0; i < 28; i++) {
      const a = (i / 28) * Math.PI * 2; const p = new THREE.Mesh(pyGeo, pyMat); p.position.set(Math.cos(a) * 480, 35, Math.sin(a) * 480); p.rotation.y = -a; p.castShadow = true; s.add(p);
      const st = new THREE.Mesh(stripGeo, stripMat); st.position.copy(p.position); st.rotation.y = -a; s.add(st);
    }
    // distant megastructures (instanced)
    const n = 160; const bm = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: 0x0a1320, metalness: 0.6, roughness: 0.5, emissive: 0x06243a }), n);
    const m4 = new THREE.Matrix4();
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, r = rand(1600, 5000); const w = rand(40, 160), h = rand(120, 900); m4.compose(new THREE.Vector3(Math.cos(a) * r, h / 2, Math.sin(a) * r), new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.random() * 3), new THREE.Vector3(w, h, w)); bm.setMatrixAt(i, m4); }
    s.add(bm);
    const beacons = new THREE.InstancedMesh(new THREE.SphereGeometry(6, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff3355, toneMapped: false }), n);
    for (let i = 0; i < n; i++) { bm.getMatrixAt(i, m4); const p = new THREE.Vector3(), q = new THREE.Quaternion(), sc2 = new THREE.Vector3(); m4.decompose(p, q, sc2); m4.makeTranslation(p.x, sc2.y + 6, p.z); beacons.setMatrixAt(i, m4); }
    s.add(beacons);
  }

  buildPlayer() {
    const P = this.playerObj; const suit = new THREE.MeshStandardMaterial({ color: 0x1a2533, metalness: 0.8, roughness: 0.3 });
    const trim = new THREE.MeshBasicMaterial({ color: 0x5ef2ff, toneMapped: false });
    const plate = new THREE.MeshStandardMaterial({ color: 0xd9e4ee, metalness: 0.4, roughness: 0.35 });
    const box = (w: number, h: number, d: number, m: THREE.Material) => { const x = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); x.castShadow = true; return x; };
    const torso = box(0.9, 1.0, 0.5, plate); torso.position.y = 1.55;
    const belt = box(0.95, 0.12, 0.55, trim); belt.position.y = 1.05;
    const core = box(0.25, 0.25, 0.05, trim); core.position.set(0, 1.65, 0.27);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.3, 18, 14), suit); head.position.y = 2.35; head.castShadow = true;
    const visor = box(0.46, 0.12, 0.2, trim); visor.position.set(0, 2.38, 0.2);
    const mkLimb = (x: number, y: number, len: number, w: number) => { const pivot = new THREE.Group(); pivot.position.set(x, y, 0); const l = box(w, len, w, suit); l.position.y = -len / 2; pivot.add(l); const stripe = box(w * 1.05, len * 0.15, w * 1.05, trim); stripe.position.y = -len * 0.55; pivot.add(stripe); return pivot; };
    const armL = mkLimb(-0.6, 2.0, 0.9, 0.24), armR = mkLimb(0.6, 2.0, 0.9, 0.24);
    const legL = mkLimb(-0.24, 1.0, 1.0, 0.3), legR = mkLimb(0.24, 1.0, 1.0, 0.3);
    this.handSlot.position.set(0, -0.9, 0.05); armR.add(this.handSlot);
    const handL = new THREE.Group(); handL.position.set(0, -0.9, 0); armL.add(handL);
    P.add(torso, belt, core, head, visor, armL, armR, legL, legR);
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.9, 1.0, 48).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x5ef2ff, transparent: true, opacity: 0.6, toneMapped: false }));
    ring.position.y = 0.05; P.add(ring);
    this.parts = { armL, armR, legL, legR, handL, torso, ring, head };
    this.scene.add(P);
  }

  setHeldModel(item: ItemDef | null) {
    while (this.handSlot.children.length) { const c = this.handSlot.children[0]; this.handSlot.remove(c); }
    if (!item) return;
    const col = new THREE.Color(item.color);
    const glow = new THREE.MeshBasicMaterial({ color: col, toneMapped: false });
    const metal = new THREE.MeshStandardMaterial({ color: 0x222a33, metalness: 0.9, roughness: 0.25 });
    const g = new THREE.Group();
    if (item.kind === 'sword') {
      const len = item.id === 'bisento' ? 3.6 : item.id === 'pole' ? 3.2 : 2.4;
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, item.id === 'sword_blade' ? 0.5 : len * 0.55, 8), metal); handle.rotation.x = Math.PI / 2; handle.position.z = 0.15;
      const bladeGeo = item.id === 'pole' ? new THREE.CylinderGeometry(0.06, 0.06, len * 0.6, 8) : new THREE.BoxGeometry(item.id === 'bisento' ? 0.35 : 0.14, 0.04, len * 0.55);
      const blade = new THREE.Mesh(bladeGeo, glow); if (item.id === 'pole') blade.rotation.x = Math.PI / 2; blade.position.z = len * 0.45;
      const guard = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.08, 0.1), metal); guard.position.z = 0.35;
      g.add(handle, blade, guard);
      if (item.id === 'pole') { const tip = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.04, 6, 20), glow); tip.position.z = len * 0.78; g.add(tip); }
      if (item.id === 'bisento') { const b2 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 0.8), glow); b2.position.set(0.12, 0, len * 0.72); g.add(b2); }
      g.rotation.x = -0.25; g.userData.blade = blade;
    } else if (item.id === 'rime' || item.id === 'wildfire') {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.22, 1.1), metal); body.position.z = 0.35;
      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.8, 10), metal); barrel.rotation.x = Math.PI / 2; barrel.position.z = 1.1;
      const coil = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.025, 6, 16), glow); coil.position.z = 0.9;
      const coil2 = coil.clone(); coil2.position.z = 1.2;
      const cell = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.4), glow); cell.position.set(0, 0.14, 0.2);
      g.add(body, barrel, coil, coil2, cell); g.rotation.x = -Math.PI / 2 + 0.1; g.position.y = 0; g.userData.muzzle = coil2;
    } else {
      const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.2, 1), glow);
      const halo = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.02, 6, 32), glow);
      g.add(orb, halo); g.userData.orb = orb; g.userData.halo = halo;
    }
    this.handSlot.add(g);
  }

  /* ---------------------------------------------------------------- settings */
  applySettings(s: GraphicsSettings) {
    this.settings = { ...s };
    const pr = Math.min(window.devicePixelRatio || 1, 2) * s.renderScale;
    this.renderer.setPixelRatio(pr);
    this.renderer.toneMappingExposure = s.exposure;
    this.sun.castShadow = s.shadows;
    if (this.sun.shadow.mapSize.x !== s.shadowRes) { this.sun.shadow.mapSize.set(s.shadowRes, s.shadowRes); this.sun.shadow.map?.dispose(); (this.sun.shadow as any).map = null; }
    this.bloom.enabled = s.bloom; this.bloom.strength = s.bloomStrength;
    const samples = s.antialias ? 4 : 0;
    if (this.composer.renderTarget1.samples !== samples) { this.composer.renderTarget1.samples = samples; this.composer.renderTarget2.samples = samples; this.composer.renderTarget1.dispose(); this.composer.renderTarget2.dispose(); }
    this.scene.fog = s.fog ? new THREE.FogExp2(0x061220, 1.6 / s.drawDistance) : null;
    this.camera.fov = s.fov; this.camera.updateProjectionMatrix();
    this.fx.sparks.density = s.particleDensity; this.fx.smoke.density = s.particleDensity;
    this.fx.rocks.density = s.debrisDensity; this.fx.shards.density = s.debrisDensity;
    this.fx.boltGlow = s.boltGlow; this.fx.lightFlashes = s.lightFlashes;
    this.touchMode = s.touchControls === 'on' || (s.touchControls === 'auto' && matchMedia('(pointer: coarse)').matches);
    this.resize();
  }
  resize = () => {
    const w = this.container.clientWidth || window.innerWidth, h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false); this.composer.setPixelRatio(this.renderer.getPixelRatio()); this.composer.setSize(w, h);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    const scale = (h * this.renderer.getPixelRatio()) / (2 * Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2));
    this.fx.sparks.mat.uniforms.uScale.value = scale; this.fx.smoke.mat.uniforms.uScale.value = scale;
  };

  /* ---------------------------------------------------------------- input */
  bindInput() {
    const el = this.renderer.domElement;
    window.addEventListener('keydown', this.onKeyDown); window.addEventListener('keyup', this.onKeyUp);
    el.addEventListener('contextmenu', (e) => e.preventDefault());
    el.addEventListener('pointerdown', this.onPtrDown); window.addEventListener('pointermove', this.onPtrMove); window.addEventListener('pointerup', this.onPtrUp); window.addEventListener('pointercancel', this.onPtrUp);
    el.addEventListener('wheel', this.onWheel, { passive: false });
  }
  onKeyDown = (e: KeyboardEvent) => {
    if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
    const k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
    if (this.keys.has(k)) return; this.keys.add(k);
    const si = SKILL_KEYS.indexOf(k);
    if (si >= 0) { this.pressSkill(si); return; }
    const slotKeys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-'];
    const sl = slotKeys.indexOf(k); if (sl >= 0) { this.toggleEquip(sl); return; }
    if (k === 'PageUp' || k === ']' || e.code === 'NumpadAdd' || k === '+' || k === '=') this.zoomBy(0.8);
    if (k === 'PageDown' || k === '[' || e.code === 'NumpadSubtract') this.zoomBy(1.25);
    if (k === ' ') { this.jump(); e.preventDefault(); }
    if (k === 'H') this.onUi?.('togglePanel');
    if (k === 'Escape') this.onUi?.('settings');
  };
  onKeyUp = (e: KeyboardEvent) => {
    const k = e.key.length === 1 ? e.key.toUpperCase() : e.key; this.keys.delete(k);
    const si = SKILL_KEYS.indexOf(k); if (si >= 0) this.releaseSkill(si);
  };
  onPtrDown = (e: PointerEvent) => {
    if (e.pointerType === 'touch') {
      this.touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.touches.size === 2) { const [a, b] = [...this.touches.values()]; this.pinch = Math.hypot(a.x - b.x, a.y - b.y); }
      return;
    }
    this.updateMouse(e);
    if (e.button === 2 || e.button === 1) { this.dragging = true; this.lastPtr = { x: e.clientX, y: e.clientY }; }
    if (e.button === 0) { this.m1Held = true; this.m1Queued = true; }
  };
  onPtrMove = (e: PointerEvent) => {
    if (e.pointerType === 'touch') {
      const t = this.touches.get(e.pointerId); if (!t) return;
      if (this.touches.size === 1) { this.yaw -= (e.clientX - t.x) * 0.006; this.pitch = THREE.MathUtils.clamp(this.pitch + (e.clientY - t.y) * 0.004, -0.2, 1.45); }
      t.x = e.clientX; t.y = e.clientY;
      if (this.touches.size === 2) { const [a, b] = [...this.touches.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y); if (this.pinch > 0) this.zoomTarget = THREE.MathUtils.clamp(this.zoomTarget * (this.pinch / d), MIN_ZOOM, MAX_ZOOM); this.pinch = d; }
      return;
    }
    this.updateMouse(e);
    if (this.dragging) { this.yaw -= (e.clientX - this.lastPtr.x) * 0.005; this.pitch = THREE.MathUtils.clamp(this.pitch + (e.clientY - this.lastPtr.y) * 0.004, -0.2, 1.45); this.lastPtr = { x: e.clientX, y: e.clientY }; }
  };
  onPtrUp = (e: PointerEvent) => {
    if (e.pointerType === 'touch') { this.touches.delete(e.pointerId); if (this.touches.size < 2) this.pinch = 0; return; }
    if (e.button === 2 || e.button === 1) this.dragging = false;
    if (e.button === 0) this.m1Held = false;
  };
  onWheel = (e: WheelEvent) => {
    e.preventDefault();
    const dy = e.deltaMode === 1 ? e.deltaY * 30 : e.deltaY; // line vs pixel (mouse wheel / laptop touchpad / pinch)
    const f = Math.exp(dy * (e.ctrlKey ? 0.01 : 0.0015));
    this.zoomTarget = THREE.MathUtils.clamp(this.zoomTarget * f, MIN_ZOOM, MAX_ZOOM);
  };
  zoomBy(f: number) { this.zoomTarget = THREE.MathUtils.clamp(this.zoomTarget * f, MIN_ZOOM, MAX_ZOOM); }
  setZoom(z: number) { this.zoomTarget = THREE.MathUtils.clamp(z, MIN_ZOOM, MAX_ZOOM); }
  updateMouse(e: PointerEvent) { const r = this.renderer.domElement.getBoundingClientRect(); this.mouse.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); this.mouseIn = true; }
  jump() { if (this.player.ground && this.worldPause <= 0) { this.player.vel.y = 17; this.player.ground = false; } }

  pollGamepad(dt: number) {
    const pads = navigator.getGamepads ? navigator.getGamepads() : []; const gp = pads && [...pads].find((p) => p);
    if (!gp) return;
    const dz = (v: number) => (Math.abs(v) < 0.15 ? 0 : v);
    this.joy.x = dz(gp.axes[0] ?? 0); this.joy.y = -dz(gp.axes[1] ?? 0);
    this.yaw -= dz(gp.axes[2] ?? 0) * dt * 2.6; this.pitch = THREE.MathUtils.clamp(this.pitch + dz(gp.axes[3] ?? 0) * dt * 1.8, -0.2, 1.45);
    const lt = gp.buttons[6]?.value ?? 0, rt = gp.buttons[7]?.value ?? 0;
    if (lt > 0.1) this.zoomTarget = Math.min(MAX_ZOOM, this.zoomTarget * (1 + lt * dt * 2.5));
    if (rt > 0.1) this.zoomTarget = Math.max(MIN_ZOOM, this.zoomTarget * (1 - rt * dt * 2.5));
    const pressed = (i: number) => !!gp.buttons[i]?.pressed; const edge = (i: number) => pressed(i) && !this.gpPrev[i];
    if (edge(0)) this.jump();
    if (edge(2)) { this.m1Queued = true; } this.m1Held = pressed(2);
    if (edge(5)) this.toggleEquip(((this.equipped < 0 ? -1 : this.equipped) + 1) % this.items.length);
    if (edge(4)) this.toggleEquip(((this.equipped < 0 ? 0 : this.equipped) - 1 + this.items.length) % this.items.length);
    const n = this.equipped >= 0 ? this.items[this.equipped].skills.length : 0;
    if (n) { if (edge(12)) this.gpSkillSel = (this.gpSkillSel - 1 + n) % n; if (edge(13)) this.gpSkillSel = (this.gpSkillSel + 1) % n; }
    if (edge(1) || edge(3)) this.pressSkill(this.gpSkillSel);
    if ((!pressed(1) && this.gpPrev[1]) || (!pressed(3) && this.gpPrev[3])) this.releaseSkill(this.gpSkillSel);
    if (pressed(14)) this.zoomTarget = Math.min(MAX_ZOOM, this.zoomTarget * (1 + dt * 1.5));
    if (pressed(15)) this.zoomTarget = Math.max(MIN_ZOOM, this.zoomTarget * (1 - dt * 1.5));
    this.gpPrev = gp.buttons.map((b) => b.pressed);
  }

  /* ---------------------------------------------------------------- items & skills */
  get item() { return this.equipped >= 0 ? this.items[this.equipped] : null; }
  toggleEquip(i: number) {
    if (i < 0 || i >= this.items.length) return;
    const prev = this.item;
    if (prev) { prev.onUnequip?.(this); this.skillStates[prev.id].forEach((s, k) => { if (s.holding) this.releaseSkill(k); s.holding = false; }); }
    this.equipped = this.equipped === i ? -1 : i; this.combo = 0; this.gpSkillSel = 0;
    this.setHeldModel(this.item); this.item?.onEquip?.(this);
    if (this.item) { this.fx.ring(this.player.pos.clone(), 0.5, 3, this.item.color, 0.4); this.fx.burstSparks(this.player.pos.clone().setY(1.5), 20, this.item.color, 6, 0.5, 0.4, 0); }
    this.onUi?.('equip');
  }
  cdMul() { return this.buffs.alarm > this.time ? 0.75 : 1; }
  skillReady(i: number) { const it = this.item; if (!it) return false; const s = this.skillStates[it.id][i]; return !!s && this.time >= s.cdEnd; }
  pressSkill(i: number) {
    const it = this.item; if (!it || this.player.deadT > 0) return; const sd = it.skills[i]; if (!sd) return; const st = this.skillStates[it.id][i];
    if (this.time < st.cdEnd || st.holding) return;
    if (sd.charges && st.charges <= 0) return;
    this.faceAim();
    const r = sd.cast(this, st);
    if (r === false) return;
    if (sd.hold) { st.holding = true; return; }
    this.startCd(it, i);
  }
  releaseSkill(i: number) {
    const it = this.item; if (!it) return; const sd = it.skills[i]; if (!sd) return; const st = this.skillStates[it.id][i];
    if (!st.holding) return; st.holding = false; this.faceAim(); sd.release?.(this, st); this.startCd(it, i);
  }
  startCd(it: ItemDef, i: number) {
    const sd = it.skills[i], st = this.skillStates[it.id][i];
    let cd = sd.cd * this.cdMul() * (sd.cdMul ? sd.cdMul(this) : 1);
    if (sd.charges) { st.charges--; cd = st.charges > 0 ? sd.charges.interval : cd; }
    st.cdTotal = cd; st.cdEnd = this.time + cd;
  }
  faceAim() { const d = _v.subVectors(this.aim, this.player.pos); if (d.x * d.x + d.z * d.z > 0.01) this.player.yaw = Math.atan2(d.x, d.z); }
  get aimDir() { const d = new THREE.Vector3(this.aim.x - this.player.pos.x, 0, this.aim.z - this.player.pos.z); if (d.lengthSq() < 0.01) d.set(Math.sin(this.player.yaw), 0, Math.cos(this.player.yaw)); return d.normalize(); }
  get fwd() { return new THREE.Vector3(Math.sin(this.player.yaw), 0, Math.cos(this.player.yaw)); }
  handPos() { const p = new THREE.Vector3(); this.handSlot.getWorldPosition(p); return p; }
  playAnim(kind: string, d: number) { this.anim = { kind, t: 0, d }; }

  doM1() {
    const it = this.item; if (!it || !it.m1 || this.player.deadT > 0) return;
    if (this.time < this.m1Next) return;
    if (this.time - this.lastM1 > 1.2) this.combo = 0;
    const L = it.m1.comboLen ?? 4; this.combo = (this.combo % L) + 1; this.lastM1 = this.time;
    this.m1Next = this.time + it.m1.interval;
    if (it.m1.endLag && this.combo === L) this.m1Next += it.m1.endLag;
    this.faceAim(); it.m1.fn(this, this.combo);
  }

  /* ---------------------------------------------------------------- scheduling */
  task(fn: Task['fn']) { this.tasks.push({ fn, t: 0 }); }
  after(delay: number, fn: () => void) { this.task((_d, t) => { if (t >= delay) { fn(); return false; } return true; }); }
  repeat(interval: number, count: number, fn: (i: number) => void, delay = 0) {
    let i = 0; this.task((_d, t) => { while (i < count && t >= delay + i * interval) { fn(i); i++; } return i < count; });
  }
  projectile(o: ProjOpts) {
    this.scene.add(o.obj); o.obj.position.copy(o.pos); const hit = new Set<Enemy>(); const tmp: Enemy[] = [];
    this.task((dt, t) => {
      if (o.homing && o.homing.alive) {
        const sp = o.vel.length(); _v.subVectors(o.homing.pos, o.pos); _v.y += o.homing.height * 0.5; _v.normalize().multiplyScalar(sp);
        o.vel.lerp(_v, Math.min(1, dt * (o.homingRate ?? 6))).setLength(sp);
      }
      if (o.gravity) o.vel.y -= o.gravity * dt;
      // sub-step for very fast projectiles
      const steps = Math.min(12, Math.max(1, Math.ceil((o.vel.length() * dt) / Math.max(1, o.radius))));
      const sdt = dt / steps;
      for (let s = 0; s < steps; s++) {
        o.pos.addScaledVector(o.vel, sdt);
        if (!o.noEnemyHit) {
          for (const e of this.enemies.inRadius(o.pos, o.radius, tmp)) {
            if (hit.has(e)) continue; if (Math.abs(o.pos.y - (e.pos.y + e.height * 0.5)) > e.height * 0.6 + o.radius) continue;
            hit.add(e); o.onHit?.(o.pos.clone(), e);
            if (!o.pierce) { this.scene.remove(o.obj); disposeLight(o.obj); return false; }
          }
        }
        if (o.hitGround !== false && o.pos.y <= 0) { o.pos.y = 0; o.obj.position.copy(o.pos); o.onHit?.(o.pos.clone(), null); this.scene.remove(o.obj); disposeLight(o.obj); return false; }
      }
      o.obj.position.copy(o.pos);
      if (o.faceVel) o.obj.lookAt(_v2.copy(o.pos).add(o.vel));
      o.onTick?.(o.pos, dt, t);
      if (t >= o.life) { o.onEnd?.(o.pos.clone()); this.scene.remove(o.obj); disposeLight(o.obj); return false; }
      return true;
    });
  }

  /* ---------------------------------------------------------------- combat */
  aoe(r: number) { return r * (this.buffs.alarm > this.time ? 3 : 1); }
  dmg(e: Enemy, amount: number, o: DmgOpts = {}) {
    if (!e.alive) return 0;
    let a = amount;
    if (!o.raw) { if (this.buffs.alarm > this.time) a *= 3; }
    if (o.crit) a *= 2;
    e.hp -= a; this.totalDmg += a; if (!o.small) e.hitFlash = 0.06;
    if (this.settings.damageNumbers && (!o.small || Math.random() < 0.35)) this.num(e.pos.clone().setY(e.pos.y + e.height + 0.8), a, o.color ?? (o.crit ? '#ffdd33' : '#ffffff'), o.crit || o.big);
    if (this.item?.id === 'gblade' || this.bladeCharge < 100) { if (e.gate('bc', this.time, 0.15)) this.bladeCharge = Math.min(100, this.bladeCharge + 1); }
    if (!o.raw && !o.noProc) {
      if (this.buffs.ice > this.time) e.freeze(3);
      if (this.buffs.fire > this.time) e.burn(3, e.maxHp * 0.02);
      if (this.buffs.alarm > this.time && e.alive && e.gate('alarmBolt', this.time, 0.5)) {
        const p = e.pos.clone(); this.fx.strike(p, { color: 0xff2233, core: 0xffc0c0, height: 45, overlap: 1, width: 0.7, radius: 2, sparks: 8, light: false, ring: false });
        this.dmg(e, e.maxHp * 0.2, { raw: true, color: '#ff3344', noProc: true });
      }
    }
    if (e.hp <= 0) { this.enemies.kill(e); }
    return a;
  }
  dmgArea(p: THREE.Vector3, r: number, amount: number, o: AreaOpts = {}) {
    const list = this.enemies.inRadius(p, r, []);
    for (const e of list) {
      if (o.filter && !o.filter(e)) continue;
      if (o.knock || o.up) { const d = _v.subVectors(e.pos, o.from ?? p).setY(0); if (d.lengthSq() < 0.01) d.set(rand(-1, 1), 0, rand(-1, 1)); d.normalize(); e.knock(d, o.knock ?? 0, o.up ?? 0); }
      if (o.stun) e.stun(o.stun); if (o.freeze) e.freeze(o.freeze); if (o.burn) e.burn(o.burn[0], o.burn[1]); if (o.lift) e.lift(o.lift[0], o.lift[1]);
      this.dmg(e, amount, o);
    }
    return list;
  }
  onKill(_e: Enemy) { this.kills++; this.bladeCharge = Math.min(100, this.bladeCharge + 10); }
  hurtPlayer(n: number) {
    const P = this.player; if (P.invT > 0 || P.deadT > 0) return;
    P.hp -= n; if (P.hp <= 0) { P.hp = 0; P.deadT = 2.5; this.flashScreen(255, 30, 40, 0.6, 1); }
  }
  healPlayer(n: number) { this.player.hp = Math.min(this.player.maxHp, this.player.hp + n); }
  shake(p: THREE.Vector3, i: number, d: number, global = false) { if (this.shakes.length > 60) this.shakes.shift(); this.shakes.push({ p: p.clone(), i, d, t: 0, global }); }
  flashScreen(r: number, g: number, b: number, a: number, decay: number) { this.overlayState = { r, g, b, a, decay }; }
  floodSlow(p: THREE.Vector3) { for (const f of this.floods) if (f.level > 0.8 && (p.x - f.p.x) ** 2 + (p.z - f.p.z) ** 2 < f.r * f.r) return true; return false; }
  num(p: THREE.Vector3, v: number, color: string, big?: boolean) {
    const n = this.nums[this.numCur]; this.numCur = (this.numCur + 1) % this.nums.length;
    n.p.copy(p).add(new THREE.Vector3(rand(-0.8, 0.8), rand(0, 0.8), rand(-0.8, 0.8))); n.t = 0; n.life = big ? 1.3 : 0.9; n.active = true;
    n.el.textContent = fmt(v); n.el.style.color = color; n.el.style.fontSize = big ? '22px' : '14px';
  }
  addAura(obj: THREE.Object3D, until: () => boolean, upd?: (o: THREE.Object3D, dt: number) => void) {
    this.scene.add(obj);
    this.task((dt) => { obj.position.copy(this.player.pos); upd?.(obj, dt); if (!until()) { this.scene.remove(obj); disposeLight(obj); return false; } return true; });
  }

  /* ---------------------------------------------------------------- loop */
  loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.fpsAcc += dt; this.fpsN++; if (this.fpsAcc > 0.5) { this.fps = Math.round(this.fpsN / this.fpsAcc); this.fpsAcc = 0; this.fpsN = 0; }
    this.update(dt);
    this.composer.render(dt);
  };
  update(dt: number) {
    this.time += dt; if (this.worldPause > 0) this.worldPause -= dt;
    this.pollGamepad(dt);
    this.updateAim();
    this.updatePlayer(dt);
    // M1
    const it = this.item;
    if (it?.m1) { if (it.m1.manual) { if (this.m1Queued) this.doM1(); } else if (this.m1Held || this.m1Queued) this.doM1(); }
    this.m1Queued = false;
    // hold skills + charge regen
    for (const item of this.items) {
      const sts = this.skillStates[item.id];
      item.skills.forEach((sd, i) => {
        const st = sts[i];
        if (sd.charges && st.charges < sd.charges.max) { st.chargeTimer += dt; if (st.chargeTimer >= sd.charges.regen) { st.chargeTimer = 0; st.charges++; } }
        if (st.holding && item === it && sd.holdTick) { if (!sd.holdTick(this, st, dt)) this.releaseSkill(i); }
      });
    }
    for (let i = this.tasks.length - 1; i >= 0; i--) { const t = this.tasks[i]; t.t += dt; let keep: boolean | void = true; try { keep = t.fn(dt, t.t); } catch (err) { console.error(err); keep = false; } if (keep === false) { const idx = this.tasks.indexOf(t); if (idx >= 0) this.tasks.splice(idx, 1); } }
    this.enemies.update(dt);
    this.fx.update(dt);
    this.updateCamera(dt);
    this.updateNums(dt);
    // overlay
    const o = this.overlayState; if (o.a > 0) o.a = Math.max(0, o.a - dt * o.decay);
    const red = this.redTint;
    if (red > 0) this.overlay.style.cssText = `position:absolute;inset:0;pointer-events:none;background:rgba(${Math.round(120 + 100 * red)},0,0,${0.25 + red * 0.45});mix-blend-mode:multiply;opacity:1`;
    else this.overlay.style.cssText = `position:absolute;inset:0;pointer-events:none;background:rgb(${o.r},${o.g},${o.b});opacity:${o.a}`;
  }
  updateAim() {
    if (!this.touchMode && this.mouseIn) {
      this.raycaster.setFromCamera(this.mouse, this.camera);
      const hit = this.raycaster.ray.intersectPlane(this.ground, _v);
      if (hit && hit.distanceTo(this.player.pos) < 600) this.aim.copy(hit);
      else { const d = this.raycaster.ray.direction.clone().setY(0).normalize(); this.aim.copy(this.player.pos).addScaledVector(d, 120); }
    } else {
      // touch / gamepad: soft-lock nearest enemy in camera forward cone, else point ahead
      const f = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
      let best: Enemy | null = null, bs = -1;
      for (const e of this.enemies.list) { const d = _v.subVectors(e.pos, this.player.pos).setY(0); const L = d.length(); if (L > 160 || L < 0.1) continue; const dot = d.dot(f) / L; const sc = dot - L / 400; if (dot > 0.75 && sc > bs) { bs = sc; best = e; } }
      if (best) this.aim.copy(best.pos).setY(0); else this.aim.copy(this.player.pos).addScaledVector(f, 30).setY(0);
    }
  }
  updatePlayer(dt: number) {
    const P = this.player;
    if (P.invT > 0) P.invT -= dt;
    if (P.deadT > 0) { P.deadT -= dt; if (P.deadT <= 0) { P.hp = P.maxHp; P.invT = 2; this.fx.shell(P.pos.clone().setY(1), 0.5, 6, 0x5ef2ff, 0.6); } }
    let ix = 0, iz = 0;
    if (this.worldPause <= 0 && P.deadT <= 0) {
      if (this.keys.has('W') || this.keys.has('ArrowUp')) iz += 1;
      if (this.keys.has('S') || this.keys.has('ArrowDown')) iz -= 1;
      if (this.keys.has('A') || this.keys.has('ArrowLeft')) ix -= 1;
      if (this.keys.has('D') || this.keys.has('ArrowRight')) ix += 1;
      if (this.keys.has('Q')) this.yaw += dt * 2; if (this.keys.has('E')) this.yaw -= dt * 2;
      ix += this.joy.x; iz += this.joy.y;
    }
    const L = Math.hypot(ix, iz);
    const sprint = this.keys.has('Shift');
    const speed = (sprint ? 30 : 17);
    if (L > 0.05) {
      const nx = ix / Math.max(1, L), nz = iz / Math.max(1, L);
      const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw); const rx = -fz, rz = fx;
      const mx = fx * nz + rx * nx, mz = fz * nz + rz * nx;
      P.pos.x += mx * speed * dt; P.pos.z += mz * speed * dt;
      const targetYaw = Math.atan2(mx, mz);
      if (this.anim.t >= this.anim.d) { let dy = targetYaw - P.yaw; while (dy > Math.PI) dy -= Math.PI * 2; while (dy < -Math.PI) dy += Math.PI * 2; P.yaw += dy * Math.min(1, dt * 12); }
      this.walkT += dt * (sprint ? 14 : 10);
    } else this.walkT *= 0.9;
    if (!P.ground || P.vel.y > 0) { P.vel.y -= 40 * dt; P.pos.y += P.vel.y * dt; if (P.pos.y <= 0) { P.pos.y = 0; P.vel.y = 0; P.ground = true; } }
    P.pos.x += P.vel.x * dt; P.pos.z += P.vel.z * dt; P.vel.x *= 0.85; P.vel.z *= 0.85;
    // model
    const O = this.playerObj; O.position.copy(P.pos); O.rotation.y = P.yaw;
    O.visible = P.deadT <= 0;
    const sw = Math.sin(this.walkT) * Math.min(1, L) * 0.8;
    const { armL, armR, legL, legR, ring } = this.parts;
    legL.rotation.x = sw; legR.rotation.x = -sw; armL.rotation.x = -sw * 0.7; armR.rotation.x = sw * 0.7; armR.rotation.z = 0; armL.rotation.z = 0;
    const a = this.anim;
    if (a.t < a.d) {
      a.t += dt; const k = a.t / a.d;
      if (a.kind === 'swing') { armR.rotation.x = -2.2 + k * 3; armR.rotation.z = -0.6 + k * 1.2; }
      else if (a.kind === 'punch') { armR.rotation.x = -Math.PI / 2 - Math.sin(k * Math.PI) * 0.3; }
      else if (a.kind === 'raise') { armR.rotation.x = -Math.PI * 0.95; armL.rotation.x = -Math.PI * 0.95; }
      else if (a.kind === 'slam') { const u = k < 0.5 ? -Math.PI * 0.9 : -Math.PI * 0.9 + (k - 0.5) * 2 * 2.6; armR.rotation.x = u; armL.rotation.x = u; }
      else if (a.kind === 'aim') { armR.rotation.x = -Math.PI / 2; }
      else if (a.kind === 'charge') { armR.rotation.x = 0.8; armR.rotation.z = -0.4; armL.rotation.x = -Math.PI / 2; }
    } else if (this.item && (this.item.id === 'rime' || this.item.id === 'wildfire')) armR.rotation.x = -Math.PI / 2.4;
    (ring as THREE.Mesh).scale.setScalar(1 + Math.sin(this.time * 4) * 0.08);
    const held = this.handSlot.children[0];
    if (held?.userData.halo) { held.userData.halo.rotation.x += dt * 3; held.userData.halo.rotation.y += dt * 2; if (Math.random() < 0.3) this.fx.sparks.emit(...this.handPos().toArray() as [number, number, number], rand(-1, 1), rand(0.5, 2), rand(-1, 1), new THREE.Color(this.item!.color), 0.5, 0.25); }
    this.sun.position.set(P.pos.x + 80, 140, P.pos.z + 40); this.sun.target.position.copy(P.pos);
  }
  updateCamera(dt: number) {
    this.zoom += (this.zoomTarget - this.zoom) * Math.min(1, dt * 10);
    const P = this.player.pos;
    this.camTarget.lerp(_v.set(P.x, P.y + 2.2, P.z), Math.min(1, dt * 14));
    const cp = Math.cos(this.pitch);
    const base = _v2.set(this.camTarget.x + Math.sin(this.yaw) * cp * this.zoom, this.camTarget.y + Math.sin(this.pitch) * this.zoom, this.camTarget.z + Math.cos(this.yaw) * cp * this.zoom);
    if (base.y < 0.5) base.y = 0.5;
    this.camera.position.copy(base);
    this.camera.lookAt(this.camTarget); // rotation fixed from un-shaken pose
    // positional-only shake (X/Y/Z translation, no pitch/yaw/roll)
    let amp = 0;
    for (let i = this.shakes.length - 1; i >= 0; i--) {
      const s = this.shakes[i]; s.t += dt; if (s.t >= s.d) { this.shakes.splice(i, 1); continue; }
      const dist = s.global ? 0 : s.p.distanceTo(base);
      const fall = 1 / (1 + (dist / 45) * (dist / 45)); // closer => stronger, farther => weaker
      amp += s.i * fall * Math.pow(1 - s.t / s.d, 1.4);
    }
    amp = Math.min(amp * 0.045 * this.settings.shakeScale, 4.5);
    this.shakeOffset.set((Math.random() * 2 - 1) * amp, (Math.random() * 2 - 1) * amp, (Math.random() * 2 - 1) * amp);
    this.camera.position.add(this.shakeOffset);
  }
  updateNums(dt: number) {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    for (const n of this.nums) {
      if (!n.active) continue; n.t += dt;
      if (n.t >= n.life) { n.active = false; n.el.style.opacity = '0'; continue; }
      _v.copy(n.p); _v.y += n.t * 2.5; _v.project(this.camera);
      if (_v.z > 1) { n.el.style.opacity = '0'; continue; }
      const k = n.t / n.life; const sc = k < 0.15 ? 0.6 + k * 4 : 1.2 - k * 0.3;
      n.el.style.transform = `translate(${(_v.x * 0.5 + 0.5) * w}px, ${(-_v.y * 0.5 + 0.5) * h}px) translate(-50%,-50%) scale(${sc})`;
      n.el.style.opacity = String(1 - k * k);
    }
  }
  dispose() {
    this.disposed = true; cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.resize); window.removeEventListener('keydown', this.onKeyDown); window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('pointermove', this.onPtrMove); window.removeEventListener('pointerup', this.onPtrUp); window.removeEventListener('pointercancel', this.onPtrUp);
    this.renderer.dispose(); this.container.innerHTML = '';
  }
}
function disposeLight(o: THREE.Object3D) { o.traverse((c) => { const m = c as THREE.Mesh; if (m.material && !(m.material as any).__shared) (m.material as THREE.Material).dispose?.(); }); }
export function fmt(v: number) {
  const a = Math.abs(v);
  if (a >= 1e15) return (v / 1e15).toFixed(1) + 'Q'; if (a >= 1e12) return (v / 1e12).toFixed(1) + 'T'; if (a >= 1e9) return (v / 1e9).toFixed(1) + 'B';
  if (a >= 1e6) return (v / 1e6).toFixed(1) + 'M'; if (a >= 1e4) return (v / 1e3).toFixed(1) + 'K'; return Math.round(v).toString();
}
