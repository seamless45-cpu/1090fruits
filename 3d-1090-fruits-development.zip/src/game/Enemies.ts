import * as THREE from 'three';
import type { Game } from './Game';
import { GEO, rand, sharedMat } from './Effects';

export type EType = 'normal' | 'elite' | 'boss';
const CFG: Record<EType, { hp: number; scale: number; speed: number; dmg: number; color: number; visor: number }> = {
  normal: { hp: 4000, scale: 1, speed: 6, dmg: 2, color: 0x2b3440, visor: 0xff3344 },
  elite: { hp: 60000, scale: 1.7, speed: 5, dmg: 5, color: 0x3a2150, visor: 0xffc23a },
  boss: { hp: 900000, scale: 4, speed: 4, dmg: 12, color: 0x401414, visor: 0xff7a00 },
};
const bodyGeo = new THREE.CapsuleGeometry(0.55, 1.0, 4, 12);
const headGeo = new THREE.BoxGeometry(0.8, 0.5, 0.7);
const visorGeo = new THREE.BoxGeometry(0.7, 0.14, 0.1);
const padGeo = new THREE.BoxGeometry(0.45, 0.3, 0.55);
const crownGeo = new THREE.TorusGeometry(0.6, 0.06, 6, 24);
const visorMats: Record<string, THREE.Material> = {};
const barBg = sharedMat(new THREE.SpriteMaterial({ color: 0x050a10, depthTest: true, opacity: 0.8, transparent: true }));
const cageMat = sharedMat(new THREE.MeshBasicMaterial({ color: 0xff1a2a, wireframe: true, transparent: true, opacity: 0.9, toneMapped: false }));
const iceMat = sharedMat(new THREE.MeshStandardMaterial({ color: 0xaee8ff, transparent: true, opacity: 0.55, roughness: 0.1, metalness: 0.1, emissive: 0x2a6f9a, emissiveIntensity: 0.5 }));
const hackMat = sharedMat(new THREE.MeshBasicMaterial({ color: 0x33ff88, wireframe: true, transparent: true, opacity: 0.6, toneMapped: false }));

let NEXT_ID = 1;
export class Enemy {
  id = NEXT_ID++; type: EType; group = new THREE.Group(); inner!: THREE.Group; mat: THREE.MeshStandardMaterial;
  hpFg: THREE.Sprite; hpFgMat: THREE.SpriteMaterial; hpBg: THREE.Sprite;
  cage: THREE.Mesh; ice: THREE.Mesh; hack: THREE.Mesh; crown?: THREE.Mesh;
  vel = new THREE.Vector3(); hp: number; maxHp: number; radius: number; height: number; speed: number; atk: number;
  stunT = 0; freezeT = 0; imprisonT = 0; blindT = 0; liftT = 0; liftH = 0; fleeT = 0; hackedT = 0;
  burnT = 0; burnDps = 0; bleeds: { t: number; dps: number }[] = []; dotAcc = 0;
  attackCd = 1; wander = new THREE.Vector3(); wanderT = 0; alive = true; hitFlash = 0; tags: Record<string, number> = {};
  get pos() { return this.group.position; }
  constructor(type: EType, p: THREE.Vector3) {
    this.type = type; const c = CFG[type];
    this.maxHp = this.hp = c.hp; this.radius = 0.7 * c.scale; this.height = 2.2 * c.scale; this.speed = c.speed * rand(0.8, 1.2); this.atk = c.dmg;
    this.mat = new THREE.MeshStandardMaterial({ color: c.color, roughness: 0.45, metalness: 0.7, emissive: 0x000000 });
    const vm = visorMats[type] ?? (visorMats[type] = sharedMat(new THREE.MeshBasicMaterial({ color: c.visor, toneMapped: false })));
    const body = new THREE.Mesh(bodyGeo, this.mat); body.position.y = 1.05; body.castShadow = true;
    const head = new THREE.Mesh(headGeo, this.mat); head.position.y = 2.05; head.castShadow = true;
    const visor = new THREE.Mesh(visorGeo, vm); visor.position.set(0, 2.08, 0.36);
    const pl = new THREE.Mesh(padGeo, this.mat); pl.position.set(-0.7, 1.55, 0); const pr = pl.clone(); pr.position.x = 0.7;
    const inner = new THREE.Group(); inner.add(body, head, visor, pl, pr);
    if (type !== 'normal') { this.crown = new THREE.Mesh(crownGeo, vm); this.crown.position.y = 2.7; this.crown.rotation.x = Math.PI / 2; inner.add(this.crown); }
    inner.scale.setScalar(c.scale); this.group.add(inner); this.inner = inner;
    this.hpBg = new THREE.Sprite(barBg); this.hpBg.center.set(0.5, 0.5);
    this.hpFgMat = new THREE.SpriteMaterial({ color: type === 'normal' ? 0xff4455 : type === 'elite' ? 0xffc23a : 0xff7a00, toneMapped: false });
    this.hpFg = new THREE.Sprite(this.hpFgMat); this.hpFg.center.set(0.5, 0.5);
    const bw = type === 'boss' ? 8 : type === 'elite' ? 3 : 1.8;
    this.hpBg.scale.set(bw + 0.1, 0.22 * (type === 'boss' ? 2 : 1), 1); this.hpBg.position.y = this.height + 0.6;
    this.hpFg.scale.set(bw, 0.16 * (type === 'boss' ? 2 : 1), 1); this.hpFg.position.set(0, this.height + 0.6, 0); this.hpFg.renderOrder = 2;
    this.group.add(this.hpBg, this.hpFg);
    this.cage = new THREE.Mesh(GEO.cylSolid, cageMat); this.cage.scale.set(this.radius * 1.8, this.height * 1.15, this.radius * 1.8); this.cage.position.y = this.height / 2; this.cage.visible = false;
    this.ice = new THREE.Mesh(GEO.box, iceMat); this.ice.scale.set(this.radius * 2.6, this.height * 1.1, this.radius * 2.6); this.ice.position.y = this.height / 2; this.ice.visible = false;
    this.hack = new THREE.Mesh(GEO.ico, hackMat); this.hack.scale.setScalar(this.height * 0.7); this.hack.position.y = this.height / 2; this.hack.visible = false;
    this.group.add(this.cage, this.ice, this.hack);
    this.group.position.copy(p);
  }
  get disabled() { return this.stunT > 0 || this.freezeT > 0 || this.imprisonT > 0 || this.liftT > 0; }
  stun(t: number) { this.stunT = Math.max(this.stunT, t); }
  freeze(t: number) { this.freezeT = Math.max(this.freezeT, t); }
  imprison(t: number) { this.imprisonT = Math.max(this.imprisonT, t); }
  blind(t: number) { this.blindT = Math.max(this.blindT, t); }
  flee(t: number) { this.fleeT = Math.max(this.fleeT, t); }
  hackIt(t: number) { this.hackedT = Math.max(this.hackedT, t); }
  burn(t: number, dps: number) { this.burnT = Math.max(this.burnT, t); this.burnDps = Math.max(this.burnDps, dps); }
  bleed(t: number, dps: number) { if (this.bleeds.length < 60) this.bleeds.push({ t, dps }); else this.bleeds[Math.floor(Math.random() * 60)] = { t, dps }; }
  lift(t: number, h: number) { this.liftT = Math.max(this.liftT, t); this.liftH = Math.max(this.liftH, h); }
  knock(dir: THREE.Vector3, force: number, up = 0) {
    const f = this.type === 'boss' ? 0.25 : this.type === 'elite' ? 0.6 : 1;
    this.vel.x += dir.x * force * f; this.vel.z += dir.z * force * f; this.vel.y += up * f;
  }
  /** returns true if throttle passed (for per-enemy effect throttling) */
  gate(key: string, now: number, every: number) { if ((this.tags[key] ?? -1e9) + every > now) return false; this.tags[key] = now; return true; }

  update(g: Game, dt: number) {
    const p = this.pos; const now = g.time;
    // status timers
    this.stunT -= dt; this.freezeT -= dt; this.imprisonT -= dt; this.blindT -= dt; this.fleeT -= dt; this.hackedT -= dt; this.liftT -= dt; this.hitFlash -= dt;
    // DOT
    this.dotAcc += dt;
    if (this.dotAcc >= 0.25) {
      let dot = 0;
      if (this.burnT > 0) { this.burnT -= this.dotAcc; dot += this.burnDps * this.dotAcc; if (Math.random() < 0.5) g.fx.burstSparks(p.clone().setY(p.y + this.height * 0.6), 3, 0xff7a1a, 4, 0.6, 0.5, -4); }
      if (this.bleeds.length) {
        for (let i = this.bleeds.length - 1; i >= 0; i--) { const b = this.bleeds[i]; b.t -= this.dotAcc; dot += b.dps * this.dotAcc; if (b.t <= 0) this.bleeds.splice(i, 1); }
      }
      this.dotAcc = 0;
      if (dot > 0) g.dmg(this, dot, { raw: true, color: this.burnT > 0 ? '#ff9a3a' : '#ff3355', small: true });
      if (!this.alive) return;
    }
    const frozenWorld = g.worldPause > 0;
    if (frozenWorld) return;
    // movement intent
    const pp = g.player.pos;
    let mx = 0, mz = 0;
    if (!this.disabled) {
      const dx = pp.x - p.x, dz = pp.z - p.z; const d = Math.hypot(dx, dz) || 1;
      if (this.fleeT > 0) { mx = -dx / d; mz = -dz / d; }
      else if (this.blindT > 0) {
        this.wanderT -= dt; if (this.wanderT <= 0) { const a = Math.random() * 6.28; this.wander.set(Math.cos(a), 0, Math.sin(a)); this.wanderT = rand(0.4, 1.2); }
        mx = this.wander.x; mz = this.wander.z;
      } else {
        if (d > this.radius + 1.6) { mx = dx / d; mz = dz / d; }
        this.attackCd -= dt;
        if (d < this.radius + 2.2 && this.attackCd <= 0 && p.y < 3) {
          this.attackCd = 1.3;
          if (this.hackedT > 0) g.healPlayer(this.atk * 2);
          else g.hurtPlayer(this.atk);
          g.fx.ring(p.clone().setY(0.1), 0.3, 1.8 * this.radius, this.hackedT > 0 ? 0x33ff88 : 0xff3344, 0.3);
        }
      }
      const sp = this.speed * (g.floodSlow(p) ? 0.4 : 1);
      p.x += mx * sp * dt; p.z += mz * sp * dt;
      if (mx || mz) this.inner.rotation.y = Math.atan2(mx, mz);
    }
    // lift / physics
    if (this.liftT > 0) { p.y += (this.liftH - p.y) * Math.min(1, dt * 4); this.vel.set(this.vel.x * 0.9, 0, this.vel.z * 0.9); }
    else {
      if (this.liftH > 0 && this.liftT <= 0) this.liftH = 0;
      if (p.y > 0 || this.vel.y > 0) { this.vel.y -= 32 * dt; }
    }
    p.addScaledVector(this.vel, dt);
    if (p.y <= 0) { p.y = 0; if (this.vel.y < 0) this.vel.y = 0; this.vel.x *= Math.max(0, 1 - dt * 6); this.vel.z *= Math.max(0, 1 - dt * 6); }
    const R = Math.hypot(p.x, p.z); if (R > 2500) { p.x *= 2500 / R; p.z *= 2500 / R; }
    // visuals
    const e = this.mat.emissive;
    if (this.hitFlash > 0) e.setRGB(1.2, 1.2, 1.2);
    else if (this.freezeT > 0) e.setRGB(0.2, 0.55, 0.9);
    else if (this.burnT > 0) e.setRGB(0.7 + Math.random() * 0.3, 0.25, 0.02);
    else if (this.blindT > 0) e.setRGB(0.6, 0.6, 0.2);
    else if (this.stunT > 0) e.setRGB(0.5, 0.5, 0.8);
    else e.setRGB(0, 0, 0);
    this.cage.visible = this.imprisonT > 0; if (this.cage.visible) this.cage.rotation.y += dt * 2;
    this.ice.visible = this.freezeT > 0;
    this.hack.visible = this.hackedT > 0; if (this.hack.visible) { this.hack.rotation.y += dt * 3; this.hack.rotation.x += dt; }
    if (this.crown) this.crown.rotation.z += dt * 2;
    this.hpFg.scale.x = this.hpBg.scale.x * Math.max(0, this.hp / this.maxHp);
    void now;
  }
}

export class EnemyManager {
  list: Enemy[] = []; spawnAcc = 0; g: Game;
  constructor(g: Game) { this.g = g; }
  spawn(type: EType, p?: THREE.Vector3) {
    const pp = this.g.player.pos;
    if (!p) { const a = Math.random() * 6.283, r = rand(35, 140); p = new THREE.Vector3(pp.x + Math.cos(a) * r, 0, pp.z + Math.sin(a) * r); }
    const e = new Enemy(type, p); this.list.push(e); this.g.scene.add(e.group);
    this.g.fx.ring(p.clone(), 0.5, e.radius * 5, type === 'normal' ? 0xff3344 : 0xffc23a, 0.6);
    this.g.fx.bolt(p.clone().setY(40), p.clone(), { color: 0xff5566, width: 0.5, life: 0.25, branches: 1 });
    return e;
  }
  kill(e: Enemy) {
    if (!e.alive) return; e.alive = false;
    const p = e.pos.clone().setY(e.pos.y + e.height * 0.5);
    const g = this.g;
    g.fx.burstSparks(p, 30 * (e.type === 'boss' ? 4 : 1), e.type === 'normal' ? 0xff4455 : 0xffc23a, 14 * (e.type === 'boss' ? 2.5 : 1), 0.9, 0.6);
    g.fx.debris(p, e.type === 'boss' ? 40 : 8, 0x39424e, 10, 0.3 * (e.type === 'boss' ? 3 : 1), 2.5);
    g.fx.shell(p, 0.3, e.height, 0xff6677, 0.4);
    g.scene.remove(e.group); e.mat.dispose(); e.hpFgMat.dispose();
    g.onKill(e);
  }
  update(dt: number) {
    const g = this.g;
    for (let i = this.list.length - 1; i >= 0; i--) {
      const e = this.list[i];
      if (e.alive) e.update(g, dt);
      if (!e.alive) this.list.splice(i, 1);
    }
    this.spawnAcc += dt;
    const target = g.settings.enemyCount;
    if (this.spawnAcc > 0.25 && this.list.length < target && g.spawning) {
      this.spawnAcc = 0;
      const hasBoss = this.list.some((e) => e.type === 'boss');
      const t: EType = !hasBoss && g.kills > 0 && g.kills % 60 < 2 ? 'boss' : Math.random() < 0.12 ? 'elite' : 'normal';
      this.spawn(t);
    }
  }
  inRadius(p: THREE.Vector3, r: number, out: Enemy[] = []) {
    out.length = 0;
    for (const e of this.list) { if (!e.alive) continue; const dx = e.pos.x - p.x, dz = e.pos.z - p.z; const rr = r + e.radius; if (dx * dx + dz * dz <= rr * rr) out.push(e); }
    return out;
  }
  nearest(p: THREE.Vector3, r = Infinity, exclude?: Set<Enemy>) {
    let best: Enemy | null = null, bd = r * r;
    for (const e of this.list) { if (!e.alive || (exclude && exclude.has(e))) continue; const dx = e.pos.x - p.x, dz = e.pos.z - p.z; const d = dx * dx + dz * dz; if (d < bd) { bd = d; best = e; } }
    return best;
  }
}
