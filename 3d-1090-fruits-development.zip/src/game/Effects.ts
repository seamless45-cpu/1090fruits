import * as THREE from 'three';

export const rand = (a: number, b: number) => a + Math.random() * (b - a);
export const randInt = (a: number, b: number) => Math.floor(rand(a, b + 1));
export const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];
const UP = new THREE.Vector3(0, 1, 0);
const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _d = new THREE.Vector3(), _s = new THREE.Vector3(), _vw = new THREE.Vector3();
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _sc = new THREE.Vector3(), _c = new THREE.Color();

/* ------------------------------------------------------------------ */
/* Textures                                                            */
/* ------------------------------------------------------------------ */
function canvasTex(size: number, draw: (c: CanvasRenderingContext2D, s: number) => void) {
  const cv = document.createElement('canvas'); cv.width = cv.height = size;
  const ctx = cv.getContext('2d')!; draw(ctx, size);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
}
export const TEX = {
  glow: canvasTex(128, (c, s) => {
    const g = c.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,255,255,0.6)');
    g.addColorStop(0.6, 'rgba(255,255,255,0.15)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g; c.fillRect(0, 0, s, s);
  }),
  ringGlow: canvasTex(256, (c, s) => {
    const g = c.createRadialGradient(s / 2, s / 2, s * 0.3, s / 2, s / 2, s / 2);
    g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.75, 'rgba(255,255,255,0.9)'); g.addColorStop(0.85, 'rgba(255,255,255,0.4)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g; c.fillRect(0, 0, s, s);
  }),
  lava: canvasTex(256, (c, s) => {
    const g = c.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    g.addColorStop(0, 'rgba(255,230,120,1)'); g.addColorStop(0.4, 'rgba(255,110,20,0.95)'); g.addColorStop(0.8, 'rgba(160,20,0,0.7)'); g.addColorStop(1, 'rgba(40,0,0,0)');
    c.fillStyle = g; c.fillRect(0, 0, s, s);
    for (let i = 0; i < 70; i++) {
      c.strokeStyle = `rgba(30,5,0,${Math.random() * 0.6 + 0.2})`; c.lineWidth = Math.random() * 4 + 1;
      c.beginPath(); let x = Math.random() * s, y = Math.random() * s; c.moveTo(x, y);
      for (let k = 0; k < 5; k++) { x += (Math.random() - 0.5) * 50; y += (Math.random() - 0.5) * 50; c.lineTo(x, y); }
      c.stroke();
    }
  }),
  spiral: canvasTex(1024, (c, s) => {
    c.clearRect(0, 0, s, s);
    const cx = s / 2;
    for (let arm = 0; arm < 5; arm++) {
      for (let i = 0; i < 900; i++) {
        const t = i / 900; const ang = arm * (Math.PI * 2 / 5) + t * 9;
        const r = s * 0.06 + t * s * 0.44;
        const x = cx + Math.cos(ang) * r, y = cx + Math.sin(ang) * r;
        const rad = 10 + t * 60 * Math.random();
        const g = c.createRadialGradient(x, y, 0, x, y, rad);
        const a = 0.12 * (1 - t * 0.6);
        g.addColorStop(0, `rgba(235,240,248,${a})`); g.addColorStop(1, 'rgba(235,240,248,0)');
        c.fillStyle = g; c.fillRect(x - rad, y - rad, rad * 2, rad * 2);
      }
    }
    // dense eyewall
    for (let i = 0; i < 400; i++) {
      const ang = Math.random() * Math.PI * 2, r = s * (0.055 + Math.random() * 0.04);
      const x = cx + Math.cos(ang) * r, y = cx + Math.sin(ang) * r; const rad = 14 + Math.random() * 16;
      const g = c.createRadialGradient(x, y, 0, x, y, rad);
      g.addColorStop(0, 'rgba(250,250,255,0.35)'); g.addColorStop(1, 'rgba(250,250,255,0)');
      c.fillStyle = g; c.fillRect(x - rad, y - rad, rad * 2, rad * 2);
    }
    c.globalCompositeOperation = 'destination-out';
    const e = c.createRadialGradient(cx, cx, 0, cx, cx, s * 0.05);
    e.addColorStop(0, 'rgba(0,0,0,1)'); e.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = e; c.fillRect(0, 0, s, s);
  }),
};

/* ------------------------------------------------------------------ */
/* Shared geometries                                                   */
/* ------------------------------------------------------------------ */
function crescentGeo(segs = 40) {
  const pos: number[] = [], col: number[] = [], idx: number[] = [];
  const arc = Math.PI * 1.1;
  for (let i = 0; i <= segs; i++) {
    const t = i / segs; const a = -arc / 2 + t * arc;
    const thick = Math.sin(t * Math.PI) * 0.28;
    const ro = 1, ri = 1 - thick;
    pos.push(Math.cos(a) * ro, 0, Math.sin(a) * ro, Math.cos(a) * ri, 0, Math.sin(a) * ri);
    const b = Math.pow(Math.sin(t * Math.PI), 0.6);
    col.push(b, b, b, b * 0.25, b * 0.25, b * 0.25);
    if (i < segs) { const k = i * 2; idx.push(k, k + 1, k + 2, k + 2, k + 1, k + 3); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx); return g;
}
function waveGeo() {
  const g = new THREE.PlaneGeometry(1, 1, 24, 10);
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i) + 0.5; // 0..1 height
    const curl = Math.pow(y, 2.2) * 0.55;
    const edge = 1 - Math.pow(Math.abs(x * 2), 4);
    p.setXYZ(i, x, y * edge, curl * edge + Math.sin(x * 20) * 0.02);
  }
  g.computeVertexNormals(); return g;
}
export const GEO = {
  sphere: new THREE.SphereGeometry(1, 28, 18),
  sphereLo: new THREE.SphereGeometry(1, 12, 8),
  ico: new THREE.IcosahedronGeometry(1, 1),
  rock: new THREE.DodecahedronGeometry(1, 0),
  ring: new THREE.RingGeometry(0.86, 1, 72).rotateX(-Math.PI / 2),
  thinRing: new THREE.RingGeometry(0.95, 1, 72).rotateX(-Math.PI / 2),
  disc: new THREE.CircleGeometry(1, 48).rotateX(-Math.PI / 2),
  torus: new THREE.TorusGeometry(1, 0.08, 8, 48).rotateX(Math.PI / 2),
  box: new THREE.BoxGeometry(1, 1, 1),
  cyl: new THREE.CylinderGeometry(1, 1, 1, 24, 1, true),
  cylSolid: new THREE.CylinderGeometry(1, 1, 1, 16),
  cone: new THREE.ConeGeometry(1, 1, 20, 1, true),
  crescent: crescentGeo(),
  wave: waveGeo(),
  plane: new THREE.PlaneGeometry(1, 1),
  octa: new THREE.OctahedronGeometry(1, 0),
};
const SHARED_GEOS = new Set<THREE.BufferGeometry>(Object.values(GEO));

export function glowMat(color: THREE.ColorRepresentation, opacity = 1, tex?: THREE.Texture) {
  return new THREE.MeshBasicMaterial({ color, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, map: tex, side: THREE.DoubleSide, vertexColors: false });
}
const fresnelShader = {
  vertexShader: `varying vec3 vN; varying vec3 vV;
    void main(){ vec4 wp = modelMatrix*vec4(position,1.); vN = normalize(mat3(modelMatrix)*normal); vV = normalize(cameraPosition - wp.xyz); gl_Position = projectionMatrix*viewMatrix*wp; }`,
  fragmentShader: `uniform vec3 uColor; uniform float uOpacity; uniform float uPower; uniform float uBase; varying vec3 vN; varying vec3 vV;
    void main(){ float f = pow(1. - abs(dot(normalize(vN), normalize(vV))), uPower); float a = (f + uBase) * uOpacity; gl_FragColor = vec4(uColor * (0.6 + f), a); }`,
};
export function fresnelMat(color: THREE.ColorRepresentation, opacity = 1, power = 2.2, base = 0.05, additive = true) {
  return new THREE.ShaderMaterial({
    uniforms: { uColor: { value: new THREE.Color(color) }, uOpacity: { value: opacity }, uPower: { value: power }, uBase: { value: base } },
    vertexShader: fresnelShader.vertexShader, fragmentShader: fresnelShader.fragmentShader,
    transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, side: THREE.DoubleSide, toneMapped: false,
  });
}
export function setOpacity(m: THREE.Material, o: number) {
  const sm = m as THREE.ShaderMaterial;
  if (sm.uniforms && sm.uniforms.uOpacity) sm.uniforms.uOpacity.value = o; else (m as THREE.MeshBasicMaterial).opacity = o;
}

/* ------------------------------------------------------------------ */
/* GPU particle pool (single draw call)                                */
/* ------------------------------------------------------------------ */
export class Particles {
  cap: number; points: THREE.Points; geo: THREE.BufferGeometry;
  pos: Float32Array; col: Float32Array; size: Float32Array; alpha: Float32Array;
  vel: Float32Array; life: Float32Array; max: Float32Array; grav: Float32Array; drag: Float32Array; s0: Float32Array; a0: Float32Array; grow: Float32Array;
  cur = 0; mat: THREE.ShaderMaterial; density = 1;
  constructor(scene: THREE.Scene, cap: number, additive: boolean) {
    this.cap = cap;
    this.pos = new Float32Array(cap * 3); this.col = new Float32Array(cap * 3); this.size = new Float32Array(cap); this.alpha = new Float32Array(cap);
    this.vel = new Float32Array(cap * 3); this.life = new Float32Array(cap); this.max = new Float32Array(cap); this.grav = new Float32Array(cap); this.drag = new Float32Array(cap);
    this.s0 = new Float32Array(cap); this.a0 = new Float32Array(cap); this.grow = new Float32Array(cap);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aSize', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aAlpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e7);
    this.geo = g;
    this.mat = new THREE.ShaderMaterial({
      uniforms: { uScale: { value: 600 } },
      vertexShader: `attribute float aSize; attribute float aAlpha; varying vec3 vC; varying float vA; uniform float uScale;
        void main(){ vC = color; vA = aAlpha; vec4 mv = modelViewMatrix*vec4(position,1.); gl_PointSize = aAlpha<=0.001?0.:min(aSize*uScale/max(-mv.z,0.1), 320.); gl_Position = projectionMatrix*mv; }`,
      fragmentShader: additive
        ? `varying vec3 vC; varying float vA; void main(){ float d = length(gl_PointCoord-.5); float a = smoothstep(.5,0.,d); a*=a; gl_FragColor = vec4(vC*a*vA*1.6, a*vA); }`
        : `varying vec3 vC; varying float vA; void main(){ float d = length(gl_PointCoord-.5); float a = smoothstep(.5,.05,d)*vA; if(a<0.01) discard; gl_FragColor = vec4(vC, a); }`,
      vertexColors: true, transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, toneMapped: false,
    });
    this.points = new THREE.Points(g, this.mat); this.points.frustumCulled = false; this.points.renderOrder = additive ? 5 : 4;
    scene.add(this.points);
  }
  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, color: THREE.Color, life: number, size: number, grav = 0, drag = 0, alpha = 1, grow = 0) {
    const i = this.cur; this.cur = (this.cur + 1) % this.cap;
    const i3 = i * 3;
    this.pos[i3] = x; this.pos[i3 + 1] = y; this.pos[i3 + 2] = z;
    this.vel[i3] = vx; this.vel[i3 + 1] = vy; this.vel[i3 + 2] = vz;
    this.col[i3] = color.r; this.col[i3 + 1] = color.g; this.col[i3 + 2] = color.b;
    this.life[i] = life; this.max[i] = life; this.s0[i] = size; this.size[i] = size; this.a0[i] = alpha; this.alpha[i] = alpha;
    this.grav[i] = grav; this.drag[i] = drag; this.grow[i] = grow;
  }
  /** emits n particles scaled by density */
  n(count: number) { return Math.max(1, Math.round(count * this.density)); }
  update(dt: number) {
    const { pos, vel, life, max, alpha, size, grav, drag, s0, a0, grow } = this;
    for (let i = 0; i < this.cap; i++) {
      if (life[i] <= 0) { if (alpha[i] !== 0) alpha[i] = 0; continue; }
      life[i] -= dt;
      const i3 = i * 3;
      const dr = 1 - Math.min(1, drag[i] * dt);
      vel[i3] *= dr; vel[i3 + 1] = vel[i3 + 1] * dr - grav[i] * dt; vel[i3 + 2] *= dr;
      pos[i3] += vel[i3] * dt; pos[i3 + 1] += vel[i3 + 1] * dt; pos[i3 + 2] += vel[i3 + 2] * dt;
      if (pos[i3 + 1] < 0.05 && grav[i] > 0) { pos[i3 + 1] = 0.05; vel[i3 + 1] *= -0.3; vel[i3] *= 0.6; vel[i3 + 2] *= 0.6; }
      const k = Math.max(0, life[i] / max[i]);
      alpha[i] = a0[i] * Math.min(1, k * 2.2);
      size[i] = s0[i] * (1 + grow[i] * (1 - k));
    }
    const a = this.geo.attributes;
    a.position.needsUpdate = true; a.aAlpha.needsUpdate = true; a.aSize.needsUpdate = true; a.color.needsUpdate = true;
  }
}

/* ------------------------------------------------------------------ */
/* Instanced debris (rocks = lit, shards = glowing)                    */
/* ------------------------------------------------------------------ */
export class Debris {
  cap: number; mesh: THREE.InstancedMesh; pos: Float32Array; vel: Float32Array; rot: Float32Array; av: Float32Array; scl: Float32Array; life: Float32Array; max: Float32Array;
  cur = 0; density = 1; bounce: number;
  constructor(scene: THREE.Scene, cap: number, geo: THREE.BufferGeometry, mat: THREE.Material, bounce = 0.35, shadows = true) {
    this.cap = cap; this.bounce = bounce;
    this.mesh = new THREE.InstancedMesh(geo, mat, cap);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.castShadow = shadows; this.mesh.frustumCulled = false;
    this.pos = new Float32Array(cap * 3); this.vel = new Float32Array(cap * 3); this.rot = new Float32Array(cap * 3); this.av = new Float32Array(cap * 3);
    this.scl = new Float32Array(cap); this.life = new Float32Array(cap); this.max = new Float32Array(cap);
    _m.makeScale(0, 0, 0);
    for (let i = 0; i < cap; i++) { this.mesh.setMatrixAt(i, _m); this.mesh.setColorAt(i, _c.set(1, 1, 1)); }
    scene.add(this.mesh);
  }
  n(count: number) { return Math.max(0, Math.round(count * this.density)); }
  emit(p: THREE.Vector3, v: THREE.Vector3, scale: number, color: THREE.ColorRepresentation, life = 4) {
    const i = this.cur; this.cur = (this.cur + 1) % this.cap; const i3 = i * 3;
    this.pos[i3] = p.x; this.pos[i3 + 1] = p.y; this.pos[i3 + 2] = p.z;
    this.vel[i3] = v.x; this.vel[i3 + 1] = v.y; this.vel[i3 + 2] = v.z;
    this.rot[i3] = Math.random() * 6; this.rot[i3 + 1] = Math.random() * 6; this.rot[i3 + 2] = Math.random() * 6;
    this.av[i3] = rand(-8, 8); this.av[i3 + 1] = rand(-8, 8); this.av[i3 + 2] = rand(-8, 8);
    this.scl[i] = scale; this.life[i] = life; this.max[i] = life;
    this.mesh.setColorAt(i, _c.set(color));
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }
  update(dt: number) {
    const e = new THREE.Euler();
    let any = false;
    for (let i = 0; i < this.cap; i++) {
      if (this.life[i] <= 0) { if (this.scl[i] !== 0) { this.scl[i] = 0; _m.makeScale(0, 0, 0); this.mesh.setMatrixAt(i, _m); any = true; } continue; }
      any = true;
      this.life[i] -= dt; const i3 = i * 3;
      this.vel[i3 + 1] -= 30 * dt;
      this.pos[i3] += this.vel[i3] * dt; this.pos[i3 + 1] += this.vel[i3 + 1] * dt; this.pos[i3 + 2] += this.vel[i3 + 2] * dt;
      const s = this.scl[i] * Math.min(1, this.life[i] / Math.min(0.6, this.max[i]));
      if (this.pos[i3 + 1] < s * 0.6) {
        this.pos[i3 + 1] = s * 0.6; this.vel[i3 + 1] *= -this.bounce; this.vel[i3] *= 0.7; this.vel[i3 + 2] *= 0.7;
        this.av[i3] *= 0.7; this.av[i3 + 1] *= 0.7; this.av[i3 + 2] *= 0.7;
      }
      this.rot[i3] += this.av[i3] * dt; this.rot[i3 + 1] += this.av[i3 + 1] * dt; this.rot[i3 + 2] += this.av[i3 + 2] * dt;
      e.set(this.rot[i3], this.rot[i3 + 1], this.rot[i3 + 2]); _q.setFromEuler(e);
      _a.set(this.pos[i3], this.pos[i3 + 1], this.pos[i3 + 2]); _sc.set(s, s * 0.8, s * 1.1);
      _m.compose(_a, _q, _sc); this.mesh.setMatrixAt(i, _m);
    }
    if (any) this.mesh.instanceMatrix.needsUpdate = true;
  }
}

/* ------------------------------------------------------------------ */
/* Lightning bolt: one buffer allocated per bolt, re-jittered in-place */
/* every 0.01s (no reallocation => low GC / low lag)                   */
/* ------------------------------------------------------------------ */
export interface BoltOpts {
  color?: THREE.ColorRepresentation; core?: THREE.ColorRepresentation; width?: number; life?: number; segs?: number;
  jag?: number; branches?: number; flat?: boolean; rate?: number; follow?: () => THREE.Vector3 | null; fadeIn?: number;
}
export class Bolt {
  from = new THREE.Vector3(); to = new THREE.Vector3();
  segs: number; nb: number; bl = 5; jag: number; width: number; life: number; t = 0; acc = 0; rate: number; flat: boolean;
  pts: Float32Array; brDir: Float32Array; brStart: Int32Array;
  core: THREE.Mesh; glow: THREE.Mesh | null; gCore: THREE.BufferGeometry; gGlow: THREE.BufferGeometry | null;
  cPos: Float32Array; gPos: Float32Array | null; nSeg: number;
  follow?: () => THREE.Vector3 | null; dead = false;
  constructor(scene: THREE.Scene, from: THREE.Vector3, to: THREE.Vector3, o: BoltOpts, glowOn: boolean) {
    this.from.copy(from); this.to.copy(to);
    const len = from.distanceTo(to);
    this.segs = o.segs ?? Math.max(8, Math.min(40, Math.round(len / 3)));
    this.nb = o.branches ?? 3; this.jag = o.jag ?? Math.max(0.6, len * 0.045); this.width = o.width ?? 1;
    this.life = o.life ?? 0.35; this.rate = o.rate ?? 0.01; this.flat = !!o.flat; this.follow = o.follow;
    this.nSeg = this.segs + this.nb * this.bl;
    this.pts = new Float32Array((this.segs + 1 + this.nb * (this.bl + 1)) * 3);
    this.brDir = new Float32Array(this.nb * 3); this.brStart = new Int32Array(this.nb);
    const idx = new Uint32Array(this.nSeg * 6);
    for (let s = 0; s < this.nSeg; s++) { const k = s * 4; idx.set([k, k + 1, k + 2, k + 2, k + 1, k + 3], s * 6); }
    const mk = (arr: Float32Array) => { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(arr, 3).setUsage(THREE.DynamicDrawUsage)); g.setIndex(new THREE.BufferAttribute(idx, 1)); g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6); return g; };
    this.cPos = new Float32Array(this.nSeg * 12); this.gCore = mk(this.cPos);
    this.core = new THREE.Mesh(this.gCore, new THREE.MeshBasicMaterial({ color: o.core ?? 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, side: THREE.DoubleSide }));
    this.core.frustumCulled = false; this.core.renderOrder = 7; scene.add(this.core);
    if (glowOn) {
      this.gPos = new Float32Array(this.nSeg * 12); this.gGlow = mk(this.gPos);
      this.glow = new THREE.Mesh(this.gGlow, new THREE.MeshBasicMaterial({ color: o.color ?? 0x88ccff, transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, side: THREE.DoubleSide }));
      this.glow.frustumCulled = false; this.glow.renderOrder = 6; scene.add(this.glow);
    } else { this.gPos = null; this.gGlow = null; this.glow = null; (this.core.material as THREE.MeshBasicMaterial).color.set(o.color ?? 0x88ccff).lerp(new THREE.Color(1, 1, 1), 0.5); }
    this.jitter();
  }
  jitter() {
    const { pts, segs, from, to, jag } = this;
    _d.subVectors(to, from); const len = _d.length(); _d.normalize();
    const u = _a.crossVectors(_d, Math.abs(_d.y) > 0.9 ? _s.set(1, 0, 0) : UP).normalize();
    const w = _b.crossVectors(_d, u).normalize();
    let ou = 0, ow = 0;
    for (let i = 0; i <= segs; i++) {
      const t = i / segs; const env = Math.sin(Math.PI * t);
      ou = ou * 0.45 + (Math.random() - 0.5) * 2 * jag; ow = this.flat ? 0 : ow * 0.45 + (Math.random() - 0.5) * 2 * jag;
      const e = i === 0 || i === segs ? 0 : Math.max(env, 0.35);
      pts[i * 3] = from.x + _d.x * len * t + (u.x * ou + w.x * ow) * e;
      pts[i * 3 + 1] = from.y + _d.y * len * t + (u.y * ou + w.y * ow) * e;
      pts[i * 3 + 2] = from.z + _d.z * len * t + (u.z * ou + w.z * ow) * e;
    }
    let o = (segs + 1) * 3;
    for (let b = 0; b < this.nb; b++) {
      const si = 1 + Math.floor(Math.random() * (segs - 2)); this.brStart[b] = si;
      let x = pts[si * 3], y = pts[si * 3 + 1], z = pts[si * 3 + 2];
      const bl = len * rand(0.1, 0.25) / this.bl;
      let dx = _d.x + (Math.random() - 0.5) * 1.6, dy = _d.y + (Math.random() - 0.5) * 1.6, dz = _d.z + (Math.random() - 0.5) * 1.6;
      if (this.flat) dy = 0;
      const dl = Math.hypot(dx, dy, dz) || 1; dx /= dl; dy /= dl; dz /= dl;
      for (let k = 0; k <= this.bl; k++) {
        pts[o++] = x; pts[o++] = y; pts[o++] = z;
        x += dx * bl + (Math.random() - 0.5) * jag; y += this.flat ? 0 : dy * bl + (Math.random() - 0.5) * jag; z += dz * bl + (Math.random() - 0.5) * jag;
      }
    }
  }
  private ribbon(arr: Float32Array, wMul: number, cam: THREE.Vector3) {
    const { pts, segs } = this; let o = 0;
    const seg = (ia: number, ib: number, w: number) => {
      _a.set(pts[ia], pts[ia + 1], pts[ia + 2]); _b.set(pts[ib], pts[ib + 1], pts[ib + 2]);
      _d.subVectors(_b, _a);
      if (this.flat) _s.crossVectors(_d, UP); else { _vw.subVectors(cam, _a); _s.crossVectors(_d, _vw); }
      _s.normalize().multiplyScalar(w);
      _d.multiplyScalar(0.08); _a.sub(_d); _b.add(_d);
      arr[o++] = _a.x + _s.x; arr[o++] = _a.y + _s.y; arr[o++] = _a.z + _s.z;
      arr[o++] = _a.x - _s.x; arr[o++] = _a.y - _s.y; arr[o++] = _a.z - _s.z;
      arr[o++] = _b.x + _s.x; arr[o++] = _b.y + _s.y; arr[o++] = _b.z + _s.z;
      arr[o++] = _b.x - _s.x; arr[o++] = _b.y - _s.y; arr[o++] = _b.z - _s.z;
    };
    const W = this.width * wMul;
    for (let i = 0; i < segs; i++) seg(i * 3, (i + 1) * 3, W * (1 - 0.5 * i / segs));
    let base = segs + 1;
    for (let b = 0; b < this.nb; b++) {
      for (let k = 0; k < this.bl; k++) seg((base + k) * 3, (base + k + 1) * 3, W * 0.45 * (1 - k / this.bl));
      base += this.bl + 1;
    }
  }
  update(dt: number, cam: THREE.Vector3) {
    this.t += dt; this.acc += dt;
    if (this.follow) { const p = this.follow(); if (p) { _d.subVectors(this.to, this.from); this.to.copy(p); this.from.copy(p).sub(_d); } }
    if (this.acc >= this.rate) { this.acc = 0; this.jitter(); } // segment re-rotation @ 0.01s
    this.ribbon(this.cPos, 0.22, cam); this.gCore.attributes.position.needsUpdate = true;
    if (this.gPos && this.gGlow) { this.ribbon(this.gPos, 1.5, cam); this.gGlow.attributes.position.needsUpdate = true; }
    const k = 1 - this.t / this.life;
    const flick = 0.55 + Math.random() * 0.45;
    (this.core.material as THREE.MeshBasicMaterial).opacity = Math.max(0, k * flick * 1.2);
    if (this.glow) (this.glow.material as THREE.MeshBasicMaterial).opacity = Math.max(0, k * flick * 0.5);
    return this.t < this.life;
  }
  dispose(scene: THREE.Scene) {
    scene.remove(this.core); this.gCore.dispose(); (this.core.material as THREE.Material).dispose();
    if (this.glow && this.gGlow) { scene.remove(this.glow); this.gGlow.dispose(); (this.glow.material as THREE.Material).dispose(); }
  }
}

/* ------------------------------------------------------------------ */
/* Transients: any mesh with a lifetime + custom update                */
/* ------------------------------------------------------------------ */
export interface Transient { obj: THREE.Object3D; life: number; t: number; upd?: (o: THREE.Object3D, k: number, dt: number, t: number) => void; }

export class FX {
  scene: THREE.Scene; camera: THREE.Camera;
  sparks: Particles; smoke: Particles; rocks: Debris; shards: Debris;
  bolts: Bolt[] = []; trans: Transient[] = []; lights: { l: THREE.PointLight; t: number; d: number; i: number }[] = [];
  boltGlow = true; lightFlashes = true; maxBolts = 260;
  onShake: (p: THREE.Vector3, intensity: number, dur: number) => void = () => { };
  constructor(scene: THREE.Scene, camera: THREE.Camera) {
    this.scene = scene; this.camera = camera;
    this.sparks = new Particles(scene, 24000, true);
    this.smoke = new Particles(scene, 9000, false);
    this.rocks = new Debris(scene, 2600, GEO.rock, new THREE.MeshStandardMaterial({ roughness: 0.85, metalness: 0.05, flatShading: true }), 0.35);
    this.shards = new Debris(scene, 2200, GEO.octa, new THREE.MeshBasicMaterial({ toneMapped: false }), 0.25, false);
    for (let i = 0; i < 6; i++) { const l = new THREE.PointLight(0xffffff, 0, 60, 1.6); scene.add(l); this.lights.push({ l, t: 0, d: 1, i: 0 }); }
  }
  add(obj: THREE.Object3D, life: number, upd?: Transient['upd']) { this.scene.add(obj); this.trans.push({ obj, life, t: 0, upd }); return obj; }
  mesh(geo: THREE.BufferGeometry, mat: THREE.Material, pos: THREE.Vector3, scale = 1) { const m = new THREE.Mesh(geo, mat); m.position.copy(pos); m.scale.setScalar(scale); return m; }

  flash(p: THREE.Vector3, color: THREE.ColorRepresentation, intensity = 40, dist = 60, dur = 0.25) {
    if (!this.lightFlashes) return;
    let best = this.lights[0];
    for (const L of this.lights) if (L.t >= L.d || L.l.intensity < best.l.intensity) best = L;
    best.l.position.copy(p); best.l.color.set(color); best.l.distance = dist; best.i = intensity * 30; best.t = 0; best.d = dur; best.l.intensity = best.i;
  }

  bolt(from: THREE.Vector3, to: THREE.Vector3, o: BoltOpts = {}) {
    if (this.bolts.length >= this.maxBolts) { const old = this.bolts.shift()!; old.dispose(this.scene); }
    const b = new Bolt(this.scene, from, to, o, this.boltGlow); this.bolts.push(b); return b;
  }
  /** tall vertical jagged strike with N overlapped bolts */
  strike(p: THREE.Vector3, o: { color?: THREE.ColorRepresentation; core?: THREE.ColorRepresentation; height?: number; overlap?: number; width?: number; life?: number; radius?: number; sparks?: number; ring?: boolean; light?: boolean } = {}) {
    const h = o.height ?? rand(70, 120); const ov = o.overlap ?? 3; const col = new THREE.Color(o.color ?? 0x9fd8ff);
    for (let i = 0; i < ov; i++) {
      const top = _a.set(p.x + rand(-6, 6), p.y + h, p.z + rand(-6, 6)).clone();
      const bot = _b.set(p.x + rand(-0.6, 0.6), p.y, p.z + rand(-0.6, 0.6)).clone();
      this.bolt(top, bot, { color: col, core: o.core, width: (o.width ?? 1.2) * rand(0.7, 1.2), life: (o.life ?? 0.4) * rand(0.8, 1.2), branches: 4, segs: 30 });
    }
    const r = o.radius ?? 4;
    this.disc(p, r * 1.4, col, 0.45);
    if (o.ring !== false) this.ring(p, r * 0.3, r * 1.3, col, 0.35);
    const sp = this.sparks.n(o.sparks ?? 30);
    for (let i = 0; i < sp; i++) { const a = Math.random() * 6.28, s = rand(8, 30); this.sparks.emit(p.x, p.y + 0.3, p.z, Math.cos(a) * s, rand(5, 25), Math.sin(a) * s, col, rand(0.3, 0.8), rand(0.3, 0.7), 30, 1.5); }
    if (o.light !== false) this.flash(_a.set(p.x, p.y + 6, p.z), col, 60, r * 12 + 30, 0.2);
  }
  disc(p: THREE.Vector3, r: number, color: THREE.ColorRepresentation, life = 0.5, opts: { tex?: THREE.Texture; grow?: number; y?: number; op?: number } = {}) {
    const m = this.mesh(GEO.disc, glowMat(color, opts.op ?? 0.9, opts.tex ?? TEX.glow), p, r);
    m.position.y = (opts.y ?? 0.08) + Math.random() * 0.02; m.renderOrder = 3;
    const g = opts.grow ?? 0.2;
    this.add(m, life, (o, k) => { o.scale.setScalar(r * (1 + g * (1 - k))); setOpacity((o as THREE.Mesh).material as THREE.Material, (opts.op ?? 0.9) * k); });
    return m;
  }
  ring(p: THREE.Vector3, r0: number, r1: number, color: THREE.ColorRepresentation, life = 0.5, opts: { y?: number; thin?: boolean; op?: number; tilt?: THREE.Euler } = {}) {
    const m = this.mesh(opts.thin ? GEO.thinRing : GEO.ring, glowMat(color, opts.op ?? 1), p, r0);
    m.position.y = p.y + (opts.y ?? 0.15); if (opts.tilt) m.rotation.copy(opts.tilt);
    this.add(m, life, (o, k) => { const e = 1 - Math.pow(k, 2.2); o.scale.setScalar(r0 + (r1 - r0) * e); setOpacity((o as THREE.Mesh).material as THREE.Material, (opts.op ?? 1) * k); });
    return m;
  }
  shell(p: THREE.Vector3, r0: number, r1: number, color: THREE.ColorRepresentation, life = 0.6, opts: { power?: number; op?: number; additive?: boolean; flatten?: number; base?: number } = {}) {
    const m = this.mesh(GEO.sphere, fresnelMat(color, opts.op ?? 1, opts.power ?? 2.2, opts.base ?? 0.05, opts.additive ?? true), p, r0);
    const fl = opts.flatten ?? 1;
    this.add(m, life, (o, k) => { const e = 1 - Math.pow(k, 3); const s = r0 + (r1 - r0) * e; o.scale.set(s, s * fl, s); setOpacity((o as THREE.Mesh).material as THREE.Material, (opts.op ?? 1) * Math.pow(k, 0.8)); });
    return m;
  }
  burstSparks(p: THREE.Vector3, n: number, color: THREE.ColorRepresentation, speed: number, life = 0.8, size = 0.6, grav = 20, up = 0.6) {
    const c = new THREE.Color(color); const N = this.sparks.n(n);
    for (let i = 0; i < N; i++) {
      const a = Math.random() * 6.283, e = Math.acos(rand(-1, 1)) ; const s = speed * rand(0.3, 1);
      const sx = Math.sin(e) * Math.cos(a), sz = Math.sin(e) * Math.sin(a), sy = Math.abs(Math.cos(e)) * up + (1 - up) * Math.cos(e);
      this.sparks.emit(p.x, p.y, p.z, sx * s, sy * s, sz * s, c, life * rand(0.5, 1.2), size * rand(0.6, 1.4), grav, 1.2);
    }
  }
  puff(p: THREE.Vector3, n: number, color: THREE.ColorRepresentation, spread: number, life = 2, size = 4, rise = 3, alpha = 0.55) {
    const c = new THREE.Color(color); const N = this.smoke.n(n);
    for (let i = 0; i < N; i++) {
      const a = Math.random() * 6.283, r = Math.random() * spread;
      this.smoke.emit(p.x + Math.cos(a) * r, p.y + rand(0, spread * 0.3), p.z + Math.sin(a) * r, Math.cos(a) * rand(1, 4), rise * rand(0.5, 1.5), Math.sin(a) * rand(1, 4), c, life * rand(0.6, 1.3), size * rand(0.7, 1.3), -0.5, 0.8, alpha, 1.4);
    }
  }
  debris(p: THREE.Vector3, n: number, color: THREE.ColorRepresentation, speed: number, size = 0.8, life = 4, shards = false) {
    const sys = shards ? this.shards : this.rocks; const N = sys.n(n); const c = new THREE.Color(color);
    for (let i = 0; i < N; i++) {
      const a = Math.random() * 6.283; const s = speed * rand(0.3, 1);
      const cc = c.clone().multiplyScalar(rand(0.6, 1.2));
      sys.emit(_a.set(p.x + rand(-1, 1), p.y + rand(0, 1), p.z + rand(-1, 1)), _b.set(Math.cos(a) * s, rand(0.5, 1.4) * speed, Math.sin(a) * s), size * rand(0.4, 1.4), cc, life * rand(0.7, 1.2));
    }
  }
  /** full explosion: flash core, fresnel shell, ground ring, sparks, smoke, debris, light, shake */
  explosion(p: THREE.Vector3, r: number, o: { core?: THREE.ColorRepresentation; edge?: THREE.ColorRepresentation; smoke?: THREE.ColorRepresentation | null; debris?: number; debrisColor?: THREE.ColorRepresentation; shards?: number; shardColor?: THREE.ColorRepresentation; sparks?: number; shake?: number; dur?: number; ring?: boolean; light?: boolean; flatten?: number } = {}) {
    const core = o.core ?? 0xffd27a, edge = o.edge ?? 0xff5a1a, dur = o.dur ?? Math.min(1.6, 0.5 + r * 0.02);
    const cm = this.mesh(GEO.sphereLo, glowMat(core, 1), p, r * 0.15);
    this.add(cm, dur * 0.55, (m, k) => { m.scale.setScalar(r * (0.15 + 0.75 * (1 - k * k))); setOpacity((m as THREE.Mesh).material as THREE.Material, k); });
    this.shell(p, r * 0.3, r * 1.05, edge, dur, { power: 1.8, op: 1, flatten: o.flatten ?? 0.8 });
    if (o.ring !== false) { this.ring(p, r * 0.2, r * 1.35, edge, dur * 0.9); this.disc(p, r * 1.1, core, dur * 1.2, { op: 0.7 }); }
    this.burstSparks(_a.set(p.x, p.y + 0.5, p.z).clone(), o.sparks ?? Math.min(160, 30 + r * 3), core, Math.min(160, 12 + r * 2.2), 0.9, Math.min(4, 0.4 + r * 0.03));
    if (o.smoke !== null) this.puff(p, Math.min(60, 8 + r), o.smoke ?? 0x2a2522, r * 0.5, 2.5, Math.min(40, 2 + r * 0.35), Math.min(20, 2 + r * 0.15));
    if (o.debris) this.debris(p, o.debris, o.debrisColor ?? 0x4a3d34, Math.min(90, 10 + r * 1.1), Math.min(4, 0.35 + r * 0.03));
    if (o.shards) this.debris(p, o.shards, o.shardColor ?? core, Math.min(110, 14 + r * 1.3), Math.min(3, 0.25 + r * 0.02), 2.5, true);
    if (o.light !== false) this.flash(_a.set(p.x, p.y + Math.min(20, r * 0.4), p.z), edge, 80, r * 5 + 40, dur * 0.5);
    if (o.shake) this.onShake(p, o.shake, Math.min(1.5, 0.3 + r * 0.01));
  }
  update(dt: number) {
    const cam = this.camera.position;
    this.sparks.update(dt); this.smoke.update(dt); this.rocks.update(dt); this.shards.update(dt);
    for (let i = this.bolts.length - 1; i >= 0; i--) { const b = this.bolts[i]; if (!b.update(dt, cam) || b.dead) { b.dispose(this.scene); this.bolts.splice(i, 1); } }
    for (let i = this.trans.length - 1; i >= 0; i--) {
      const t = this.trans[i]; t.t += dt; const k = Math.max(0, 1 - t.t / t.life);
      if (t.upd) t.upd(t.obj, k, dt, t.t);
      if (t.t >= t.life) { this.scene.remove(t.obj); disposeObj(t.obj); this.trans.splice(i, 1); }
    }
    for (const L of this.lights) { if (L.t < L.d) { L.t += dt; L.l.intensity = L.i * Math.max(0, 1 - L.t / L.d); } else L.l.intensity = 0; }
  }
}
export function disposeObj(o: THREE.Object3D) {
  o.traverse((c) => {
    const m = c as THREE.Mesh;
    if (m.geometry && !SHARED_GEOS.has(m.geometry)) m.geometry.dispose();
    if (m.material) { const mats = Array.isArray(m.material) ? m.material : [m.material]; for (const mt of mats) if (!(mt as any).__shared) mt.dispose(); }
  });
}
export function sharedMat<T extends THREE.Material>(m: T): T { (m as any).__shared = true; return m; }
