import type { Game } from './Game';

export type ItemKind = 'fruit' | 'sword';

export interface SkillState {
  cdEnd: number;       // game time when cooldown ends
  cdTotal: number;     // total cooldown of current cycle (for 100->0 bar)
  holding: boolean;
  charges: number;
  chargeTimer: number;
  data: any;
}

export interface SkillDef {
  name: string;
  cd: number;
  hold?: boolean;
  /** return false to cancel (no cooldown applied). return 'hold' handled via hold flag */
  cast: (g: Game, s: SkillState) => void | boolean;
  /** for hold skills: called every frame while held. return false to auto release */
  holdTick?: (g: Game, s: SkillState, dt: number) => boolean;
  release?: (g: Game, s: SkillState) => void;
  charges?: { max: number; regen: number; interval: number };
  /** multiplier on cooldown (dynamic) */
  cdMul?: (g: Game) => number;
  /** extra text shown in the panel row */
  extra?: (g: Game, s: SkillState) => string;
  /** special UI controls */
  ui?: 'supercell';
}

export interface M1Def {
  interval: number;
  endLag?: number;
  comboLen?: number;
  manual?: boolean; // guns: must click for each shot
  fn: (g: Game, combo: number) => void;
}

export interface ItemDef {
  id: string;
  name: string;
  kind: ItemKind;
  color: string;
  glyph: string;
  passive?: string;
  m1?: M1Def;
  skills: SkillDef[];
  onEquip?: (g: Game) => void;
  onUnequip?: (g: Game) => void;
}

export interface GraphicsSettings {
  preset: 'low' | 'medium' | 'high' | 'ultra' | 'custom';
  renderScale: number;
  shadows: boolean;
  shadowRes: number;
  bloom: boolean;
  bloomStrength: number;
  antialias: boolean;
  particleDensity: number;
  debrisDensity: number;
  fog: boolean;
  drawDistance: number;
  exposure: number;
  fov: number;
  shakeScale: number;
  damageNumbers: boolean;
  showFps: boolean;
  enemyCount: number;
  lightFlashes: boolean;
  touchControls: 'auto' | 'on' | 'off';
  boltGlow: boolean;
}

export const DEFAULT_SETTINGS: GraphicsSettings = {
  preset: 'high',
  renderScale: 1,
  shadows: true,
  shadowRes: 2048,
  bloom: true,
  bloomStrength: 0.9,
  antialias: true,
  particleDensity: 1,
  debrisDensity: 1,
  fog: true,
  drawDistance: 4000,
  exposure: 1.05,
  fov: 62,
  shakeScale: 1,
  damageNumbers: true,
  showFps: true,
  enemyCount: 40,
  lightFlashes: true,
  touchControls: 'auto',
  boltGlow: true,
};

export const PRESETS: Record<string, Partial<GraphicsSettings>> = {
  low: { renderScale: 0.6, shadows: false, bloom: false, antialias: false, particleDensity: 0.35, debrisDensity: 0.3, fog: true, drawDistance: 1500, lightFlashes: false, boltGlow: false, enemyCount: 25 },
  medium: { renderScale: 0.8, shadows: true, shadowRes: 1024, bloom: true, bloomStrength: 0.7, antialias: false, particleDensity: 0.65, debrisDensity: 0.6, drawDistance: 2500, lightFlashes: true, boltGlow: true, enemyCount: 35 },
  high: { renderScale: 1, shadows: true, shadowRes: 2048, bloom: true, bloomStrength: 0.9, antialias: true, particleDensity: 1, debrisDensity: 1, drawDistance: 4000, lightFlashes: true, boltGlow: true, enemyCount: 40 },
  ultra: { renderScale: 1.25, shadows: true, shadowRes: 4096, bloom: true, bloomStrength: 1.05, antialias: true, particleDensity: 1.5, debrisDensity: 1.5, drawDistance: 8000, lightFlashes: true, boltGlow: true, enemyCount: 60 },
};

export const SKILL_KEYS = ['Z', 'X', 'C', 'V', 'B', 'F', 'G', 'N', 'M', 'L', 'K', 'J'];
