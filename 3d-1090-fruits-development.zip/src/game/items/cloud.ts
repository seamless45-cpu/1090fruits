import * as THREE from 'three';
import type { ItemDef } from '../types';
import type { Game } from '../Game';
import type { Enemy } from '../Enemies';
import { GEO, TEX, glowMat, fresnelMat, rand, disposeObj, setOpacity } from '../Effects';
import { B, V, randAround } from '../kit';

type Layout = 'cell' | 'stratus' | 'nimbo' | 'line' | 'bow';
interface CellOpts {
  pos: THREE.Vector3; layout: Layout; r: number; base: number; life: number; grow: number; supercell?: boolean;
  rain?: number; rainStart?: number; lightning?: number; superChance?: number; superMul?: number; hail?: number; hailSize?: number; hailDmg?: number; shatter?: [number, number];
  tornado?: boolean; dmgMul?: number; vel?: THREE.Vector3; length?: number; wind?: { speed: number; depth: number; shake?: boolean }; dark?: number; color?: number; dir?: THREE.Vector3;
}
interface Puff { x: number; y: number; z: number; sx: number; sy: number; sz: number; th: number; wall?: boolean }

const cells: Cell[] = []; const MAX_CELLS = 46;
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3(), _c = new THREE.Color();

/* ------------------------------------------------------------------ hail pool */
class Hail {
  im: THREE.InstancedMesh; cap = 900; pos: THREE.Vector3[] = []; vel: THREE.Vector3[] = []; size: number[] = []; dmg: number[] = []; sh: [number, number][] = []; alive: boolean[] = []; cur = 0; g: Game;
  constructor(g: Game) {
    this.g = g; this.im = new THREE.InstancedMesh(GEO.ico, new THREE.MeshStandardMaterial({ color: 0xe8f6ff, roughness: 0.2, metalness: 0.1, emissive: 0x335566, emissiveIntensity: 0.4 }), this.cap);
    this.im.frustumCulled = false; this.im.castShadow = true; _m.makeScale(0, 0, 0);
    for (let i = 0; i < this.cap; i++) { this.im.setMatrixAt(i, _m); this.pos.push(new THREE.Vector3()); this.vel.push(new THREE.Vector3()); this.size.push(0); this.dmg.push(0); this.sh.push([0, 0]); this.alive.push(false); }
    g.scene.add(this.im);
  }
  add(p: THREE.Vector3, size: number, dmg: number, sh: [number, number]) { const i = this.cur; this.cur = (this.cur + 1) % this.cap; this.pos[i].copy(p); this.vel[i].set(rand(-3, 3), -rand(30, 45), rand(-3, 3)); this.size[i] = size; this.dmg[i] = dmg; this.sh[i] = sh; this.alive[i] = true; }
  update(dt: number) {
    const g = this.g; let any = false;
    for (let i = 0; i < this.cap; i++) {
      if (!this.alive[i]) continue; any = true;
      const p = this.pos[i]; p.addScaledVector(this.vel[i], dt);
      if (p.y <= this.size[i]) {
        this.alive[i] = false; _m.makeScale(0, 0, 0); this.im.setMatrixAt(i, _m); p.y = 0.1;
        g.dmgArea(p, 2.2 + this.size[i], this.dmg[i], { small: true, color: '#dff6ff' });
        if (Math.random() < this.sh[i][0]) { g.fx.debris(p, 5, 0xdff6ff, 6, this.size[i] * 0.4, 1.2, true); g.dmgArea(p, 4.5, this.dmg[i] * this.sh[i][1], { small: true, color: '#bfe8ff' }); }
        else if (Math.random() < 0.3) g.fx.burstSparks(p, 3, 0xdff6ff, 4, 0.3, 0.3);
        continue;
      }
      _s.setScalar(this.size[i]); _m.compose(p, _q.identity(), _s); this.im.setMatrixAt(i, _m);
    }
    if (any) this.im.instanceMatrix.needsUpdate = true;
  }
}
let hail: Hail | null = null; let hailGame: Game | null = null;
function ensureHail(g: Game) { if (!hail || hailGame !== g) { hail = new Hail(g); hailGame = g; g.task((dt) => { hail!.update(dt); return hailGame === g; }); } return hail; }

/* ------------------------------------------------------------------ tornado */
function tornado(g: Game, cell: Cell, dur: number, strength = 1) {
  const pts: THREE.Vector2[] = []; const H = cell.o.base;
  for (let i = 0; i <= 20; i++) { const t = i / 20; pts.push(new THREE.Vector2(1.5 + Math.pow(t, 2.4) * 16 * strength, t * H)); }
  const geo = new THREE.LatheGeometry(pts, 28, 0, Math.PI * 2);
  const grp = new THREE.Group();
  const outer = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ color: 0x6a6660, transparent: true, opacity: 0.6, side: THREE.DoubleSide, depthWrite: false })); grp.add(outer);
  const inner = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ color: 0x4a4640, transparent: true, opacity: 0.5, side: THREE.DoubleSide, depthWrite: false })); inner.scale.set(0.7, 1, 0.7); grp.add(inner);
  g.scene.add(grp); const off = V(); let wa = Math.random() * 6; const dc = new THREE.Color(0x5a4a3a); let acc = 0;
  g.task((dt, t) => {
    if (!cell.alive) t = dur;
    wa += dt * 0.4; off.set(Math.cos(wa) * cell.o.r * 0.4, 0, Math.sin(wa * 1.3) * cell.o.r * 0.4);
    grp.position.set(cell.grp.position.x + off.x, 0, cell.grp.position.z + off.z);
    outer.rotation.y += dt * 6; inner.rotation.y -= dt * 9;
    const k = Math.min(1, t / 1.5, (dur - t) / 1.5); grp.scale.set(Math.max(0.01, k), 1, Math.max(0.01, k));
    (outer.material as THREE.MeshLambertMaterial).opacity = 0.6 * k;
    const bp = grp.position;
    for (let i = 0; i < g.fx.smoke.n(8); i++) { const a = Math.random() * 6.28, rr = rand(2, 10) * strength; g.fx.smoke.emit(bp.x + Math.cos(a) * rr, rand(0, 6), bp.z + Math.sin(a) * rr, -Math.sin(a) * 25, rand(6, 20), Math.cos(a) * 25, dc, rand(0.6, 1.4), rand(2, 5), 0, 0.5, 0.6, 1.5); }
    if (Math.random() < 0.4) g.fx.debris(bp, 1, 0x4a3d34, 18, 0.5, 2);
    acc += dt;
    for (const e of g.enemies.inRadius(bp, 45 * strength, [])) {
      const d = bp.clone().sub(e.pos).setY(0); const L = d.length() || 1; d.divideScalar(L);
      e.pos.addScaledVector(d, Math.min(L, 12 * dt)); e.pos.x += -d.z * 16 * dt; e.pos.z += d.x * 16 * dt;
      if (L < 9 * strength) { e.lift(0.3, 8 + Math.sin(t * 3 + e.id) * 6); if (acc > 0.1) g.dmg(e, B * 0.5 * cell.o.dmgMul!, { small: true }); }
    }
    if (acc > 0.1) acc = 0;
    if (Math.hypot(bp.x - g.player.pos.x, bp.z - g.player.pos.z) < 60) g.shake(bp, 1.5, 0.1);
    if (t >= dur) { g.scene.remove(grp); geo.dispose(); disposeObj(grp); return false; }
  });
}

/* ------------------------------------------------------------------ cell */
class Cell {
  g: Game; o: Required<Pick<CellOpts, 'r' | 'base' | 'life' | 'grow'>> & CellOpts; grp = new THREE.Group(); im: THREE.InstancedMesh; mat: THREE.MeshLambertMaterial; puffs: Puff[] = [];
  t = 0; growth = 0; alive = true; dead = false; fadeOut = 0; rot = 0;
  rain: THREE.LineSegments | null = null; rArr: Float32Array | null = null; rN = 0; rainAcc = 0; dmgAcc = 0; lastGrowUpd = -1; tornados = 0; tornadoAcc = 0;
  constructor(g: Game, o: CellOpts) {
    this.g = g; this.o = { dmgMul: 1, ...o } as any;
    this.buildPuffs();
    this.mat = new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.97, emissive: 0x111418 });
    this.im = new THREE.InstancedMesh(GEO.sphereLo, this.mat, this.puffs.length); this.im.frustumCulled = false; this.im.castShadow = false;
    const dark = o.dark ?? 0;
    this.puffs.forEach((p, i) => { const h = THREE.MathUtils.clamp((p.y + o.r * 0.2) / (o.r * 2), 0, 1); const b = (0.45 + h * 0.55) * (1 - dark * 0.55); _c.setRGB(b, b, b * 1.04); if (o.color) _c.multiply(new THREE.Color(o.color)); this.im.setColorAt(i, _c); });
    this.grp.add(this.im); this.grp.position.copy(o.pos).setY(o.base); g.scene.add(this.grp);
    this.updatePuffs();
    cells.push(this);
    while (cells.filter((c) => c.alive).length > MAX_CELLS) { const old = cells.find((c) => c.alive); if (old) old.kill(); else break; }
    g.clouds = cells.filter((c) => c.alive).length;
  }
  buildPuffs() {
    const { r, layout } = this.o; const P = this.puffs;
    const add = (x: number, y: number, z: number, sx: number, sy: number, sz: number, th: number, wall = false) => P.push({ x, y, z, sx, sy, sz, th, wall });
    if (layout === 'cell') {
      for (let i = 0; i < 12; i++) { const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * r * 0.7; const s = r * rand(0.28, 0.42); add(Math.cos(a) * d, rand(0, r * 0.1), Math.sin(a) * d, s, s * 0.5, s, i < 4 ? 0 : rand(0, 0.15)); }
      for (let i = 0; i < 16; i++) { const k = i / 16; const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * r * 0.42 * (1 - k * 0.4); const s = r * rand(0.25, 0.38); add(Math.cos(a) * d, r * (0.25 + k * 1.45), Math.sin(a) * d, s, s * 0.85, s, 0.18 + k * 0.55); }
      for (let i = 0; i < 14; i++) { const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * r * (this.o.supercell ? 2 : 1.5); const s = r * rand(0.35, 0.55); add(Math.cos(a) * d + r * 0.3, r * rand(1.8, 2.0), Math.sin(a) * d, s, s * 0.3, s, 0.76 + (i / 14) * 0.2); }
      if (this.o.supercell) { for (let i = 0; i < 9; i++) { const a = (i / 9) * 6.28; const s = r * rand(0.2, 0.28); add(Math.cos(a) * r * 0.3, -r * 0.18, Math.sin(a) * r * 0.3, s, s * 0.5, s, 0.88, true); } add(0, r * 2.25, 0, r * 0.4, r * 0.35, r * 0.4, 0.95); }
    } else if (layout === 'stratus') {
      for (let i = 0; i < 14; i++) { const s = r * rand(0.3, 0.45); add(rand(-r, r), rand(-0.5, 0.5), rand(-r * 0.6, r * 0.6), s, s * 0.22, s, 0); }
    } else if (layout === 'nimbo') {
      for (let i = 0; i < 70; i++) { const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * r; const s = r * rand(0.12, 0.2); add(Math.cos(a) * d, rand(-2, 3), Math.sin(a) * d, s, s * 0.3, s, 0); }
    } else {
      const L = this.o.length ?? 200; const n = Math.min(90, Math.round(L / 5));
      for (let i = 0; i < n; i++) {
        const u = (i / (n - 1) - 0.5) * L; const bow = layout === 'bow' ? -Math.pow(u / (L / 2), 2) * L * 0.18 : 0;
        const s = r * rand(0.28, 0.4); add(u, rand(-1, 1), bow + r * 0.3, s * 1.2, s * 0.28, s * 0.8, 0); // shelf
        const s2 = r * rand(0.35, 0.55); add(u + rand(-3, 3), r * rand(0.6, 1.6), bow - r * rand(0.3, 1), s2, s2 * 0.9, s2, 0); // towers behind
        if (i % 2 === 0) { const s3 = r * rand(0.5, 0.7); add(u, r * 2, bow - r * 1.4, s3 * 1.3, s3 * 0.3, s3, 0); }
      }
    }
  }
  updatePuffs() {
    this.puffs.forEach((p, i) => {
      const f = THREE.MathUtils.clamp((this.growth - p.th) / 0.14, 0, 1);
      let x = p.x, z = p.z; if (p.wall) { const a = this.rot; const c = Math.cos(a), s = Math.sin(a); x = p.x * c - p.z * s; z = p.x * s + p.z * c; }
      _p.set(x, p.y, z); _s.set(p.sx * f + 0.001, p.sy * f + 0.001, p.sz * f + 0.001); _m.compose(_p, _q.identity(), _s); this.im.setMatrixAt(i, _m);
    });
    this.im.instanceMatrix.needsUpdate = true;
  }
  ensureRain(intensity: number) {
    if (this.rain) return;
    const n = Math.round(Math.min(1400, 180 * intensity * (this.o.layout === 'line' || this.o.layout === 'bow' ? 4 : 1) * (this.o.layout === 'nimbo' ? 4 : 1)) * this.g.settings.particleDensity);
    this.rN = Math.max(30, n); this.rArr = new Float32Array(this.rN * 6);
    for (let i = 0; i < this.rN; i++) this.resetDrop(i, true);
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(this.rArr, 3).setUsage(THREE.DynamicDrawUsage)); geo.boundingSphere = new THREE.Sphere(V(), 1e5);
    this.rain = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0xa8c4dd, transparent: true, opacity: 0.55, depthWrite: false })); this.rain.frustumCulled = false; this.g.scene.add(this.rain);
  }
  footprint(): [number, number] {
    const { layout, r } = this.o;
    if (layout === 'line' || layout === 'bow') { const L = this.o.length ?? 200; return [(Math.random() - 0.5) * L, -rand(0, r * 1.4) + r * 0.2]; }
    const R = layout === 'nimbo' ? r : layout === 'stratus' ? r * 0.8 : r * 0.75; const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * R; return [Math.cos(a) * d, Math.sin(a) * d];
  }
  resetDrop(i: number, initial: boolean) {
    const a = this.rArr!; const [x, z] = this.footprint(); const y = initial ? Math.random() * this.o.base : this.o.base;
    a[i * 6] = x; a[i * 6 + 1] = y; a[i * 6 + 2] = z; a[i * 6 + 3] = x; a[i * 6 + 4] = y + 2.2; a[i * 6 + 5] = z;
  }
  /** is a world point beneath this cloud */
  under(p: THREE.Vector3) {
    const c = this.grp.position; const dx = p.x - c.x, dz = p.z - c.z;
    if (this.o.layout === 'line' || this.o.layout === 'bow') { const d = this.o.dir ?? V(0, 0, 1); const right = V(d.z, 0, -d.x); const u = dx * right.x + dz * right.z, f = dx * d.x + dz * d.z; return Math.abs(u) < (this.o.length ?? 200) / 2 && f < this.o.r * 0.4 && f > -this.o.r * 1.6; }
    const R = this.o.layout === 'nimbo' ? this.o.r : this.o.r * 0.8; return dx * dx + dz * dz < R * R;
  }
  strike() {
    const g = this.g; const c = this.grp.position; const inR = g.enemies.inRadius(V(c.x, 0, c.z), this.o.r * 1.3, []);
    const target = inR.length && Math.random() < 0.75 ? inR[Math.floor(Math.random() * inR.length)].pos.clone().setY(0) : randAround(V(c.x, 0, c.z), this.o.r);
    const sup = Math.random() < (this.o.superChance ?? 0); const mul = sup ? this.o.superMul ?? 1 : 1;
    const hyper = mul >= 12; const col = hyper ? 0xd8a6ff : sup ? 0xfff2a6 : 0xcfe6ff;
    for (let i = 0; i < (sup ? 4 : 2); i++) g.fx.bolt(V(c.x + rand(-this.o.r * 0.4, this.o.r * 0.4), this.o.base - 2, c.z + rand(-this.o.r * 0.4, this.o.r * 0.4)), target.clone(), { color: col, width: sup ? (hyper ? 3.5 : 2.2) : 1.1, life: sup ? 0.6 : 0.35, branches: 5, segs: 32 });
    if (Math.random() < 0.5) g.fx.bolt(V(c.x + rand(-this.o.r, this.o.r), this.o.base + rand(0, this.o.r), c.z + rand(-this.o.r, this.o.r)), V(c.x + rand(-this.o.r, this.o.r), this.o.base + rand(0, this.o.r), c.z + rand(-this.o.r, this.o.r)), { color: 0xdfeeff, width: 0.6, life: 0.2, branches: 2 }); // in-cloud
    const r = g.aoe(sup ? (hyper ? 22 : 12) : 6);
    g.fx.explosion(target, r, { core: 0xffffff, edge: col, smoke: null, sparks: sup ? 90 : 30, shake: sup ? (hyper ? 18 : 9) : 3, ring: true, dur: 0.5 });
    g.dmgArea(target, r, B * 2 * mul * this.o.dmgMul!, { stun: sup ? 1.5 : 0.3, big: sup, color: sup ? '#fff2a6' : undefined });
  }
  kill() { if (this.alive) { this.alive = false; this.fadeOut = 0; } }
  update(dt: number) {
    const g = this.g; this.t += dt;
    if (this.alive && this.t >= this.o.life) this.kill();
    // growth
    const pg = this.growth; this.growth = Math.min(1, this.t / this.o.grow);
    if (this.o.supercell) this.rot += dt * 0.6;
    if (this.growth !== pg || (this.o.supercell && this.growth > 0.85)) { if (g.time - this.lastGrowUpd > 0.03) { this.lastGrowUpd = g.time; this.updatePuffs(); } }
    if (this.o.vel) this.grp.position.addScaledVector(this.o.vel, dt);
    const c = this.grp.position;
    // fade
    let alpha = Math.min(1, this.t / 0.6);
    if (!this.alive) { this.fadeOut += dt; alpha = Math.max(0, 1 - this.fadeOut / 2); }
    this.mat.opacity = 0.97 * alpha;
    const raining = this.alive && (this.o.rain ?? 0) > 0 && this.growth >= (this.o.rainStart ?? 0.55);
    if (raining) this.ensureRain(this.o.rain!);
    if (this.rain && this.rArr) {
      const a = this.rArr; const sp = 60 * dt;
      (this.rain.material as THREE.LineBasicMaterial).opacity = 0.55 * alpha * (raining ? 1 : 0.5);
      this.rain.position.set(c.x, 0, c.z); this.rain.rotation.y = this.o.layout === 'line' || this.o.layout === 'bow' ? this.grp.rotation.y : 0;
      for (let i = 0; i < this.rN; i++) { a[i * 6 + 1] -= sp; a[i * 6 + 4] -= sp; if (a[i * 6 + 1] < 0) { if (raining) this.resetDrop(i, false); else { a[i * 6 + 1] = -99; a[i * 6 + 4] = -99; } } }
      this.rain.geometry.attributes.position.needsUpdate = true;
      // rain damage every 0.05s (medium)
      this.dmgAcc += dt;
      if (raining && this.dmgAcc >= 0.05) { this.dmgAcc = 0; for (const e of g.enemies.list) if (e.alive && this.under(e.pos)) g.dmg(e, B * 0.06 * this.o.rain! * this.o.dmgMul!, { small: true, color: '#9fc8ff', noProc: Math.random() < 0.8 }); }
    }
    if (this.alive && this.growth >= 0.8) {
      if (this.o.lightning && Math.random() < this.o.lightning * dt) this.strike();
      if (this.o.hail && Math.random() < this.o.hail * dt * 10) { const h = ensureHail(g); const n = Math.ceil(this.o.hail); for (let i = 0; i < n; i++) { const [x, z] = this.footprint(); h.add(V(c.x + x, this.o.base - 1, c.z + z), this.o.hailSize ?? 0.3, (this.o.hailDmg ?? B) * this.o.dmgMul!, this.o.shatter ?? [0.5, 0.3]); } }
      if (this.o.tornado && this.o.supercell && this.growth >= 1) { this.tornadoAcc -= dt; if (this.tornadoAcc <= 0 && this.tornados < 3) { this.tornadoAcc = rand(15, 40); this.tornados++; tornado(g, this, rand(12, 25), rand(0.8, 1.3)); } }
    }
    if (this.alive && this.o.wind) {
      const d = this.o.dir ?? V(0, 0, 1); const right = V(d.z, 0, -d.x); const push = this.o.wind.speed * 0.25;
      for (const e of g.enemies.list) { if (!e.alive) continue; const dx = e.pos.x - c.x, dz = e.pos.z - c.z; const u = dx * right.x + dz * right.z, f = dx * d.x + dz * d.z; if (Math.abs(u) < (this.o.length ?? 200) / 2 && f > -this.o.r && f < this.o.wind.depth) { e.pos.addScaledVector(d, push * dt); if (e.gate('wind', g.time, 0.3)) g.dmg(e, B * 0.3 * (this.o.wind.speed / 50), { small: true, color: '#cfe6ff' }); } }
      if (this.o.wind.shake) { const pp = g.player.pos; const f = (pp.x - c.x) * d.x + (pp.z - c.z) * d.z; if (f > -this.o.r && f < this.o.wind.depth + 20 && Math.random() < 0.5) g.shake(pp, 2 + this.o.wind.speed / 40, 0.2); }
      const gc = new THREE.Color(0xbfcfdf); for (let i = 0; i < g.fx.smoke.n(6); i++) { const u = (Math.random() - 0.5) * (this.o.length ?? 200); const q = c.clone().addScaledVector(right, u).addScaledVector(d, rand(0, this.o.r * 0.5)); g.fx.smoke.emit(q.x, rand(0.5, 3), q.z, d.x * this.o.wind.speed * 0.4, 1, d.z * this.o.wind.speed * 0.4, gc, rand(0.6, 1.2), rand(3, 6), 0, 0.3, 0.35, 1.5); }
    }
    if (!this.alive && this.fadeOut >= 2) { this.dispose(); return false; }
    return true;
  }
  dispose() {
    this.dead = true; this.g.scene.remove(this.grp); this.im.dispose(); this.mat.dispose();
    if (this.rain) { this.g.scene.remove(this.rain); this.rain.geometry.dispose(); (this.rain.material as THREE.Material).dispose(); }
    const i = cells.indexOf(this); if (i >= 0) cells.splice(i, 1); this.g.clouds = cells.filter((c) => c.alive).length;
  }
}
function spawnCell(g: Game, o: CellOpts) { const c = new Cell(g, o); g.task((dt) => c.update(dt)); return c; }

/* ------------------------------------------------------------------ presets */
function cumulus(g: Game, p: THREE.Vector3, grow: number, life: number, forceSuper?: boolean, extra: Partial<CellOpts> = {}) {
  const sup = forceSuper ?? Math.random() < 0.35;
  return spawnCell(g, { pos: p, layout: 'cell', r: sup ? 26 : 18, base: sup ? 34 : 30, life, grow, supercell: sup, rain: sup ? 2 : 1.1, rainStart: 0.5, lightning: sup ? 1.4 : 0.6, superChance: sup ? 0.4 : 0.2, superMul: sup ? 12 : 3, hail: sup ? 1.2 : 0.15, hailSize: sup ? rand(0.5, 0.9) : 0.3, hailDmg: sup ? B * 6 : B * 1.5, shatter: [0.6, 0.4], tornado: sup, dark: sup ? 0.5 : 0.25, ...extra });
}

function hurricane(g: Game) {
  const center = g.player.pos.clone(); const dir = g.aimDir; const R = 7500; const EYE = 55;
  const grp = new THREE.Group(); grp.position.set(center.x, 0, center.z);
  const disc = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: TEX.spiral, transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: false, opacity: 0 }));
  disc.rotation.x = -Math.PI / 2; disc.position.y = 420; disc.scale.set(R * 2, R * 2, 1); grp.add(disc);
  const disc2 = disc.clone(); disc2.material = (disc.material as THREE.MeshBasicMaterial).clone(); disc2.position.y = 360; disc2.scale.set(R * 1.4, R * 1.4, 1); grp.add(disc2);
  const wall = new THREE.Mesh(GEO.cyl, new THREE.MeshLambertMaterial({ color: 0xcfd6de, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false })); wall.scale.set(EYE + 25, 420, EYE + 25); wall.position.y = 210; grp.add(wall);
  const rainWall = new THREE.Mesh(GEO.cyl, fresnelMat(0x8aa4bc, 0, 0.8, 0.25, false)); rainWall.scale.set(EYE + 60, 400, EYE + 60); rainWall.position.y = 200; grp.add(rainWall);
  g.scene.add(grp);
  // player-local heavy rain field
  const N = Math.round(2600 * g.settings.particleDensity); const arr = new Float32Array(N * 6);
  for (let i = 0; i < N; i++) { const x = rand(-110, 110), z = rand(-110, 110), y = rand(0, 90); arr.set([x, y, z, x - 3, y + 4, z], i * 6); }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(arr, 3).setUsage(THREE.DynamicDrawUsage)); geo.boundingSphere = new THREE.Sphere(V(), 1e5);
  const rain = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0xb0c8dc, transparent: true, opacity: 0, depthWrite: false })); rain.frustumCulled = false; g.scene.add(rain);
  const dur = 600; let acc = 0; const spray = new THREE.Color(0xd0dde8);
  g.task((dt, t) => {
    grp.position.addScaledVector(dir, 10 * dt); disc.rotation.z += dt * 0.05; disc2.rotation.z += dt * 0.08; wall.rotation.y += dt * 0.4;
    const k = Math.min(1, t / 4, (dur - t) / 6);
    (disc.material as THREE.MeshBasicMaterial).opacity = 0.95 * k; (disc2.material as THREE.MeshBasicMaterial).opacity = 0.7 * k; (wall.material as THREE.MeshLambertMaterial).opacity = 0.35 * k; setOpacity(rainWall.material as THREE.Material, 0.6 * k);
    const c = grp.position; const pp = g.player.pos; const dP = Math.hypot(pp.x - c.x, pp.z - c.z);
    const inEye = dP < EYE; const wallI = dP < EYE ? 0 : Math.max(0.25, 1 - (dP - EYE) / 900);
    (rain.material as THREE.LineBasicMaterial).opacity = inEye ? 0 : 0.55 * k * wallI; rain.position.set(pp.x, 0, pp.z);
    const sp = 90 * dt;
    for (let i = 0; i < N; i++) { arr[i * 6 + 1] -= sp; arr[i * 6 + 4] -= sp; arr[i * 6] -= sp * 0.35; arr[i * 6 + 3] -= sp * 0.35; if (arr[i * 6 + 1] < 0) { const x = rand(-110, 110), z = rand(-110, 110), y = 90; arr[i * 6] = x; arr[i * 6 + 1] = y; arr[i * 6 + 2] = z; arr[i * 6 + 3] = x - 3; arr[i * 6 + 4] = y + 4; arr[i * 6 + 5] = z; } }
    geo.attributes.position.needsUpdate = true;
    if (!inEye && k > 0.5) { g.shake(pp, 1 + wallI * 4, 0.15, true); for (let i = 0; i < g.fx.smoke.n(4); i++) g.fx.smoke.emit(pp.x + rand(-60, 60), rand(0.5, 4), pp.z + rand(-60, 60), rand(-30, -10), 1, rand(-6, 6), spray, 1, rand(3, 7), 0, 0.2, 0.35, 1.5); }
    acc += dt;
    for (const e of g.enemies.list) {
      if (!e.alive) continue; const dx = e.pos.x - c.x, dz = e.pos.z - c.z; const L = Math.hypot(dx, dz) || 1; if (L < EYE || L > R) continue;
      const w = Math.max(0.15, 1 - (L - EYE) / 1200) * k; // 250 mph at eyewall
      e.pos.x += ((dx / L) * 22 - (dz / L) * 30) * w * dt; e.pos.z += ((dz / L) * 22 + (dx / L) * 30) * w * dt;
      if (acc > 0.5) g.dmg(e, B * 0.8 * w, { small: true, color: '#cfe6ff' });
    }
    if (acc > 0.5) acc = 0;
    if (t >= dur) { g.scene.remove(grp); g.scene.remove(rain); geo.dispose(); disposeObj(grp); (rain.material as THREE.Material).dispose(); return false; }
  });
}

/* ------------------------------------------------------------------ item */
export const cloudFruit: ItemDef = {
  id: 'cloud', name: 'Cloud', kind: 'fruit', color: '#dbe8f5', glyph: '☁',
  passive: 'M1 (0.05s): combo 4 launches a homing cloudlet; 10% chance to spawn a drizzling stratus.',
  m1: {
    interval: 0.05, comboLen: 4,
    fn: (g, combo) => {
      g.playAnim('punch', 0.08); const f = g.aimDir; const hp = g.handPos();
      g.fx.puff(hp.clone().addScaledVector(f, 1.5), 2, 0xeef4fb, 0.6, 0.4, 1.2, 1, 0.6);
      for (const e of g.enemies.inRadius(g.player.pos.clone().addScaledVector(f, 3), 3.5, [])) g.dmg(e, B * 0.3, { small: true });
      if (combo === 4) {
        const t = g.enemies.nearest(g.aim, 60) ?? g.enemies.nearest(g.player.pos, 60);
        const c = new THREE.Group(); const cm = new THREE.MeshLambertMaterial({ color: 0xf4f8ff, emissive: 0x333a44 });
        for (let i = 0; i < 4; i++) { const s = new THREE.Mesh(GEO.sphereLo, cm); s.scale.setScalar(rand(0.5, 0.9)); s.position.set(rand(-0.8, 0.8), rand(-0.3, 0.3), rand(-0.8, 0.8)); c.add(s); }
        g.projectile({ obj: c, pos: hp.clone(), vel: f.clone().multiplyScalar(40).setY(3), life: 2.5, radius: 1.3, homing: t, homingRate: 8, hitGround: true,
          onHit: (p) => { g.fx.explosion(p, 5, { core: 0xffffff, edge: 0xcfe6ff, smoke: 0xe6eef6, sparks: 20, light: false }); g.fx.bolt(p.clone().setY(12), p.clone().setY(0), { color: 0xcfe6ff, width: 0.4, life: 0.15, branches: 1 }); g.dmgArea(p, g.aoe(5), B * 1.2); },
          onEnd: (p) => g.fx.puff(p, 8, 0xeef4fb, 2, 1, 2, 1) });
        if (Math.random() < 0.1) spawnCell(g, { pos: g.aim.clone(), layout: 'stratus', r: 14, base: 16, life: 3.6, grow: 0.4, rain: 0.35, rainStart: 0, dmgMul: 0.4, dark: 0.3 });
      }
    },
  },
  skills: [
    { name: 'Cumulus Growth', cd: 5, extra: (g) => `${g.clouds} cells`, cast: (g) => { g.playAnim('raise', 0.5); cumulus(g, randAround(g.player.pos, 90), 10, 300); } },
    {
      name: 'Atmospheric Instability', cd: 5,
      cast: (g) => { g.playAnim('raise', 0.6); const d = g.aimDir; const p = g.player.pos.clone().addScaledVector(d, -60); const c = spawnCell(g, { pos: p, layout: 'line', r: 16, base: 22, life: 120, grow: 1.2, length: 320, dir: d, vel: d.clone().multiplyScalar(10), rain: 3.2, rainStart: 0, lightning: 1.2, superChance: 0.1, superMul: 3, wind: { speed: 54, depth: 40, shake: true }, dark: 0.55 }); c.grp.rotation.y = Math.atan2(d.x, d.z); },
    },
    {
      name: 'Hailstorm', cd: 5,
      cast: (g) => { g.playAnim('raise', 0.5); const c = g.aim.clone(); for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2; spawnCell(g, { pos: c.clone().add(V(Math.cos(a) * 26, 0, Math.sin(a) * 26)), layout: 'cell', r: 22, base: 32, life: 8, grow: 0.8, rain: 0.8, rainStart: 0.5, lightning: 0.5, superChance: 0.2, superMul: 3, hail: 4, hailSize: 0.22, hailDmg: B * 1.6, shatter: [0.5, 0.3], dark: 0.45 }); } },
    },
    {
      name: 'Derecho Swarm', cd: 5,
      cast: (g) => {
        g.playAnim('raise', 0.6); const pp = g.player.pos.clone();
        for (const s of [V(1, 0, 0), V(-1, 0, 0), V(0, 0, 1), V(0, 0, -1)]) { const d = s.clone().negate(); const c = spawnCell(g, { pos: pp.clone().addScaledVector(s, 30), layout: 'bow', r: 14, base: 20, life: 5.5, grow: 0.5, length: 200, dir: d, vel: d.clone().multiplyScalar(12), rain: 2.5, rainStart: 0, lightning: 1, superChance: 0.1, superMul: 3, wind: { speed: 107, depth: 35, shake: true }, dark: 0.6 }); c.grp.rotation.y = Math.atan2(d.x, d.z); }
      },
    },
    {
      name: 'Tornado Destruction', cd: 5,
      cast: (g) => { g.playAnim('raise', 0.6); const c = spawnCell(g, { pos: g.aim.clone(), layout: 'cell', r: 30, base: 38, life: 12, grow: 0.9, supercell: true, rain: 1.6, rainStart: 0.5, lightning: 1, superChance: 0.4, superMul: 12, hail: 0.6, hailSize: 0.5, hailDmg: B * 4, dark: 0.55 }); g.after(1, () => tornado(g, c, 10, 1.6)); },
    },
    {
      name: 'Hurricane Storm', cd: 5,
      cast: (g) => { g.player.invT = Math.max(g.player.invT, 1.1); g.playAnim('raise', 1); const col = new THREE.Color(0xdbe8f5); g.task((_dt, t) => { const hp = g.handPos(); for (let i = 0; i < g.fx.sparks.n(10); i++) { const a = Math.random() * 6.28; g.fx.sparks.emit(hp.x + Math.cos(a) * 3, hp.y, hp.z + Math.sin(a) * 3, -Math.sin(a) * 8, rand(1, 4), Math.cos(a) * 8, col, 0.4, 0.5); } return t < 1; }); g.after(1, () => hurricane(g)); },
    },
    {
      name: 'Cyclone Bomb', cd: 5,
      cast: (g) => {
        g.playAnim('raise', 0.8); const C = g.aim.clone(); const cs: Cell[] = [];
        for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2 + rand(-0.3, 0.3); const p = C.clone().add(V(Math.cos(a) * 55, 0, Math.sin(a) * 55)); const c = spawnCell(g, { pos: p, layout: 'cell', r: 12, base: 30, life: 4.2, grow: 1.4, rain: 0.6, rainStart: 0.5, lightning: 0.8, dark: 0.4 }); c.o.vel = C.clone().sub(p).setY(0).multiplyScalar(1 / 2.6); cs.push(c); }
        g.after(2.8, () => {
          cs.forEach((c) => (c.o.vel = V()));
          const big = spawnCell(g, { pos: C.clone(), layout: 'cell', r: 34, base: 36, life: 6, grow: 0.3, rain: 3, rainStart: 0, lightning: 2, superChance: 0.3, superMul: 3, dark: 0.65 }); void big;
          // microburst slams down at 200 m/s
          const col = new THREE.Mesh(GEO.cylSolid, fresnelMat(0xbcd0e2, 1, 1, 0.3)); col.scale.set(18, 1, 18); g.scene.add(col); const top = 36;
          g.task((_dt, t) => {
            const y = Math.max(0, top - 200 * t); col.scale.y = top - y + 0.1; col.position.set(C.x, y + (top - y) / 2, C.z);
            if (y <= 0) {
              g.scene.remove(col); disposeObj(col);
              g.fx.explosion(C, 25, { core: 0xffffff, edge: 0xa8c4dd, smoke: 0xc0ccd8, sparks: 60, debris: 40, shake: 26 });
              const wallM = new THREE.Mesh(GEO.cyl, fresnelMat(0x9fb6cc, 1, 0.9, 0.35, false)); wallM.position.set(C.x, 12, C.z); g.scene.add(wallM);
              const hit = new Set<Enemy>();
              g.task((_d2, t2) => {
                const R = 5 + 70 * t2; wallM.scale.set(R, 24 * (1 - t2 / 2.2), R); setOpacity(wallM.material as THREE.Material, Math.max(0, 1 - t2 / 2));
                for (const e of g.enemies.inRadius(C, R, [])) { if (hit.has(e)) continue; hit.add(e); const d = e.pos.clone().sub(C).setY(0).normalize(); e.knock(d, 60, 12); g.dmg(e, B * 5); }
                g.shake(C, 6, 0.1);
                if (t2 >= 2.2) { g.scene.remove(wallM); disposeObj(wallM); return false; }
              });
              return false;
            }
          });
        });
      },
    },
    {
      name: 'Nimbostratus Flooding', cd: 5,
      cast: (g) => {
        g.playAnim('raise', 0.6); const C = g.aim.clone(); const R = 90; const dur = 25;
        spawnCell(g, { pos: C, layout: 'nimbo', r: R, base: 42, life: dur, grow: 1.5, rain: 2.2, rainStart: 0, dark: 0.55, dmgMul: 1.2 });
        const water = new THREE.Mesh(GEO.disc, new THREE.MeshStandardMaterial({ color: 0x1a5a88, transparent: true, opacity: 0.7, roughness: 0.05, metalness: 0.4, emissive: 0x06243a })); water.position.set(C.x, 0, C.z); water.scale.setScalar(R); g.scene.add(water);
        const fl = { p: C.clone(), r: R, level: 0 }; g.floods.push(fl); let acc = 0;
        g.task((dt, t) => {
          fl.level = Math.min(4, t < dur - 3 ? t * 0.22 : Math.max(0, fl.level - dt * 1.5)); water.position.y = fl.level; acc += dt;
          if (acc > 0.3) { acc = 0; for (const e of g.enemies.inRadius(C, R, [])) if (fl.level > e.height * 0.5) { g.dmg(e, e.maxHp * 0.01 * fl.level, { small: true, color: '#5ab0ff' }); if (Math.random() < 0.2) g.fx.burstSparks(e.pos.clone().setY(fl.level), 4, 0xbfe6ff, 3, 0.4, 0.4); } }
          if (t >= dur) { g.scene.remove(water); disposeObj(water); g.floods.splice(g.floods.indexOf(fl), 1); return false; }
        });
      },
    },
    {
      name: 'Supercell Spawner', cd: 5, ui: 'supercell',
      cdMul: (g) => [0.4, 1, 2.5][g.supercellType],
      extra: (g) => ['LP', 'NORMAL', 'HP'][g.supercellType],
      cast: (g) => {
        g.playAnim('raise', 0.6); const T = g.supercellType; const pm = [0.3, 1, 2.5][T]; const dm = [0.5, 1, 2.2][T];
        cumulus(g, g.aim.clone(), 2.5, 60, true, { rain: 2 * pm, hail: 1.2 * pm, dmgMul: dm, lightning: 1.4 * (0.6 + pm * 0.4), dark: [0.25, 0.5, 0.75][T] });
      },
    },
    {
      name: 'Storm Suppression', cd: 5,
      cast: (g) => {
        g.playAnim('raise', 0.6); const C = g.player.pos.clone(); const mine: Cell[] = []; let next = 0;
        g.task((_dt, t) => {
          if (t >= next && t < 30) {
            const active = mine.filter((c) => c.alive).length;
            if (active < 14) { const c = cumulus(g, randAround(C, 110), 3, 30 - t + 1, false, { supercell: false, r: 17, dark: 0.35, tornado: false }); mine.push(c); }
            next = t + Math.max(0.6, 3 - t * 0.12);
          }
          return t < 30;
        });
      },
    },
  ],
};
void glowMat;
