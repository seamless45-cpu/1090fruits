import * as THREE from 'three';
import type { ItemDef } from '../types';
import type { Game } from '../Game';
import type { Enemy } from '../Enemies';
import { GEO, glowMat, rand, disposeObj } from '../Effects';
import { B, V, laser, pillarBeam, auraRings, slashFx } from '../kit';

const RED = 0xff1a2e, HOT = 0xff6070;

export function redStomp(g: Game, p: THREE.Vector3, scale = 1) {
  const r = g.aoe(40);
  g.fx.shell(p, 1, r, RED, 0.9, { power: 1.6, flatten: 0.4 });
  g.fx.ring(p, 1, r * 1.2, RED, 0.8); g.fx.ring(p, 1, r * 0.7, 0xffb0b8, 0.6, { thin: true });
  g.fx.debris(p, 70 * scale, 0x4a2a2e, 30, 1, 3); g.fx.puff(p, 25, 0x3a1a1e, r * 0.4, 2, 6, 3);
  g.fx.burstSparks(p.clone().setY(1), 80, HOT, 40, 0.8, 1.2);
  g.fx.flash(p.clone().setY(8), RED, 80, 120, 0.4);
  g.shake(p, 13, 0.6);
  g.dmgArea(p, r, B * 4, { up: 56, knock: 6, stun: 1.5 }); // up 56m/s ≈ 50m flight
}
export function imprisonBeams(g: Game, from: THREE.Vector3) {
  const list = g.enemies.list.filter((e) => e.alive && e.pos.distanceTo(from) < 150).sort(() => Math.random() - 0.5).slice(0, 4);
  for (let i = 0; i < 6; i++) {
    const e = list[i % Math.max(1, list.length)];
    const to = e ? e.pos.clone().setY(e.height * 0.5) : from.clone().add(V(rand(-30, 30), 0, rand(-30, 30)));
    laser(g, from.clone(), to, RED, 0.35, 0.4);
  }
  for (const e of list) { e.imprison(3); g.dmg(e, B * 0.8); }
}

function makeGiant() {
  const G = new THREE.Group();
  const armor = new THREE.MeshStandardMaterial({ color: 0x2a0d12, metalness: 0.8, roughness: 0.35, emissive: 0x220004 });
  const red = glowMat(RED, 1); red.side = THREE.FrontSide; red.blending = THREE.NormalBlending;
  const box = (w: number, h: number, d: number, m: THREE.Material, x: number, y: number, z: number) => { const b = new THREE.Mesh(GEO.box, m); b.scale.set(w, h, d); b.position.set(x, y, z); b.castShadow = true; G.add(b); return b; };
  box(3.2, 3.6, 2, armor, 0, 6.2, 0); box(2, 1.6, 1.8, armor, 0, 8.9, 0); box(1.6, 0.35, 0.2, red, 0, 9, 0.92);
  box(1.1, 4, 1.1, armor, -0.9, 2.2, 0); box(1.1, 4, 1.1, armor, 0.9, 2.2, 0);
  box(1, 3.4, 1, armor, -2.2, 6.2, 0);
  const arm = new THREE.Group(); arm.position.set(2.2, 7.6, 0); G.add(arm);
  const a = new THREE.Mesh(GEO.box, armor); a.scale.set(1, 3.4, 1); a.position.y = -1.6; arm.add(a);
  const blade = new THREE.Mesh(GEO.box, red); blade.scale.set(0.35, 0.15, 7); blade.position.set(0, -3.2, 3.5); arm.add(blade);
  const siren = new THREE.Mesh(GEO.sphereLo, glowMat(RED, 1)); siren.scale.setScalar(0.5); siren.position.y = 10; G.add(siren);
  G.userData = { arm, siren };
  return G;
}

export const alarmFruit: ItemDef = {
  id: 'alarm', name: 'Alarm', kind: 'fruit', color: '#ff1a2e', glyph: '⚠',
  skills: [
    {
      name: 'Manual Alert', cd: 3,
      cast: (g) => {
        g.playAnim('punch', 0.3); const hp = g.handPos();
        const list = g.enemies.inRadius(g.player.pos, g.aoe(80), []);
        list.forEach((e, i) => { if (i < 45) laser(g, hp, e.pos.clone().setY(e.height * 0.5), RED, 0.3, 0.4); e.imprison(6); g.dmg(e, B); });
        g.fx.shell(hp, 0.3, 3, RED, 0.3);
      },
    },
    {
      name: 'Automatic Transmission Alarming', cd: 5.5,
      cast: (g) => {
        g.playAnim('punch', 0.4);
        let top: Enemy | null = null; for (const e of g.enemies.list) if (e.alive && (!top || e.hp > top.hp)) top = e;
        if (!top) return;
        const hp = g.handPos(); const to = top.pos.clone().setY(top.height * 0.5);
        laser(g, hp, to, RED, 1.8, 0.7); g.fx.explosion(to, 6, { core: 0xffffff, edge: RED, smoke: null, sparks: 60 });
        top.imprison(15); g.dmg(top, B * 8, { big: true });
        const center = top.pos.clone();
        g.after(0.35, () => {
          for (const e of g.enemies.inRadius(center, g.aoe(40), [])) {
            if (e.imprisonT <= 0 && e !== top) continue;
            pillarBeam(g, e.pos.clone(), RED, 140, 2.2, 0.9); g.dmg(e, B * 4); g.fx.burstSparks(e.pos.clone().setY(1), 20, HOT, 14, 0.5, 0.6);
          }
          g.shake(center, 8, 0.4);
        });
      },
    },
    {
      name: 'Siren Blaster', cd: 8,
      cast: (g) => {
        g.playAnim('raise', 0.6);
        const grp = new THREE.Group(); const bars: THREE.Mesh[] = [];
        for (let i = 0; i < 2; i++) { const b = new THREE.Mesh(GEO.box, glowMat(i ? RED : 0xff8a1a, 0.9)); b.scale.set(0.3, 0.3, 6); b.position.y = 3.3; bars.push(b); grp.add(b); }
        let pulse = 0, beat = 0;
        g.addAura(grp, () => pulse < 7, (_o, dt) => { bars[0].rotation.y += dt * 12; bars[1].rotation.y -= dt * 12; });
        g.task((dt, t) => {
          pulse = t; beat += dt;
          if (Math.floor(t / 0.35) !== Math.floor((t - dt) / 0.35)) { g.fx.ring(g.player.pos.clone(), 2, 90, RED, 0.9, { thin: true }); g.fx.shell(g.player.pos.clone().setY(1.5), 1, 18, RED, 0.5, { op: 0.4 }); g.shake(g.player.pos, 2, 0.2, true); }
          const fleeing = g.enemies.inRadius(g.player.pos, 1000, []); fleeing.forEach((e) => e.flee(0.5));
          if (beat >= 1) {
            beat = 0;
            fleeing.forEach((e, i) => {
              if (i < 40) { pillarBeam(g, e.pos.clone(), RED, 90, 1.2, 0.5); for (let k = 0; k < 2; k++) g.fx.bolt(e.pos.clone().add(V(rand(-2, 2), rand(0, e.height), rand(-2, 2))), e.pos.clone().add(V(rand(-3, 3), rand(0, e.height * 1.5), rand(-3, 3))), { color: HOT, width: 0.3, life: 0.25, branches: 1, segs: 8 }); }
              g.dmg(e, B * 1.5, { small: i >= 40 });
            });
          }
          return t < 7;
        });
      },
    },
    {
      name: 'Alarm Buffer', cd: 15,
      extra: (g) => (g.buffs.alarm > g.time ? `${Math.ceil(g.buffs.alarm - g.time)}s` : ''),
      cast: (g) => { g.buffs.alarm = g.time + 30; g.playAnim('raise', 0.6); g.fx.shell(g.player.pos.clone().setY(1), 0.5, 10, RED, 0.6); g.fx.burstSparks(g.player.pos.clone().setY(1), 60, HOT, 16, 0.8, 0.6, 0); auraRings(g, RED, () => g.buffs.alarm > g.time, 1.3); },
    },
    {
      name: 'Amber Alert', cd: 30,
      cast: (g) => {
        g.playAnim('raise', 0.8);
        const claimed = new Set<Enemy>();
        for (let i = 0; i < 15; i++) {
          const a = (i / 15) * Math.PI * 2; const spawn = g.player.pos.clone().add(V(Math.cos(a) * 16, 0, Math.sin(a) * 16));
          const G = makeGiant(); G.position.copy(spawn); g.scene.add(G);
          pillarBeam(g, spawn, RED, 120, 5, 0.8); g.fx.ring(spawn, 1, 14, RED, 0.6);
          const hacker = new THREE.Group(); const hb = new THREE.Mesh(GEO.octa, glowMat(0x33ff88, 1)); hb.scale.setScalar(0.8); hacker.add(hb); const hr = new THREE.Mesh(GEO.torus, glowMat(0x33ff88, 0.8)); hr.scale.setScalar(1.3); hacker.add(hr); g.scene.add(hacker);
          const st = { target: null as Enemy | null, atk: 0, stomp: rand(1, 5), hits: 0, hack: 1 + Math.random(), swing: 0 };
          g.task((dt, t) => {
            if (!st.target || !st.target.alive) { if (st.target) claimed.delete(st.target); st.target = null; let best: Enemy | null = null, bd = 200 * 200; for (const e of g.enemies.list) { if (!e.alive || claimed.has(e)) continue; const d = e.pos.distanceToSquared(G.position); if (d < bd) { bd = d; best = e; } } if (best) { st.target = best; claimed.add(best); } }
            const T = st.target;
            if (T) {
              const d = T.pos.clone().sub(G.position).setY(0); const L = d.length();
              G.rotation.y = Math.atan2(d.x, d.z);
              if (L > 6) G.position.addScaledVector(d.normalize(), Math.min(L - 5, 20 * dt));
              st.atk -= dt;
              if (L < 9 && st.atk <= 0) {
                st.hits++; st.atk = st.hits % 3 === 0 ? 0.6 : 0.2; st.swing = 0.2;
                g.dmg(T, B * 2); slashFx(g, T.pos.clone().setY(3), d.normalize(), 6, RED, { life: 0.2 });
                if (st.hits % 3 === 0) imprisonBeams(g, G.position.clone().setY(9));
              }
              st.hack -= dt;
              if (st.hack <= 0) { st.hack = 2; T.hackIt(6); laser(g, hacker.position.clone(), T.pos.clone().setY(T.height * 0.6), 0x33ff88, 0.2, 0.3); g.fx.burstSparks(T.pos.clone().setY(T.height), 12, 0x33ff88, 6, 0.4, 0.4, 0); }
            }
            st.stomp -= dt; if (st.stomp <= 0) { st.stomp = 5; redStomp(g, G.position.clone(), 0.5); }
            st.swing -= dt; const arm = G.userData.arm as THREE.Group; arm.rotation.x = st.swing > 0 ? -1.8 + (0.2 - st.swing) * 12 : Math.sin(t * 4) * 0.1;
            (G.userData.siren as THREE.Mesh).scale.setScalar(0.4 + (Math.sin(t * 16) > 0 ? 0.3 : 0));
            G.position.y = Math.abs(Math.sin(t * 8)) * 0.3;
            hacker.position.copy(G.position).add(V(Math.cos(t * 2) * 4, 12 + Math.sin(t * 3), Math.sin(t * 2) * 4)); hb.rotation.y += dt * 4; hr.rotation.x += dt * 3;
            if (t >= 15) { if (st.target) claimed.delete(st.target); g.fx.shell(G.position.clone().setY(5), 1, 10, RED, 0.5); g.fx.burstSparks(G.position.clone().setY(5), 40, RED, 16); g.scene.remove(G); g.scene.remove(hacker); disposeObj(G); disposeObj(hacker); return false; }
          });
        }
      },
    },
  ],
};

export const alarmSword: ItemDef = {
  id: 'asword', name: 'Alarm Sword', kind: 'sword', color: '#ff3347', glyph: '⟊',
  passive: 'Every 3 M1 hits fires 6 red beams imprisoning 4 random enemies (3s).',
  m1: {
    interval: 0.2, endLag: 0.4, comboLen: 3,
    fn: (g, combo) => {
      g.playAnim('swing', 0.18); const f = g.fwd; const p = g.player.pos.clone().addScaledVector(f, 2.8).setY(1.5);
      slashFx(g, p, f, 4.4, RED, { tilt: combo === 2 ? -0.7 : 0.7 });
      let hit = false;
      for (const e of g.enemies.inRadius(g.player.pos, 7, [])) { const d = e.pos.clone().sub(g.player.pos).setY(0).normalize(); if (d.dot(f) > 0.2) { g.dmg(e, B * 1); hit = true; } }
      const s = g.skillStates['asword'][0].data; s.hits = (s.hits ?? 0) + (hit ? 1 : 0);
      if (hit && s.hits % 3 === 0) imprisonBeams(g, g.handPos());
    },
  },
  skills: [
    { name: 'Red Stomp', cd: 5, cast: (g) => { g.playAnim('slam', 0.4); g.after(0.2, () => redStomp(g, g.player.pos.clone())); } },
  ],
};
