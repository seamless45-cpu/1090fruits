import * as THREE from 'three';
import type { ItemDef } from '../types';
import { GEO, glowMat, fresnelMat, rand, setOpacity, disposeObj } from '../Effects';
import { B, V, randAround, slashFx } from '../kit';

const YEL = 0xffe45c, CYAN = 0x7fe9ff, WHITE = 0xffffff;

function darkCloud(scale: number) {
  const grp = new THREE.Group(); const mat = new THREE.MeshLambertMaterial({ color: 0x1c1f2a, transparent: true, opacity: 0.95 });
  for (let i = 0; i < 7; i++) { const s = new THREE.Mesh(GEO.sphereLo, mat); s.scale.set(rand(3, 6) * scale, rand(1.6, 3) * scale, rand(3, 6) * scale); s.position.set(rand(-6, 6) * scale, rand(-1, 1) * scale, rand(-6, 6) * scale); grp.add(s); }
  return grp;
}

export const lightningFruit: ItemDef = {
  id: 'lightning', name: 'Lightning', kind: 'fruit', color: '#ffe45c', glyph: 'ϟ',
  skills: [
    {
      name: 'Bestia Relámpago', cd: 5,
      cast: (g) => {
        g.playAnim('punch', 0.3);
        const tgt = g.enemies.nearest(g.aim, 80);
        const grp = new THREE.Group();
        const head = new THREE.Mesh(GEO.octa, glowMat(WHITE, 1)); head.scale.set(1.2, 1.2, 3.2); grp.add(head);
        const aura = new THREE.Mesh(GEO.sphere, fresnelMat(YEL, 1, 1.5, 0.15)); aura.scale.set(2.6, 2.4, 4.5); grp.add(aura);
        for (const s of [-1, 1]) { const horn = new THREE.Mesh(GEO.cone, glowMat(CYAN, 1)); horn.scale.set(0.35, 2.2, 0.35); horn.position.set(s * 1.1, 1.4, 0.6); horn.rotation.x = -0.6; horn.rotation.z = -s * 0.4; grp.add(horn); const eye = new THREE.Mesh(GEO.sphereLo, glowMat(0x00ffff, 1)); eye.scale.setScalar(0.3); eye.position.set(s * 0.5, 0.5, 2.2); grp.add(eye); }
        const start = g.handPos(); const dir = (tgt ? tgt.pos.clone().setY(1.5) : g.aim.clone().setY(1.5)).sub(start).normalize();
        let acc = 0; const yc = new THREE.Color(YEL);
        const boom = (p: THREE.Vector3) => { const r = g.aoe(30); const q = p.clone().setY(0.5); g.fx.explosion(q, r, { core: WHITE, edge: YEL, smoke: 0x22262e, sparks: 140, shards: 30, shardColor: CYAN, shake: 14 }); for (let i = 0; i < 8; i++) g.fx.strike(randAround(q, r * 0.6), { color: YEL, overlap: 1, radius: 3, sparks: 10, light: false }); g.dmgArea(q, r, B * 5, { knock: 18, up: 8, stun: 0.5 }); };
        g.projectile({
          obj: grp, pos: start, vel: dir.multiplyScalar(30), life: 5, radius: 2.5, homing: tgt, homingRate: 3, faceVel: true, hitGround: false,
          onTick: (p, dt) => {
            acc += dt; if (acc > 0.04) { acc = 0; for (let i = 0; i < 3; i++) g.fx.bolt(p.clone(), p.clone().add(V(rand(-1, 1), rand(-1, 1), rand(-1, 1)).normalize().multiplyScalar(rand(3, 7))), { color: i ? YEL : CYAN, width: 0.25, life: 0.08, branches: 1, segs: 8 }); }
            for (let i = 0; i < g.fx.sparks.n(6); i++) g.fx.sparks.emit(p.x + rand(-1, 1), p.y + rand(-1, 1), p.z + rand(-1, 1), rand(-3, 3), rand(-3, 3), rand(-3, 3), yc, 0.4, 0.8);
            aura.scale.x = 2.6 + Math.sin(g.time * 30) * 0.3;
          },
          onHit: (p) => boom(p), onEnd: (p) => boom(p),
        });
      },
    },
    {
      name: 'Tormenta', cd: 8,
      cast: (g) => { g.playAnim('raise', 0.5); g.repeat(0.22, 17, () => { const p = randAround(g.aim, 32); g.fx.strike(p, { color: YEL, core: 0xfffbe0, overlap: 3, width: 1.1, radius: g.aoe(4.5) }); g.fx.explosion(p, g.aoe(4.5), { core: WHITE, edge: YEL, smoke: null, sparks: 25, light: false }); g.dmgArea(p, g.aoe(4.5), B * 1.6, { stun: 0.4 }); g.shake(p, 4, 0.2); }); },
    },
    {
      name: 'Juicio Celestial', cd: 12,
      cast: (g) => {
        g.playAnim('raise', 1.5); const p = g.aim.clone(); const r = g.aoe(7);
        const col = new THREE.Mesh(GEO.cyl, fresnelMat(CYAN, 1, 1.2, 0.2)); col.position.set(p.x, 60, p.z); col.scale.set(r, 120, r);
        g.fx.add(col, 1.8, (o, k) => { setOpacity((o as THREE.Mesh).material as THREE.Material, k * 0.8); o.scale.x = o.scale.z = r * (0.8 + Math.random() * 0.3); });
        g.repeat(0.05, 30, (i) => {
          g.fx.strike(randAround(p, 2), { color: i % 3 ? CYAN : YEL, core: WHITE, overlap: 3, width: 1.4, radius: r, height: 160, sparks: 12, ring: i % 5 === 0, light: i % 4 === 0 });
          if (i % 3 === 0) g.dmgArea(p, r, B * 1.2, { lift: [3, 7], stun: 3 });
          if (i % 6 === 0) g.shake(p, 7, 0.3);
        });
      },
    },
    {
      name: 'Destrucción de Bola de Trueno', cd: 20, hold: true,
      extra: (_g, s) => (s.holding ? `${Math.round((s.data.size ?? 0) * 100)}%` : ''),
      cast: (g, s) => {
        g.playAnim('raise', 99);
        const cloud = darkCloud(1.8); const ball = new THREE.Group();
        const core = new THREE.Mesh(GEO.sphere, new THREE.MeshStandardMaterial({ color: 0x050508, roughness: 0.2, metalness: 0.9 })); ball.add(core);
        const hal = new THREE.Mesh(GEO.sphere, fresnelMat(0x8a6bff, 1, 1.8)); hal.scale.setScalar(1.15); ball.add(hal);
        g.scene.add(cloud); g.scene.add(ball);
        s.data = { size: 0.05, acc: 0, cloud, ball, bt: 0 };
      },
      holdTick: (g, s, dt) => {
        const d = s.data; if (!d.ball) return false;
        d.acc += dt; while (d.acc >= 0.05) { d.acc -= 0.05; d.size = Math.min(1, d.size + 0.05); }
        const top = g.player.pos.clone().setY(45);
        d.cloud.position.copy(top).setY(55); d.cloud.rotation.y += dt * 0.3;
        d.ball.position.copy(top); d.ball.scale.setScalar(2 + d.size * 12);
        d.bt += dt; if (d.bt > 0.06) { d.bt = 0; const R = 2 + d.size * 12; g.fx.bolt(top.clone().add(V(rand(-1, 1), rand(-1, 1), rand(-1, 1)).normalize().multiplyScalar(R)), top.clone().add(V(rand(-1, 1), rand(-1, 1), rand(-1, 1)).normalize().multiplyScalar(R * 1.4)), { color: 0xb9a6ff, width: 0.4, life: 0.1, branches: 1, segs: 10 }); if (Math.random() < 0.3) g.fx.bolt(d.cloud.position.clone().add(V(rand(-10, 10), 0, rand(-10, 10))), top.clone(), { color: YEL, width: 0.5, life: 0.12 }); }
        return true;
      },
      release: (g, s) => {
        const d = s.data; if (!d.ball) return; g.playAnim('punch', 0.4);
        const ball: THREE.Group = d.ball, cloud: THREE.Group = d.cloud; const size = d.size; s.data = {};
        const target = g.aim.clone(); const from = ball.position.clone(); const dist = from.distanceTo(target);
        g.fx.add(cloud, 3, (o, k) => { o.traverse((c) => { const m = c as THREE.Mesh; if (m.material) (m.material as THREE.MeshLambertMaterial).opacity = k * 0.95; }); });
        g.task((_dt, t) => {
          const k = Math.min(1, (t * 50) / dist); ball.position.lerpVectors(from, target, k);
          if (k >= 1) {
            g.scene.remove(ball); disposeObj(ball);
            const maxR = g.aoe(20 + size * 75); const dome = new THREE.Mesh(GEO.sphere, fresnelMat(0x6a4dff, 1, 1.5, 0.12)); dome.position.copy(target); g.scene.add(dome);
            const inner = new THREE.Mesh(GEO.sphere, new THREE.MeshBasicMaterial({ color: 0x0a0616, transparent: true, opacity: 0.55, depthWrite: false })); dome.add(inner); inner.scale.setScalar(0.92);
            g.fx.explosion(target, 18, { core: WHITE, edge: 0x7a5cff, debris: 60, shake: 20 + size * 25 });
            let tick = 0;
            g.task((dt2, t2) => {
              const R = Math.min(maxR, 4 + 15 * t2); dome.scale.set(R, R * 0.75, R); tick += dt2;
              if (tick > 0.2) { tick = 0; g.dmgArea(target, R, B * (1 + size * 4), { small: true, color: '#b9a6ff' }); for (let i = 0; i < 3; i++) g.fx.bolt(target.clone().add(V(rand(-R, R) * 0.6, rand(0, R * 0.6), rand(-R, R) * 0.6)), target.clone().add(V(rand(-R, R) * 0.7, rand(0, R * 0.5), rand(-R, R) * 0.7)), { color: i ? 0xb9a6ff : YEL, width: 0.8, life: 0.2 }); g.shake(target, 5, 0.25); }
              setOpacity(dome.material as THREE.Material, t2 > 4.3 ? (5 - t2) / 0.7 : 1); (inner.material as THREE.MeshBasicMaterial).opacity = 0.55 * (t2 > 4.3 ? (5 - t2) / 0.7 : 1);
              if (t2 >= 5) { g.scene.remove(dome); disposeObj(dome); return false; }
            });
            return false;
          }
        });
      },
    },
    {
      name: 'Destello Eléctrico', cd: 1, charges: { max: 3, regen: 3, interval: 0.2 },
      extra: (_g, s) => `${s.charges}/3`,
      cast: (g) => {
        const dir = g.aimDir; const start = g.player.pos.clone(); const dist = 10; const dur = dist / 240; const hit = new Set<any>();
        g.fx.shell(start.clone().setY(1.2), 0.5, 3, YEL, 0.25);
        g.task((_dt, t) => {
          const k = Math.min(1, t / dur); g.player.pos.copy(start).addScaledVector(dir, dist * k);
          for (const e of g.enemies.inRadius(g.player.pos, 2.5, [])) if (!hit.has(e)) { hit.add(e); g.dmg(e, B * 1.5); e.stun(0.5); }
          if (k >= 1) {
            const end = g.player.pos.clone();
            for (let i = 0; i < 4; i++) g.fx.bolt(start.clone().setY(rand(0.6, 2.2)), end.clone().setY(rand(0.6, 2.2)), { color: i % 2 ? YEL : CYAN, width: 0.5, life: 0.25, branches: 2 });
            g.fx.burstSparks(end.clone().setY(1), 25, YEL, 12, 0.4, 0.4);
            return false;
          }
        });
      },
    },
    {
      name: 'Más Allá del Trueno', cd: 30,
      cast: (g) => {
        g.playAnim('raise', 1.2); const c = g.player.pos.clone();
        const N = 120; const im = new THREE.InstancedMesh(GEO.sphereLo, new THREE.MeshLambertMaterial({ color: 0x20232e, transparent: true, opacity: 0 }), N * 3);
        const cps: THREE.Vector3[] = []; const m4 = new THREE.Matrix4();
        for (let i = 0; i < N; i++) { const p = randAround(c, 160).setY(rand(60, 85)); cps.push(p); for (let j = 0; j < 3; j++) { m4.compose(p.clone().add(V(rand(-7, 7), rand(-1, 1), rand(-7, 7))), new THREE.Quaternion(), V(rand(5, 9), rand(2.5, 4), rand(5, 9))); im.setMatrixAt(i * 3 + j, m4); } }
        g.scene.add(im);
        g.task((_dt, t) => { (im.material as THREE.MeshLambertMaterial).opacity = Math.min(0.95, t, (14 - t) / 1.5 * 0.95); if (t > 14) { g.scene.remove(im); im.dispose(); (im.material as THREE.Material).dispose(); return false; } });
        g.repeat(0.1, N, (i) => {
          const cp = cps[(i * 37) % N]; const p = V(cp.x + rand(-5, 5), 0, cp.z + rand(-5, 5)); const r = g.aoe(16);
          const h = cp.y;
          for (let k = 0; k < 3; k++) g.fx.bolt(V(cp.x + rand(-4, 4), h, cp.z + rand(-4, 4)), p.clone(), { color: k ? YEL : 0xfff6b0, width: 1.5, life: 0.4, branches: 4, segs: 26 });
          g.fx.explosion(p, r, { core: WHITE, edge: YEL, smoke: 0x1c1f28, sparks: 40, shake: 6, light: i % 2 === 0 });
          g.dmgArea(p, r, B * 2.5, { stun: 3 });
        }, 0.8);
      },
    },
  ],
};

/* ----------------------------------------------------------------- pole */
export const pole: ItemDef = {
  id: 'pole', name: 'Pole', kind: 'sword', color: '#ffd84a', glyph: '†',
  passive: 'Combo 4 strikes a small lightning bolt.',
  m1: {
    interval: 0.1, comboLen: 4,
    fn: (g, combo) => {
      g.playAnim('swing', 0.1); const f = g.fwd; const p = g.player.pos.clone().addScaledVector(f, 3).setY(1.5);
      slashFx(g, p, f, 3.6, YEL, { tilt: [0.7, -0.7, 0][combo - 1] ?? 0.2, life: 0.15 });
      for (const e of g.enemies.inRadius(g.player.pos, 6.5, [])) { const d = e.pos.clone().sub(g.player.pos).setY(0).normalize(); if (d.dot(f) > 0.2) g.dmg(e, B * 0.6); }
      if (combo === 4) { const s = g.player.pos.clone().addScaledVector(f, 6); g.fx.strike(s, { color: YEL, overlap: 1, width: 0.6, height: 35, radius: 2.5, sparks: 14 }); g.dmgArea(s, 3, B * 1.5, { stun: 0.3 }); }
    },
  },
  skills: [
    {
      name: 'Asalto Atronador', cd: 3,
      cast: (g) => {
        g.playAnim('punch', 0.3); const dir = g.aimDir; const cloud = darkCloud(0.35); const start = g.player.pos.clone().addScaledVector(dir, 2).setY(2.5);
        cloud.position.copy(start); g.scene.add(cloud);
        let acc = 0;
        g.task((dt, t) => {
          if (t < 1) cloud.position.addScaledVector(dir, 25 * dt);
          cloud.rotation.y += dt * 2;
          if (t >= 1) { acc += dt; if (acc > 0.12) { acc = 0; const p = cloud.position.clone().add(V(rand(-1.5, 1.5), rand(-1, 0.5), rand(-1.5, 1.5))); const r = g.aoe(2); g.fx.explosion(p, r * 1.5, { core: WHITE, edge: YEL, smoke: null, sparks: 16, light: false, ring: false }); g.fx.bolt(cloud.position.clone(), p.clone().setY(0), { color: YEL, width: 0.4, life: 0.12, branches: 1 }); g.dmgArea(p, r + 1, B * 0.8, { small: true }); g.shake(p, 1.5, 0.1); } }
          if (t >= 3) { g.scene.remove(cloud); disposeObj(cloud); return false; }
        });
      },
    },
    {
      name: 'Juicio Continuo', cd: 10, hold: true,
      extra: (g, s) => (s.holding ? `R ${(8 * (1 + Math.min(0.5, 0.05 * (s.data.t ?? 0)))).toFixed(1)}m` : `${Math.round((g.player.hp / g.player.maxHp) * 100)}%HP`),
      cast: (g, s) => { if (g.player.hp <= g.player.maxHp * 0.5) return false; g.playAnim('raise', 99); s.data = { t: 0, acc: 0 }; },
      holdTick: (g, s, dt) => {
        const d = s.data; d.t += dt; d.acc += dt;
        const buff = Math.min(0.5, 0.05 * d.t); const R = g.aoe(8 * (1 + buff)); const suck = g.aoe(9 * (1 + buff));
        const p = g.aim.clone();
        for (const e of g.enemies.inRadius(p, suck, [])) { const v = p.clone().sub(e.pos).setY(0); if (v.length() > 1) e.pos.addScaledVector(v.normalize(), 14 * dt); }
        if (d.acc >= 0.12) {
          d.acc = 0;
          g.fx.strike(randAround(p, R * 0.3), { color: YEL, core: 0xfffbe6, overlap: 2, width: 1.2, radius: R, sparks: 14, ring: Math.random() < 0.3, light: Math.random() < 0.3 });
          g.dmgArea(p, R, B * 1.1, { small: true });
          g.player.hp -= g.player.maxHp * 0.01; g.shake(p, 3, 0.15);
          if (g.player.hp <= g.player.maxHp * 0.5) { g.player.hp = g.player.maxHp * 0.5; return false; }
        }
        return true;
      },
      release: (g) => { g.playAnim('', 0); },
    },
  ],
};
