import * as THREE from 'three';
import type { ItemDef } from '../types';
import type { Game } from '../Game';
import type { Enemy } from '../Enemies';
import { GEO, glowMat, fresnelMat, rand, randInt, setOpacity } from '../Effects';
import { B, V, asteroid, firePit, randAround, smallMeteor, slashFx, distinctPicker } from '../kit';

const PURPLE = 0xa64dff, DEEP = 0x5a12c8, PINK = 0xe7b6ff;

function vortex(g: Game, p: THREE.Vector3, r: number, life: number, color = PURPLE) {
  const grp = new THREE.Group(); grp.position.copy(p);
  const core = new THREE.Mesh(GEO.sphere, new THREE.MeshBasicMaterial({ color: 0x05000c })); core.scale.setScalar(r * 0.18); grp.add(core);
  const hal = new THREE.Mesh(GEO.sphere, fresnelMat(color, 1, 1.6)); hal.scale.setScalar(r * 0.3); grp.add(hal);
  const rings: THREE.Mesh[] = [];
  for (let i = 0; i < 5; i++) { const m = new THREE.Mesh(GEO.torus, glowMat(i % 2 ? PINK : color, 0.8)); m.scale.setScalar(r * (0.35 + i * 0.15)); m.rotation.set(rand(-1, 1), rand(0, 6), rand(-1, 1)); rings.push(m); grp.add(m); }
  const col = new THREE.Color(color);
  g.fx.add(grp, life, (_o, k, dt) => {
    rings.forEach((m, i) => { m.rotation.y += dt * (2 + i); m.rotation.x += dt * 0.6; });
    const s = Math.min(1, (1 - k) * 5); grp.scale.setScalar(s);
    for (let i = 0; i < g.fx.sparks.n(10); i++) { const a = Math.random() * 6.28, d = r * rand(0.8, 1.6), y = rand(-r * 0.3, r * 0.6); const q = V(p.x + Math.cos(a) * d, p.y + y, p.z + Math.sin(a) * d); const v = p.clone().sub(q).multiplyScalar(1.8); v.x += -Math.sin(a) * r; v.z += Math.cos(a) * r; g.fx.sparks.emit(q.x, q.y, q.z, v.x, v.y, v.z, col, 0.5, rand(0.4, 1.2)); }
  });
  return grp;
}

export const gravityFruit: ItemDef = {
  id: 'gravity', name: 'Gravity', kind: 'fruit', color: '#a64dff', glyph: '◉',
  skills: [
    {
      name: 'Asteroid', cd: 2,
      cast: (g) => { g.playAnim('raise', 0.4); const t = g.aim.clone(); asteroid(g, t, { radius: 25, dmg: B * 3, size: 8, color: 0xff6a1a, onLand: (p) => firePit(g, p, g.aoe(25), 10, 0.03) }); },
    },
    {
      name: 'Gravitational Pressure', cd: 4,
      cast: (g) => {
        g.playAnim('raise', 0.6);
        const C = V(0, 8, 0); const targets = g.enemies.list.filter((e) => e.alive);
        const n = targets.length; const mult = Math.min(20, 1 + 0.02 * n);
        vortex(g, C, 14, 1.6);
        const start = targets.map((e) => e.pos.clone());
        g.task((_dt, t) => {
          const k = Math.min(1, t / 1.3); const ease = k * k;
          targets.forEach((e, i) => { if (!e.alive) return; const a = Math.atan2(start[i].z, start[i].x) + ease * 4; const R = start[i].clone().setY(0).length() * (1 - ease) + 2; e.pos.set(Math.cos(a) * R, 8 * ease, Math.sin(a) * R); e.stun(0.3); e.vel.set(0, 0, 0); });
          if (t >= 1.4) {
            const r = g.aoe(20 * mult);
            g.fx.explosion(C.clone().setY(2), r, { core: 0xf3d6ff, edge: PURPLE, debris: 90, debrisColor: 0x3a2a4a, shards: 60, shardColor: PINK, shake: 14 + mult, smoke: 0x1c0f2a });
            g.fx.shell(C, 2, r * 1.4, DEEP, 1.6, { power: 3, op: 0.8 });
            g.dmgArea(V(0, 0, 0), r, B * 3 * mult, { knock: 30, up: 18 });
            return false;
          }
        });
      },
    },
    {
      name: 'Gravitational Lightning', cd: 6.5,
      cast: (g) => {
        g.playAnim('raise', 0.8);
        const base = g.player.pos.clone();
        // rising stacked rings pillar
        const grp = new THREE.Group(); grp.position.set(base.x, 0, base.z);
        const col = new THREE.Mesh(GEO.cyl, fresnelMat(PURPLE, 1, 1.4, 0.15)); col.scale.set(2.4, 40, 2.4); col.position.y = 20; grp.add(col);
        const rings: THREE.Mesh[] = [];
        for (let i = 0; i < 12; i++) { const r = new THREE.Mesh(GEO.torus, glowMat(i % 2 ? PINK : PURPLE, 0.9)); r.scale.setScalar(3.2 - i * 0.1); r.position.y = i * 1.4; rings.push(r); grp.add(r); }
        g.fx.add(grp, 1.1, (_o, k, dt) => { rings.forEach((r, i) => { r.position.y += dt * (18 + i * 3); r.rotation.z += dt * 3; setOpacity(r.material as THREE.Material, k); }); setOpacity(col.material as THREE.Material, k); col.scale.y = 40 + (1 - k) * 60; });
        g.repeat(0.25, 8, () => {
          const c = g.player.pos.clone(); let hits = g.enemies.inRadius(c, 17, []);
          const spots = hits.length ? hits.map((e) => e.pos.clone().setY(0)) : [randAround(c, 17), randAround(c, 17)];
          for (const s of spots) { g.fx.strike(s, { color: PURPLE, core: 0xf5e6ff, overlap: 3, width: 1.1, radius: 4, height: 90 }); }
          for (const e of hits) g.dmg(e, B * 1.2);
          g.shake(c, 4, 0.2);
          if (Math.random() < 0.12) { const n = randInt(1, 5); const o = spots[Math.floor(Math.random() * spots.length)]; for (let i = 0; i < n; i++) smallMeteor(g, randAround(o, 12), { speed: 110, radius: 8, dmg: B, color: 0xc06bff }); }
        }, 0.8);
      },
    },
    {
      name: 'Pressure Dereliction', cd: 7.5,
      cast: (g) => {
        g.playAnim('punch', 0.3);
        const pick = distinctPicker(g, () => g.player.pos, 160);
        for (let i = 0; i < 7; i++) {
          const target = pick(); const a = g.player.yaw + (i - 3) * 0.35;
          const pos = g.player.pos.clone().setY(2); const out = V(Math.sin(a), 0, Math.cos(a));
          const grp = new THREE.Group(); grp.position.copy(pos);
          const sh = new THREE.Mesh(GEO.sphere, fresnelMat(PURPLE, 1, 1.8, 0.1)); sh.scale.setScalar(4); grp.add(sh);
          const cr = new THREE.Mesh(GEO.sphereLo, new THREE.MeshBasicMaterial({ color: 0x0a0014 })); cr.scale.setScalar(1.3); grp.add(cr);
          const rg = new THREE.Mesh(GEO.torus, glowMat(PINK, 0.9)); rg.scale.setScalar(5); grp.add(rg);
          g.scene.add(grp);
          const booms = [0.7, 1.2, 1.7]; let bi = 0; let fallback = pos.clone().addScaledVector(out, 25);
          g.task((dt, t) => {
            const goal = target && target.alive ? target.pos.clone().setY(2) : fallback;
            if (t < 0.35) grp.position.addScaledVector(out, 50 * dt); else grp.position.lerp(goal, Math.min(1, dt * 7));
            rg.rotation.x += dt * 4; rg.rotation.y += dt * 3; sh.scale.setScalar(4 + Math.sin(t * 20) * 0.4);
            if (bi < 3 && t >= booms[bi]) {
              bi++; const p = grp.position.clone().setY(0.5); const r = g.aoe(10);
              g.fx.explosion(p, r, { core: 0xffe6ff, edge: DEEP, smoke: 0x1a0a28, sparks: 40, shards: 10, shardColor: PINK, shake: 6, flatten: 0.6 });
              g.fx.ring(p, 1, r * 1.5, PINK, 0.4, { thin: true });
              g.dmgArea(p, r, B * 1.6, { up: 4 });
            }
            if (t > 1.85) { g.scene.remove(grp); grp.traverse((c) => { const m = c as THREE.Mesh; if (m.material) (m.material as THREE.Material).dispose(); }); return false; }
            fallback = goal;
          });
        }
      },
    },
    {
      name: 'Asteroid Rain', cd: 10,
      cast: (g) => { g.playAnim('raise', 1); const c = g.player.pos.clone(); g.repeat(0.3, 8, () => asteroid(g, randAround(c, 90), { radius: 25, dmg: B * 3.5, size: 9, color: 0xff4d1a, shake: 18, onLand: (p) => firePit(g, p, g.aoe(25), 10, 0.05, { color: 0xff4a10 }) })); },
    },
    {
      name: 'Gravitational Punch', cd: 10,
      cast: (g) => {
        g.playAnim('charge', 0.8);
        const hand = new THREE.Mesh(GEO.sphere, fresnelMat(PURPLE, 1, 1.2, 0.3)); const dark = new THREE.Mesh(GEO.sphereLo, new THREE.MeshBasicMaterial({ color: 0x08000f })); dark.scale.setScalar(0.5); hand.add(dark);
        g.scene.add(hand); const col = new THREE.Color(PINK);
        g.task((_dt, t) => {
          const hp = g.handPos(); hand.position.copy(hp); hand.scale.setScalar(0.4 + t * 1.8);
          for (let i = 0; i < g.fx.sparks.n(12); i++) { const d = V(rand(-1, 1), rand(-1, 1), rand(-1, 1)).normalize().multiplyScalar(rand(6, 12)); const q = hp.clone().add(d); g.fx.sparks.emit(q.x, q.y, q.z, -d.x * 2.2, -d.y * 2.2, -d.z * 2.2, col, 0.45, 0.5); }
          const front = g.player.pos.clone().addScaledVector(g.fwd, 4);
          for (const e of g.enemies.inRadius(g.player.pos, 35, [])) { const dv = front.clone().sub(e.pos).setY(0); if (dv.length() > 2) e.pos.addScaledVector(dv.normalize(), Math.min(dv.length(), 30 * _dt)); e.stun(0.2); }
          if (t >= 0.8) { g.scene.remove(hand); (hand.material as THREE.Material).dispose(); return false; }
        });
        g.after(0.8, () => {
          g.playAnim('punch', 0.4);
          const f = g.fwd; const p = g.player.pos.clone().addScaledVector(f, 3).setY(1.5);
          g.shake(p, 42, 1.2);
          g.fx.explosion(p, 10, { core: 0xffffff, edge: PURPLE, sparks: 90, shards: 40, shardColor: PINK, smoke: 0x1a0a28 });
          const cone = new THREE.Mesh(GEO.cone, fresnelMat(PINK, 1, 1.3, 0.1)); cone.position.copy(p); cone.lookAt(p.clone().add(f)); cone.rotateX(Math.PI / 2);
          g.fx.add(cone, 0.5, (o, k) => { const s = 1 - k; o.scale.set(3 + s * 10, 4 + s * 30, 3 + s * 10); o.position.copy(p).addScaledVector(f, s * 14); setOpacity((o as THREE.Mesh).material as THREE.Material, k); });
          const hit = g.dmgArea(g.player.pos.clone().addScaledVector(f, 5), g.aoe(10), B * 6, { knock: 55, up: 22, from: g.player.pos });
          hit.forEach((e) => e.stun(2));
          const origin = g.player.pos.clone(); const right = V(f.z, 0, -f.x);
          for (let row = 0; row < 4; row++) {
            g.after(1.1 + row * 0.5, () => {
              const c = origin.clone().addScaledVector(f, 16 + row * 9);
              for (let j = 0; j < 4; j++) { const s = c.clone().addScaledVector(right, (j - 1.5) * 6); g.fx.strike(s, { color: row % 2 ? PURPLE : 0xc58cff, core: 0xffffff, overlap: 4, width: 1.6, radius: 6, height: 130 }); g.dmgArea(s, g.aoe(6), B * 3, { stun: 1 }); }
              g.shake(c, 12, 0.4);
            });
          }
        });
      },
    },
  ],
};

/* ---------------------------------------------------------------------- blade */
function bladeGlow(g: Game, on: number) {
  const held = g.handSlot.children[0]; const bl = held?.userData.blade as THREE.Mesh | undefined;
  if (bl) (bl.material as THREE.MeshBasicMaterial).color.set(PURPLE).multiplyScalar(1 + on * 4);
}
export const gravityBlade: ItemDef = {
  id: 'gblade', name: 'Gravity Blade', kind: 'sword', color: '#b46bff', glyph: '⟋',
  passive: 'Every 4th slash spawns 6–24 lightning bolts near the blade.',
  m1: {
    interval: 0.2, endLag: 0.4, comboLen: 4,
    fn: (g, combo) => {
      g.playAnim('swing', 0.18);
      const f = g.fwd; const p = g.player.pos.clone().addScaledVector(f, 2.5).setY(1.6);
      slashFx(g, p, f, 4.2, combo === 4 ? PINK : PURPLE, { tilt: combo % 2 ? 0.6 : -0.6 });
      for (const e of g.enemies.inRadius(g.player.pos, 7, [])) { const d = e.pos.clone().sub(g.player.pos).setY(0).normalize(); if (d.dot(f) > 0.2) { g.dmg(e, B * 0.8); e.knock(f, 4, 1); } }
      if (combo === 4) {
        const c = g.player.pos.clone().addScaledVector(f, 7); const n = randInt(6, 24);
        g.repeat(0.02, n, () => { const s = randAround(c, 8); g.fx.strike(s, { color: PURPLE, core: 0xf0dcff, overlap: 1, width: 0.6, radius: 2.5, height: rand(25, 45), sparks: 10, ring: false, light: Math.random() < 0.2 }); g.dmgArea(s, 3, B * 0.5, { small: true }); });
        g.shake(c, 5, 0.25);
      }
    },
  },
  skills: [
    {
      name: 'Superforce Lightning of Force', cd: 3,
      cdMul: (g) => (g.bladeCharge <= 0 ? 0.5 : 1),
      extra: (g) => `${Math.round(g.bladeCharge)}%`,
      cast: (g) => {
        g.playAnim('raise', 1.1); const charge = g.bladeCharge; const col = new THREE.Color(PINK);
        g.task((_dt, t) => { bladeGlow(g, Math.min(1, t)); const hp = g.handPos(); for (let i = 0; i < g.fx.sparks.n(6); i++) g.fx.sparks.emit(hp.x, hp.y + rand(0, 2.5), hp.z, rand(-3, 3), rand(1, 5), rand(-3, 3), col, 0.4, 0.6); if (t >= 1) { bladeGlow(g, 0); return false; } });
        g.after(1, () => {
          const tgt = g.enemies.nearest(g.aim, 30); const p = (tgt ? tgt.pos.clone() : g.aim.clone()).setY(0);
          const k = charge / 100; const R = g.aoe(8 + k * 14); const mega = charge >= 100 && Math.random() < 0.42;
          g.fx.strike(p, { color: PURPLE, core: 0xffffff, overlap: 3 + Math.round(k * 5), width: 1.5 + k * 3, radius: R, height: 220, life: 0.7, sparks: 120 });
          g.fx.explosion(p, R, { core: 0xffffff, edge: PURPLE, shards: 30, shardColor: PINK, shake: 10 + k * 22, smoke: 0x1a0a28 });
          const base = B * (0.5 + k * 9.5) * (mega ? 20 : 1);
          for (const e of g.enemies.inRadius(p, R, [])) {
            const d = Math.hypot(e.pos.x - p.x, e.pos.z - p.z); const chance = Math.max(0, 1 - d / R) * k; // lightningRangeFromBolt%
            e.blind(10);
            if (Math.random() < chance) { if (e.type === 'normal') g.dmg(e, e.hp + 1, { raw: true, color: '#ff66ff', big: true }); else g.dmg(e, e.maxHp * 0.5, { raw: true, color: '#ff66ff', big: true }); }
            else g.dmg(e, base, { big: mega, color: mega ? '#ff66ff' : undefined });
          }
          g.bladeCharge = Math.max(0, g.bladeCharge - 10);
        });
      },
    },
    {
      name: 'Rainy Meteors', cd: 5,
      cast: (g) => { g.playAnim('raise', 0.6); g.repeat(0.06, 80, () => smallMeteor(g, randAround(g.aim, 45), { speed: 130, radius: 12, dmg: B * 1.4, color: 0xb35cff, size: 1.4, shake: 3, debris: 6 })); },
    },
    {
      name: 'Rocks Extinction', cd: 7,
      cast: (g) => {
        g.playAnim('slam', 0.5);
        const offs: THREE.Vector3[] = []; const rocks: THREE.Mesh[] = []; const mat = new THREE.MeshStandardMaterial({ color: 0x4a3f38, roughness: 0.95, flatShading: true, emissive: 0x2a0a4a, emissiveIntensity: 0.5 });
        for (let i = 0; i < 26; i++) { const o = V(rand(-22, 22), 0, rand(-22, 22)); offs.push(o); const r = new THREE.Mesh(GEO.rock, mat); r.scale.setScalar(rand(2.2, 3.6)); r.castShadow = true; r.position.copy(g.player.pos).add(o).setY(-3); g.scene.add(r); rocks.push(r); g.fx.puff(r.position.clone().setY(0), 4, 0x3a3230, 3, 1.5, 4, 3); g.fx.debris(r.position.clone().setY(0), 4, 0x4a3f38, 8, 0.5, 2); }
        const heights = offs.map(() => rand(12, 22)); const released = new Array(26).fill(false);
        const pick = distinctPicker(g, () => g.player.pos, 170);
        g.task((dt, t) => {
          rocks.forEach((r, i) => { if (released[i]) return; const k = Math.min(1, t / 1.2); r.position.set(g.player.pos.x + offs[i].x, -3 + (heights[i] + 3) * (1 - Math.pow(1 - k, 3)) + Math.sin(t * 3 + i) * 0.4, g.player.pos.z + offs[i].z); r.rotation.x += dt; r.rotation.y += dt * 0.7; });
          return rocks.some((_r, i) => !released[i]);
        });
        g.repeat(0.15, 26, (i) => {
          released[i] = true; const r = rocks[i]; const tgt: Enemy | null = pick(); const dest = tgt ? tgt.pos.clone().setY(0) : randAround(g.player.pos, 40);
          const from = r.position.clone(); const tr = new THREE.Color(0xc58cff);
          g.task((_dt, t) => {
            const k = Math.min(1, t / 0.25); const goal = tgt && tgt.alive ? tgt.pos.clone().setY(0) : dest;
            r.position.lerpVectors(from, goal, k * k); r.position.y += Math.sin(k * Math.PI) * 6;
            g.fx.sparks.emit(r.position.x, r.position.y, r.position.z, 0, 0, 0, tr, 0.3, 2);
            if (k >= 1) { const R = g.aoe(24); g.fx.explosion(goal, R, { core: 0xffe8c0, edge: 0x9a4dff, debris: 50, debrisColor: 0x4a3f38, shake: 11, smoke: 0x2a2226 }); g.dmgArea(goal, R, B * 4, { knock: 18, up: 12 }); g.scene.remove(r); if (i === 25) mat.dispose(); return false; }
          });
        }, 1.2);
      },
    },
    {
      name: 'Death Slashes', cd: 3,
      cast: (g) => {
        const pick = distinctPicker(g, () => g.player.pos, 250);
        g.repeat(0.15, 23, (i) => {
          g.playAnim('swing', 0.14);
          const tgt = pick(); const mega = Math.random() < 0.22; const speed = mega ? 930 : 186;
          const f = g.fwd; const start = g.player.pos.clone().addScaledVector(f, 2).setY(2);
          const goal = tgt ? tgt.pos.clone().setY(1.5) : g.aim.clone().setY(1.5);
          const dir = goal.clone().sub(start).normalize();
          const m = new THREE.Mesh(GEO.crescent, new THREE.MeshBasicMaterial({ color: mega ? 0xff4dff : PURPLE, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
          m.scale.setScalar(mega ? 7 : 4.5); const tilt = i % 2 ? 0.8 : -0.8;
          const dmg = B * 3 * (mega ? 26 : 1);
          const col = new THREE.Color(mega ? 0xff9cff : PINK);
          g.projectile({
            obj: m, pos: start, vel: dir.multiplyScalar(speed), life: 2.5, radius: 2.5, homing: tgt, homingRate: 30, hitGround: false,
            onTick: (p) => { const vdir = tgt && tgt.alive ? tgt.pos.clone().sub(p).setY(0).normalize() : dir.clone().normalize(); m.lookAt(p.clone().add(vdir)); m.rotateY(-Math.PI / 2); m.rotateX(tilt); for (let k = 0; k < g.fx.sparks.n(4); k++) g.fx.sparks.emit(p.x, p.y, p.z, rand(-2, 2), rand(-2, 2), rand(-2, 2), col, 0.3, 1); },
            onHit: (p, e) => {
              const r = g.aoe(mega ? 6 * 26 : 6);
              g.fx.explosion(p.clone().setY(0.5), r, { core: 0xffffff, edge: mega ? 0xff3dff : PURPLE, shards: mega ? 80 : 12, shardColor: PINK, shake: mega ? 8 * 3 : 8, smoke: 0x1a0a28, debris: mega ? 80 : 0 });
              g.fx.strike(p.clone().setY(0), { color: PURPLE, core: 0xffffff, overlap: 2, width: mega ? 3 : 1, radius: 4 });
              for (const x of g.dmgArea(p, r, dmg, { crit: true, stun: 2 })) x.burn(10, dmg * 0.27);
              void e;
            },
            onEnd: (p) => { g.fx.explosion(p, 5, { core: 0xffffff, edge: PURPLE, smoke: null }); },
          });
        });
      },
    },
    {
      name: 'Super Slashes', cd: 4,
      cast: (g) => {
        let spawned = 0; const cols = [PURPLE, PINK, 0x7a2dff, 0xd28cff];
        g.task((_dt, t) => {
          const want = Math.min(300, Math.floor(t / 0.01)); let vis = 0;
          while (spawned < want) {
            spawned++; const p = randAround(g.player.pos, 50).setY(rand(1, 5));
            if (vis < 4) { vis++; const d = V(rand(-1, 1), rand(-0.4, 0.4), rand(-1, 1)).normalize(); slashFx(g, p, d, rand(6, 11), cols[spawned % 4], { tilt: rand(-1.5, 1.5), life: 0.2 }); }
            const dmg = B * 0.6;
            for (const e of g.dmgArea(p, g.aoe(7), dmg, { small: true })) e.bleed(5, dmg * 0.01);
          }
          if (Math.random() < 0.3) g.shake(g.player.pos, 3, 0.15);
          return t < 3;
        });
      },
    },
  ],
};
