import * as THREE from 'three';
import type { ItemDef } from '../types';
import type { Game } from '../Game';
import type { Enemy } from '../Enemies';
import { GEO, glowMat, fresnelMat, rand, randInt, disposeObj, setOpacity } from '../Effects';
import { B, V, firePit, auraRings, randAround } from '../kit';

const ICE = 0x8fe6ff, ICE2 = 0xd8f7ff, FIRE = 0xff6a14, FIRE2 = 0xffc23a;

function autoTarget(g: Game): Enemy | null {
  let t = g.enemies.nearest(g.aim, 25);
  if (!t) { const f = g.aimDir; let bs = -1; for (const e of g.enemies.list) { const d = e.pos.clone().sub(g.player.pos).setY(0); const L = d.length(); if (L > 180 || L < 0.1) continue; const dot = d.dot(f) / L; if (dot > 0.8 && dot - L / 500 > bs) { bs = dot - L / 500; t = e; } } }
  return t;
}
function muzzle(g: Game) { const m = g.handSlot.children[0]?.userData.muzzle as THREE.Object3D | undefined; const p = new THREE.Vector3(); if (m) m.getWorldPosition(p); else p.copy(g.handPos()); return p; }

/** single-draw-call fragment burst with real hit detection */
function fragmentBurst(g: Game, p: THREE.Vector3, n: number, speed: number, range: number, dmg: number, color: number, onHit?: (e: Enemy) => void) {
  const im = new THREE.InstancedMesh(GEO.octa, glowMat(color, 1), n); im.frustumCulled = false; g.scene.add(im);
  const pos: THREE.Vector3[] = [], vel: THREE.Vector3[] = [], alive: boolean[] = [];
  for (let i = 0; i < n; i++) { const a = Math.random() * 6.283; const v = V(Math.cos(a), rand(0.05, 0.5), Math.sin(a)).normalize().multiplyScalar(speed * rand(0.8, 1.1)); pos.push(p.clone().setY(p.y + 1)); vel.push(v); alive.push(true); }
  const life = range / speed; const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), s = V(0.4, 0.4, 1.6), z = V(0, 0, 1); const tmp: Enemy[] = []; const c = new THREE.Color(color);
  g.task((dt, t) => {
    for (let i = 0; i < n; i++) {
      if (!alive[i]) { m4.makeScale(0, 0, 0); im.setMatrixAt(i, m4); continue; }
      vel[i].y -= 12 * dt; pos[i].addScaledVector(vel[i], dt); if (pos[i].y < 0.2) { pos[i].y = 0.2; vel[i].y *= -0.3; }
      q.setFromUnitVectors(z, vel[i].clone().normalize()); m4.compose(pos[i], q, s); im.setMatrixAt(i, m4);
      if (Math.random() < 0.3) g.fx.sparks.emit(pos[i].x, pos[i].y, pos[i].z, 0, 0, 0, c, 0.25, 0.7);
      for (const e of g.enemies.inRadius(pos[i], 1.6, tmp)) { g.dmg(e, dmg, { small: true }); onHit?.(e); alive[i] = false; break; }
    }
    im.instanceMatrix.needsUpdate = true; setOpacity(im.material as THREE.Material, Math.min(1, (life - t) * 4));
    if (t >= life) { g.scene.remove(im); im.dispose(); (im.material as THREE.Material).dispose(); return false; }
  });
}

function tracer(g: Game, from: THREE.Vector3, to: THREE.Vector3, color: number) {
  const len = from.distanceTo(to); const m = new THREE.Mesh(GEO.cylSolid, glowMat(color, 1)); m.position.copy(from).add(to).multiplyScalar(0.5); m.lookAt(to); m.rotateX(Math.PI / 2); m.scale.set(0.06, len, 0.06);
  g.fx.add(m, 0.08, (o, k) => { o.scale.x = o.scale.z = 0.06 * k + 0.01; setOpacity((o as THREE.Mesh).material as THREE.Material, k); });
  g.fx.burstSparks(to, 6, color, 8, 0.25, 0.4, 5);
}

function gunFire(g: Game, cfg: { color: number; special: number; specialMul: number; cd: number; buffKey: 'ice' | 'fire'; buffMul: number; onSpecial: (target: Enemy | null, point: THREE.Vector3, dmg: number) => void; lowHpMul?: number }) {
  const buffed = g.buffs[cfg.buffKey] > g.time;
  g.m1Next = g.time + cfg.cd * (buffed ? 0.23 : 1);
  g.playAnim('aim', 0.25);
  const t = autoTarget(g); const from = muzzle(g); const to = t ? t.pos.clone().setY(t.pos.y + t.height * 0.55) : g.aim.clone().setY(1);
  if (t) g.player.yaw = Math.atan2(t.pos.x - g.player.pos.x, t.pos.z - g.player.pos.z);
  g.fx.sparks.emit(from.x, from.y, from.z, 0, 0, 0, new THREE.Color(cfg.color), 0.08, 1.2);
  let dmg = B * (buffed ? cfg.buffMul : 1);
  const low = t && cfg.lowHpMul && t.hp < t.maxHp * 0.5;
  if (low) dmg *= cfg.lowHpMul!;
  if (Math.random() < cfg.special) { cfg.onSpecial(t, to, dmg * cfg.specialMul); return; }
  tracer(g, from, to, cfg.color);
  if (t) g.dmg(t, dmg, { noProc: true });
}

function specialBullet(g: Game, from: THREE.Vector3, target: Enemy | null, to: THREE.Vector3, mesh: THREE.Object3D, color: number, onImpact: (p: THREE.Vector3, e: Enemy | null) => void) {
  const c = new THREE.Color(color);
  g.projectile({ obj: mesh, pos: from.clone(), vel: to.clone().sub(from).normalize().multiplyScalar(260), life: 1.5, radius: 1, homing: target, homingRate: 40, faceVel: true,
    onTick: (p) => { for (let i = 0; i < g.fx.sparks.n(4); i++) g.fx.sparks.emit(p.x, p.y, p.z, rand(-2, 2), rand(-2, 2), rand(-2, 2), c, 0.3, 0.9); },
    onHit: (p, e) => onImpact(p, e), onEnd: (p) => onImpact(p, null) });
}

function giantBall(g: Game, target: THREE.Vector3, o: { color: number; edge: number; size: number; radius: number; frags: number; fragSpeed: number; dmg: number; ice: boolean; onFragHit?: (e: Enemy) => void }) {
  const start = target.clone().add(V(rand(-20, 20), 140, rand(-20, 20)));
  const ball = new THREE.Group(); const core = new THREE.Mesh(GEO.ico, o.ice ? new THREE.MeshStandardMaterial({ color: ICE2, roughness: 0.05, metalness: 0.2, emissive: 0x3aa0d0, emissiveIntensity: 0.8, flatShading: true }) : glowMat(FIRE2, 1)); ball.add(core);
  const sh = new THREE.Mesh(GEO.sphere, fresnelMat(o.color, 1, 1.5, 0.1)); sh.scale.setScalar(1.3); ball.add(sh); ball.scale.setScalar(o.size);
  const c = new THREE.Color(o.color);
  g.projectile({ obj: ball, pos: start, vel: target.clone().sub(start).normalize().multiplyScalar(180), life: 3, radius: o.size, noEnemyHit: true,
    onTick: (p, dt) => { ball.rotation.x += dt * 3; for (let i = 0; i < g.fx.sparks.n(10); i++) g.fx.sparks.emit(p.x + rand(-1, 1) * o.size, p.y + rand(-1, 1) * o.size, p.z + rand(-1, 1) * o.size, rand(-3, 3), rand(3, 10), rand(-3, 3), c, 0.6, 2.5); },
    onHit: (p) => {
      const r = g.aoe(o.radius);
      g.fx.explosion(p, r, { core: o.ice ? 0xffffff : 0xfff0b0, edge: o.edge, smoke: o.ice ? 0x9fc6d8 : 0x2a1a12, debris: o.ice ? 0 : 60, shards: 120, shardColor: o.color, shake: 22 });
      g.dmgArea(p, r, o.dmg, { knock: 20, up: 10, freeze: o.ice ? 2 : 0, burn: o.ice ? undefined : [3, o.dmg * 0.02] });
      fragmentBurst(g, p, o.frags, o.fragSpeed, r, o.dmg * 0.25, o.color, o.onFragHit);
    } });
}

/* ================================================================ RIMEFRACTURE */
export const rimeFruit: ItemDef = {
  id: 'rime', name: 'Rimefracture', kind: 'fruit', color: '#8fe6ff', glyph: '❄',
  passive: 'Ice rifle: manual fire (0.05s), auto-aim precision shots. 45% icicle bullet (+7500% dmg) calls a giant ice ball (60m) that shatters into 120m/s fragments.',
  m1: {
    interval: 0.05, manual: true, comboLen: 1,
    fn: (g) => gunFire(g, {
      color: ICE, special: 0.45, specialMul: 76, cd: 0.05, buffKey: 'ice', buffMul: 7253.25,
      onSpecial: (t, to, dmg) => {
        const ic = new THREE.Mesh(GEO.cone, new THREE.MeshStandardMaterial({ color: ICE2, emissive: 0x4ab8e8, emissiveIntensity: 1, roughness: 0.1 })); ic.scale.set(0.35, 2.2, 0.35); const w = new THREE.Group(); ic.rotation.x = Math.PI / 2; w.add(ic);
        specialBullet(g, muzzle(g), t, to, w, ICE, (p, e) => { if (e) g.dmg(e, dmg, { big: true, color: '#9ff0ff', noProc: true }); g.fx.burstSparks(p, 20, ICE, 12, 0.4, 0.6); giantBall(g, (e ? e.pos : p).clone().setY(0), { color: ICE, edge: 0x5ac8ff, size: 6, radius: 60, frags: randInt(18, 30), fragSpeed: 120, dmg: dmg * 0.3, ice: true }); });
      },
    }),
  },
  skills: [
    {
      name: 'Icy Power', cd: 3.5,
      cast: (g) => {
        g.playAnim('raise', 0.6); const c = g.aim.clone();
        g.repeat(0.13, 17, () => {
          const tgt = randAround(c, 20); const ic = new THREE.Mesh(GEO.cone, new THREE.MeshStandardMaterial({ color: ICE2, roughness: 0.05, metalness: 0.1, emissive: 0x3aa8e0, emissiveIntensity: 0.7, flatShading: true }));
          ic.scale.set(2.2, 12, 2.2); ic.rotation.x = Math.PI; const start = tgt.clone().setY(130).add(V(rand(-8, 8), 0, rand(-8, 8)));
          const dmg = B * 4; const col = new THREE.Color(ICE);
          g.projectile({ obj: ic, pos: start, vel: tgt.clone().sub(start).normalize().multiplyScalar(160), life: 2, radius: 2, noEnemyHit: true,
            onTick: (p) => { for (let i = 0; i < g.fx.sparks.n(4); i++) g.fx.sparks.emit(p.x, p.y + 6, p.z, rand(-1, 1), 4, rand(-1, 1), col, 0.4, 1.4); },
            onHit: (p) => { const r = g.aoe(45); g.fx.explosion(p, r, { core: 0xffffff, edge: 0x5ac8ff, smoke: 0xa8d0e0, shards: 60, shardColor: ICE, shake: 9 }); g.dmgArea(p, r, dmg, { freeze: 0.5 }); fragmentBurst(g, p, randInt(20, 40), 70, 40, dmg * 0.5, ICE); } });
        });
      },
    },
    {
      name: 'Ice Bombard', cd: 30,
      extra: (g) => (g.buffs.ice > g.time ? `${Math.ceil(g.buffs.ice - g.time)}s` : ''),
      cast: (g) => { g.buffs.ice = g.time + 15; g.playAnim('raise', 0.6); g.fx.shell(g.player.pos.clone().setY(1.5), 0.5, 14, ICE, 0.7); g.fx.debris(g.player.pos, 40, ICE, 14, 0.4, 2, true); auraRings(g, ICE, () => g.buffs.ice > g.time, 1.2); },
    },
    {
      name: 'Snowy Destruction', cd: 8,
      cast: (g) => {
        g.player.invT = Math.max(g.player.invT, 0.6); g.playAnim('charge', 0.5); const col = new THREE.Color(ICE);
        g.task((_dt, t) => { const p = g.player.pos; for (let i = 0; i < g.fx.sparks.n(20); i++) { const a = Math.random() * 6.28, d = rand(4, 10); g.fx.sparks.emit(p.x + Math.cos(a) * d, rand(0, 3), p.z + Math.sin(a) * d, -Math.cos(a) * d * 2.5, 0, -Math.sin(a) * d * 2.5, col, 0.4, 0.7); } return t < 0.5; });
        g.after(0.5, () => {
          g.playAnim('slam', 0.3); const p = g.player.pos.clone(); const R = 3500;
          g.flashScreen(150, 225, 255, 0.9, 1.8);
          g.shake(p, 45, 12, true);
          const dome = new THREE.Mesh(GEO.sphere, fresnelMat(ICE, 1, 1.3, 0.08)); dome.position.copy(p); g.scene.add(dome);
          g.task((_dt, t) => { const k = Math.min(1, t / 2.5); const r = 3 + (R - 3) * (1 - Math.pow(1 - k, 3)); dome.scale.set(r, r * 0.35, r); setOpacity(dome.material as THREE.Material, 1 - k * 0.8); if (t >= 3) { g.scene.remove(dome); disposeObj(dome); return false; } });
          g.fx.ring(p, 2, 600, ICE2, 2.5); g.fx.ring(p, 2, 200, ICE, 1.5); g.fx.explosion(p, 40, { core: 0xffffff, edge: ICE, smoke: 0xcfe8f5, shards: 300, shardColor: ICE, light: true });
          g.fx.debris(p, 200, 0xbfe6f5, 60, 2.2, 8, true);
          // jutting ice crystals debris field
          const crystals: THREE.Mesh[] = []; const cm = new THREE.MeshStandardMaterial({ color: ICE2, roughness: 0.05, metalness: 0.2, emissive: 0x2a8ac0, emissiveIntensity: 0.5, flatShading: true, transparent: true, opacity: 0.9 });
          for (let i = 0; i < 70; i++) { const q = randAround(p, 90); const m = new THREE.Mesh(GEO.cone, cm); const h = rand(4, 16); m.scale.set(h * 0.25, h, h * 0.25); m.position.set(q.x, h * 0.4, q.z); m.rotation.set(rand(-0.5, 0.5), 0, rand(-0.5, 0.5)); m.castShadow = true; g.scene.add(m); crystals.push(m); }
          const hit = g.enemies.inRadius(p, R, []); hit.forEach((e) => { e.freeze(10); g.dmg(e, B * 10); });
          let acc = 0;
          g.task((dt, t) => {
            acc += dt; if (acc > 0.5) { acc = 0; for (const e of hit) if (e.alive) g.dmg(e, B * 1.5, { small: true, color: '#9ff0ff' }); }
            if (t > 9) cm.opacity = 0.9 * Math.max(0, (10 - t));
            if (t >= 10) { crystals.forEach((m) => g.scene.remove(m)); cm.dispose(); return false; }
          });
        });
      },
    },
  ],
};

/* ================================================================ WILDFIRE */
function orangeBolt(g: Game, e: Enemy) { if (!e.gate('obolt', g.time, 0.4)) return; g.fx.strike(e.pos.clone(), { color: 0xff8a1a, core: 0xfff0c0, overlap: 1, width: 0.8, height: 50, radius: 2.5, sparks: 10, light: false, ring: false }); e.burn(3, e.maxHp * 0.01); }

function lobbed(g: Game, dir: THREE.Vector3, dist: number, o: { size: number; radius: number; dmg: number; pitDur: number; pitPct: number; lava: boolean }) {
  const start = g.handPos(); const T = rand(0.6, 0.9); const target = g.player.pos.clone().addScaledVector(dir, dist);
  const grav = 60; const vel = target.clone().sub(start).divideScalar(T); vel.y = (target.y - start.y) / T + 0.5 * grav * T;
  const m = new THREE.Mesh(o.lava ? GEO.rock : GEO.sphereLo, o.lava ? new THREE.MeshStandardMaterial({ color: 0x2a0a02, emissive: 0xff3a00, emissiveIntensity: 1.3, flatShading: true }) : glowMat(FIRE2, 1));
  m.scale.setScalar(o.size); const c = new THREE.Color(o.lava ? 0xff4a0a : FIRE); const sc = new THREE.Color(0x2a1a14);
  g.projectile({ obj: m, pos: start, vel, gravity: grav, life: 3, radius: o.size, noEnemyHit: true,
    onTick: (p) => { for (let i = 0; i < g.fx.sparks.n(3); i++) g.fx.sparks.emit(p.x, p.y, p.z, rand(-2, 2), rand(0, 3), rand(-2, 2), c, 0.35, o.size * 1.6); if (o.lava && Math.random() < 0.4) g.fx.smoke.emit(p.x, p.y, p.z, 0, 1, 0, sc, 1, o.size * 2, 0, 0.5, 0.5, 1); },
    onHit: (p) => {
      const r = g.aoe(o.radius);
      g.fx.explosion(p, r, { core: 0xffe7a0, edge: o.lava ? 0xff3a00 : FIRE, smoke: 0x2a1a12, sparks: o.lava ? 90 : 35, debris: o.lava ? 30 : 0, debrisColor: 0x2a1208, shake: o.lava ? 10 : 4, light: Math.random() < 0.3, dur: 0.7 });
      const hits = g.dmgArea(p, r, o.dmg, { burn: [3, o.dmg * 0.05] });
      if (o.lava) hits.forEach((e) => orangeBolt(g, e));
      firePit(g, p, r * (o.lava ? 0.8 : 0.6), o.pitDur, o.pitPct, { color: o.lava ? 0xff3a00 : FIRE, onTickHit: o.lava ? (e) => orangeBolt(g, e) : undefined, tick: 0.5 });
    } });
}

export const wildfireFruit: ItemDef = {
  id: 'wildfire', name: 'Wildfire', kind: 'fruit', color: '#ff6a14', glyph: '♨',
  passive: 'Flame rifle: manual fire (0.1s), auto-aim precision shots. 35% fireball (+15000% dmg) calls a giant fiery ball (65m) → 30–60 fragments that call orange lightning. <50% HP targets: +1000% dmg, +300% AoE.',
  m1: {
    interval: 0.1, manual: true, comboLen: 1,
    fn: (g) => gunFire(g, {
      color: FIRE, special: 0.35, specialMul: 151, cd: 0.1, buffKey: 'fire', buffMul: 12501, lowHpMul: 11,
      onSpecial: (t, to, dmg) => {
        const fb = new THREE.Mesh(GEO.sphereLo, glowMat(FIRE2, 1)); fb.scale.setScalar(0.7);
        const low = !!t && t.hp < t.maxHp * 0.5;
        specialBullet(g, muzzle(g), t, to, fb, FIRE, (p, e) => { if (e) g.dmg(e, dmg, { big: true, color: '#ffae4a', noProc: true }); giantBall(g, (e ? e.pos : p).clone().setY(0), { color: FIRE, edge: 0xff3a00, size: 6.5, radius: 65 * (low ? 4 : 1), frags: randInt(30, 60), fragSpeed: 150, dmg: dmg * 0.3 * (low ? 2 : 1), ice: false, onFragHit: (x) => orangeBolt(g, x) }); });
      },
    }),
  },
  skills: [
    { name: 'Firestorm', cd: 5, cast: (g) => { g.playAnim('aim', 5.3); const base = Math.atan2(g.aimDir.x, g.aimDir.z); const dist = Math.max(25, Math.min(120, g.aim.distanceTo(g.player.pos))); g.repeat(0.035, 150, () => { const a = base + THREE.MathUtils.degToRad(rand(-15, 15)); lobbed(g, V(Math.sin(a), 0, Math.cos(a)), dist * rand(0.7, 1.3), { size: 0.9, radius: 30, dmg: B * 1.2, pitDur: 6, pitPct: 0.01, lava: false }); }); } },
    {
      name: 'Hell Fury', cd: 30,
      extra: (g) => (g.buffs.fire > g.time ? `${Math.ceil(g.buffs.fire - g.time)}s` : ''),
      cast: (g) => { g.buffs.fire = g.time + 15; g.playAnim('raise', 0.6); g.fx.explosion(g.player.pos.clone(), 10, { core: 0xffe7a0, edge: FIRE, smoke: 0x2a1a12, sparks: 100 }); auraRings(g, FIRE, () => g.buffs.fire > g.time, 1.2); },
    },
    { name: 'Burning Lightning', cd: 5, cast: (g) => { g.playAnim('aim', 4.2); const base = Math.atan2(g.aimDir.x, g.aimDir.z); const dist = Math.max(35, Math.min(140, g.aim.distanceTo(g.player.pos))); g.repeat(0.1, 40, () => { const a = base + THREE.MathUtils.degToRad(rand(-30, 30)); lobbed(g, V(Math.sin(a), 0, Math.cos(a)), dist * rand(0.7, 1.3), { size: 2.4, radius: 50, dmg: B * 3, pitDur: 10, pitPct: 0.015, lava: true }); }); } },
  ],
};
