import * as THREE from 'three';
import type { ItemDef } from '../types';
import type { Game } from '../Game';
import { GEO, glowMat, fresnelMat, rand, disposeObj } from '../Effects';
import { B, V, quakeCracks, airCracks, tsunami, slashFx } from '../kit';

const NEON = 0x2ec8ff, WHITE = 0xffffff;

function leftHand(g: Game) { const p = new THREE.Vector3(); (g.parts.handL as THREE.Object3D).getWorldPosition(p); return p; }

function whiteShock(g: Game, p: THREE.Vector3, r: number, life = 0.8) {
  g.fx.shell(p, 1, r, 0xf2fbff, life, { power: 1.4, op: 0.9, additive: false, base: 0.12, flatten: 0.55 });
  g.fx.ring(p, 1, r * 1.1, 0xe8f8ff, life * 0.9, { op: 0.8 });
  g.fx.ring(p, 1, r * 0.8, NEON, life * 0.7, { thin: true });
}

function quakeOrb(g: Game, start: THREE.Vector3, dir: THREE.Vector3, o: { size: number; speed: number; life: number; pierce: boolean; dmg: number; stun: number; boomR: number }) {
  const grp = new THREE.Group();
  const core = new THREE.Mesh(GEO.sphere, glowMat(0xe9f8ff, 0.9)); core.scale.setScalar(o.size * 0.55); grp.add(core);
  const sh = new THREE.Mesh(GEO.sphere, fresnelMat(0xffffff, 1, 1.6, 0.1)); sh.scale.setScalar(o.size); grp.add(sh);
  const rg = new THREE.Mesh(GEO.torus, glowMat(NEON, 0.9)); rg.scale.setScalar(o.size * 1.2); grp.add(rg);
  let acc = 0;
  const boom = (p: THREE.Vector3) => { const r = g.aoe(o.boomR); whiteShock(g, p, r, 0.6); airCracks(g, p, r * 0.8, 10); g.fx.explosion(p, r * 0.6, { core: WHITE, edge: 0xcfeeff, smoke: 0x8a96a6, shards: 18, shardColor: 0xdff6ff, shake: 6, light: false }); g.dmgArea(p, r, o.dmg * 0.6, { knock: 20, up: 6, stun: o.stun }); };
  g.projectile({
    obj: grp, pos: start, vel: dir.clone().multiplyScalar(o.speed), life: o.life, radius: o.size, pierce: o.pierce, hitGround: false,
    onTick: (p, dt) => { rg.rotation.x += dt * 6; rg.rotation.y += dt * 4; acc += dt; if (acc > 0.05) { acc = 0; airCracks(g, p, o.size * 1.8, 2, NEON, 0.15); } },
    onHit: (p, e) => { if (e) { g.dmg(e, o.dmg); e.stun(o.stun); e.knock(dir, 20, 5); } if (!o.pierce) boom(p); },
    onEnd: (p) => boom(p),
  });
}

export const quakeFruit: ItemDef = {
  id: 'quake', name: 'Quake', kind: 'fruit', color: '#e8f8ff', glyph: '▦',
  skills: [
    {
      name: 'Fatal Destruction', cd: 5,
      cast: (g) => {
        const f = g.aimDir; let best = null as any, bd = 1e9;
        for (const e of g.enemies.inRadius(g.player.pos, 25, [])) { const d = e.pos.clone().sub(g.player.pos).setY(0); const L = d.length(); if (L > 0.1 && d.dot(f) / L > 0.55 && L < bd) { bd = L; best = e; } }
        g.playAnim('charge', 0.3);
        airCracks(g, g.handPos(), 2.5, 5, NEON, 0.3);
        if (!best) return false; // nothing caught -> nothing happens
        const e = best; const front = g.player.pos.clone().addScaledVector(f, 3);
        g.task((dt, t) => { e.pos.lerp(front, Math.min(1, dt * 18)); e.stun(2); return t < 0.25; });
        g.after(0.25, () => {
          g.worldPause = 1.1;
          g.task((_dt, t) => { g.redTint = Math.min(1, t / 1); return t < 1; });
          g.after(1, () => {
            g.redTint = 0; g.playAnim('punch', 0.4);
            const hp = g.handPos(); const p = front.clone().setY(1.5);
            airCracks(g, hp, 9, 18, NEON, 0.6); whiteShock(g, p, 22, 0.9); quakeCracks(g, p.clone().setY(0), 30, 12);
            g.fx.explosion(p, 12, { core: WHITE, edge: 0xdff6ff, smoke: 0x8a96a6, shards: 40, shardColor: 0xe0f7ff, debris: 50, shake: 32 });
            g.dmg(e, B * 25, { big: true }); e.knock(f, 95, 30);
            g.dmgArea(p, g.aoe(10), B * 6, { knock: 50, up: 15, from: g.player.pos, filter: (x) => x !== e });
          });
        });
      },
    },
    {
      name: 'Air Crusher', cd: 7,
      cast: (g) => { g.playAnim('punch', 0.4); const hp = g.handPos(); airCracks(g, hp, 6, 14, NEON, 0.5); g.fx.shell(hp, 0.5, 5, 0xffffff, 0.3, { additive: false, base: 0.1 }); quakeOrb(g, hp.clone().addScaledVector(g.aimDir, 3), g.aimDir, { size: 4, speed: 45, life: 2, pierce: true, dmg: B * 4, stun: 2, boomR: 16 }); g.shake(hp, 8, 0.3); },
    },
    {
      name: 'Spatial Shockwave', cd: 7,
      cast: (g) => {
        g.playAnim('slam', 0.45);
        g.after(0.22, () => {
          const p = g.player.pos.clone(); const r = g.aoe(45);
          airCracks(g, g.handPos(), 4, 10, NEON, 0.8); airCracks(g, leftHand(g), 4, 10, NEON, 0.8);
          whiteShock(g, p, r, 1.1); quakeCracks(g, p, r, 18, NEON, 1.8);
          g.fx.debris(p, 140, 0x5a6573, 34, 1.2, 4); g.fx.puff(p, 40, 0x6e7885, r * 0.4, 2.5, 6, 3);
          g.shake(p, 22, 0.8);
          g.dmgArea(p, r, B * 5, { stun: 5, knock: 38, up: 9 });
        });
      },
    },
    {
      name: 'Seaquake', cd: 14.5,
      cast: (g) => {
        g.playAnim('slam', 0.45); const c = g.player.pos.clone();
        for (let i = 0; i < 3; i++) g.after(0.2 + i * 0.15, () => { const r = g.aoe(20 + i * 18); whiteShock(g, c, r, 0.6); quakeCracks(g, c, r, 10, NEON, 1.4); g.shake(c, 12, 0.4); g.dmgArea(c, r, B * 2, { knock: 15, up: 5 }); });
        g.after(0.6, () => {
          const sides = [V(1, 0, 0), V(-1, 0, 0), V(0, 0, 1), V(0, 0, -1)];
          for (const s of sides) {
            const dir = s.clone().negate(); const right = V(dir.z, 0, -dir.x);
            for (let j = -1; j <= 1; j++) tsunami(g, c.clone().addScaledVector(s, 110).addScaledVector(right, j * 30), dir, { width: 28, height: 7, speed: 45, dist: 220, dmg: B * 2, hitEvery: 0.3 });
            g.after(0.4, () => tsunami(g, c.clone().addScaledVector(s, 120), dir, { width: 110, height: 30, speed: 45, dist: 240, dmg: B * 6, color: 0x155a8f, knock: 30, hitEvery: 0.3 }));
          }
        });
      },
    },
  ],
};

export const bisento: ItemDef = {
  id: 'bisento', name: 'Bisento', kind: 'sword', color: '#bfefff', glyph: '⚚',
  m1: {
    interval: 0.3, comboLen: 3,
    fn: (g, combo) => {
      g.playAnim('swing', 0.25); const f = g.fwd; const p = g.player.pos.clone().addScaledVector(f, 3).setY(1.4);
      slashFx(g, p, f, 5, 0xdff6ff, { tilt: combo === 2 ? -0.5 : 0.5, life: 0.2 });
      for (const e of g.enemies.inRadius(g.player.pos, 7.5, [])) { const d = e.pos.clone().sub(g.player.pos).setY(0).normalize(); if (d.dot(f) > 0.2) { g.dmg(e, B * 1.1); e.knock(f, 6, 1); } }
    },
  },
  skills: [
    {
      name: 'Quake Slam', cd: 2,
      cast: (g) => {
        g.playAnim('slam', 0.4);
        g.after(0.2, () => { const p = g.player.pos.clone().addScaledVector(g.fwd, 4); const r = g.aoe(26); whiteShock(g, p, r, 0.8); quakeCracks(g, p, r, 12, NEON, 1.3); g.fx.debris(p, 50, 0x5a6573, 22, 0.8, 3); g.shake(p, 14, 0.5); g.dmgArea(p, r, B * 3, { stun: 2.5, knock: 70, up: 20 }); });
      },
    },
    {
      name: 'Quake Ball', cd: 3,
      cast: (g) => { g.playAnim('swing', 0.3); const base = Math.atan2(g.aimDir.x, g.aimDir.z); const hp = g.player.pos.clone().setY(1.8); for (let i = 0; i < 5; i++) { const a = base + (i - 2) * 0.22; const d = V(Math.sin(a), 0, Math.cos(a)); quakeOrb(g, hp.clone().addScaledVector(d, 2), d, { size: 1.2, speed: 60, life: 1.5, pierce: false, dmg: B * 2.2, stun: 0.8, boomR: 8 }); } },
    },
    {
      name: 'Mini Seaquake', cd: 5,
      cast: (g) => {
        g.playAnim('slam', 0.4); const c = g.player.pos.clone();
        g.after(0.2, () => { whiteShock(g, c, g.aoe(14), 0.5); quakeCracks(g, c, 18, 8); g.shake(c, 8, 0.3);
          for (let i = 0; i < 23; i++) { const a = rand(0, Math.PI * 2); const s = V(Math.cos(a), 0, Math.sin(a)); tsunami(g, c.clone().addScaledVector(s, 70), s.clone().negate(), { width: 14, height: 5, speed: 40, dist: 140, dmg: B * 1.3, hitEvery: 0.4 }); } });
      },
    },
  ],
};
void disposeObj;
