import { useEffect, useRef, useState } from 'react';
import type { Game } from '../game/Game';
import { fmt } from '../game/Game';
import { PRESETS, SKILL_KEYS, type GraphicsSettings } from '../game/types';

const SLOT_KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-'];

function useTick(ms = 33) {
  const [, set] = useState(0);
  useEffect(() => { let raf = 0, last = 0; const f = (t: number) => { raf = requestAnimationFrame(f); if (t - last >= ms) { last = t; set((x) => (x + 1) % 1e6); } }; raf = requestAnimationFrame(f); return () => cancelAnimationFrame(raf); }, [ms]);
}

/* ------------------------------------------------------------ skill panel */
function SkillPanel({ g, open, setOpen }: { g: Game; open: boolean; setOpen: (b: boolean) => void }) {
  const it = g.item;
  if (!open) return (
    <button onClick={() => setOpen(true)} className="sf-btn absolute right-0 top-1/2 -translate-y-1/2 px-2 py-3 text-[10px] pointer-events-auto" style={{ writingMode: 'vertical-rl' }}>SKILLS ◂</button>
  );
  return (
    <div className="absolute right-2 top-1/2 -translate-y-1/2 w-[244px] max-w-[46vw] pointer-events-auto sf-panel p-1.5">
      <div className="flex items-center justify-between px-1 pb-1 mb-1 border-b border-cyan-300/20">
        <div className="font-orb text-[10px] tracking-[0.2em] text-cyan-200 sf-glow truncate">
          {it ? <><span style={{ color: it.color }}>{it.glyph}</span> {it.name.toUpperCase()}</> : 'NO ITEM EQUIPPED'}
        </div>
        <button onClick={() => setOpen(false)} className="text-cyan-300/70 hover:text-white text-xs px-1 font-orb" title="Close (H)">✕</button>
      </div>
      {!it && <div className="text-[11px] text-cyan-100/60 px-1 py-2">Equip a fruit or sword from the inventory slots below.</div>}
      {it?.m1 && (
        <div className="text-[10px] text-cyan-100/60 px-1 pb-1 font-orb tracking-wider">M1 · {it.m1.interval}s{it.m1.endLag ? ` · END-LAG ${it.m1.endLag}s` : ''}{it.m1.manual ? ' · MANUAL' : ''}</div>
      )}
      <div className="flex flex-col gap-[3px]">
        {it?.skills.map((s, i) => {
          const st = g.skillStates[it.id][i];
          const rem = Math.max(0, st.cdEnd - g.time); const frac = rem > 0 ? rem / st.cdTotal : 0; const ready = rem <= 0 && (!s.charges || st.charges > 0);
          const extra = s.extra?.(g, st);
          const gpSel = g.gpSkillSel === i;
          return (
            <div key={i} className="flex items-stretch gap-1">
              {g.touchMode && (
                <button
                  onPointerDown={(e) => { e.preventDefault(); g.pressSkill(i); }}
                  onPointerUp={() => g.releaseSkill(i)} onPointerLeave={() => g.releaseSkill(i)} onPointerCancel={() => g.releaseSkill(i)}
                  className="sf-btn text-[9px] px-2 min-w-[38px] font-bold" style={{ opacity: ready ? 1 : 0.5 }}>USE</button>
              )}
              <div className="relative flex-1 h-[24px] overflow-hidden slot border" style={{ borderColor: st.holding ? '#fff' : ready ? 'rgba(94,242,255,.45)' : 'rgba(94,242,255,.15)', background: 'rgba(3,12,22,.75)', boxShadow: gpSel ? '0 0 0 1px #ffd84a inset' : undefined }}>
                {/* cooldown: whole-bar 100% -> 0% sweep */}
                <div className="absolute inset-y-0 left-0" style={{ width: `${frac * 100}%`, background: `linear-gradient(90deg, ${it.color}55, ${it.color}22)`, borderRight: frac > 0 ? `1px solid ${it.color}` : 'none' }} />
                {ready && <div className="absolute inset-0" style={{ background: `linear-gradient(90deg, ${it.color}22, transparent 70%)` }} />}
                <div className="relative flex items-center h-full px-1.5 gap-1.5">
                  {!g.touchMode && <span className="font-orb text-[10px] w-4 text-center font-bold" style={{ color: ready ? it.color : '#6b8595' }}>{SKILL_KEYS[i]}</span>}
                  <span className="text-[11.5px] font-semibold leading-none truncate flex-1" style={{ color: ready ? '#e6fbff' : '#7d93a3' }}>{s.name}</span>
                  {extra && <span className="font-orb text-[9px] text-amber-200/90">{extra}</span>}
                  {rem > 0 && <span className="font-orb text-[10px] text-white tabular-nums">{rem.toFixed(1)}s</span>}
                </div>
              </div>
              {s.ui === 'supercell' && (
                <div className="flex gap-[2px]">
                  {['LP', 'N', 'HP'].map((l, k) => (
                    <button key={l} onClick={() => (g.supercellType = k)} className="text-[8px] font-orb px-1 border slot" style={{ borderColor: g.supercellType === k ? '#5ef2ff' : 'rgba(94,242,255,.2)', color: g.supercellType === k ? '#fff' : '#7d93a3', background: g.supercellType === k ? 'rgba(30,110,160,.6)' : 'rgba(3,12,22,.7)' }}>{l}</button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
      {it?.passive && <div className="mt-1.5 px-1 text-[10px] leading-tight text-cyan-100/55 border-t border-cyan-300/10 pt-1">PASSIVE · {it.passive}</div>}
    </div>
  );
}

/* ------------------------------------------------------------ inventory */
function Inventory({ g }: { g: Game }) {
  const fruits = g.items.map((it, i) => ({ it, i })).filter((x) => x.it.kind === 'fruit');
  const swords = g.items.map((it, i) => ({ it, i })).filter((x) => x.it.kind === 'sword');
  const Slot = ({ it, i }: { it: typeof g.items[number]; i: number }) => {
    const on = g.equipped === i;
    return (
      <button onClick={() => g.toggleEquip(i)} title={`${it.name} (${it.kind})`}
        className="relative slot w-[50px] h-[50px] sm:w-[56px] sm:h-[56px] flex flex-col items-center justify-center shrink-0 transition-all"
        style={{ background: on ? `linear-gradient(180deg, ${it.color}40, rgba(4,14,26,.9))` : 'rgba(4,14,26,.82)', border: `1px solid ${on ? it.color : 'rgba(94,242,255,.28)'}`, boxShadow: on ? `0 0 14px ${it.color}88, inset 0 0 10px ${it.color}55` : undefined, transform: on ? 'translateY(-4px)' : undefined }}>
        <span className="absolute top-0.5 left-1 font-orb text-[8px] text-cyan-200/60">{SLOT_KEYS[i]}</span>
        <span className="text-[20px] leading-none" style={{ color: it.color, textShadow: `0 0 8px ${it.color}` }}>{it.glyph}</span>
        <span className="text-[8.5px] font-orb mt-1 max-w-[48px] truncate" style={{ color: on ? '#fff' : '#9fb8c8' }}>{it.name.split(' ')[0].toUpperCase()}</span>
        {on && <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-[2px]" style={{ background: it.color, boxShadow: `0 0 6px ${it.color}` }} />}
      </button>
    );
  };
  return (
    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 pointer-events-auto flex items-end gap-2 max-w-[98vw] overflow-x-auto px-1 pt-2">
      <div className="flex flex-col items-center">
        <div className="font-orb text-[8px] tracking-[0.3em] text-cyan-300/70 mb-0.5">FRUITS</div>
        <div className="flex gap-1">{fruits.map((x) => <Slot key={x.it.id} {...x} />)}</div>
      </div>
      <div className="w-px h-12 bg-cyan-300/30 mb-1" />
      <div className="flex flex-col items-center">
        <div className="font-orb text-[8px] tracking-[0.3em] text-cyan-300/70 mb-0.5">SWORDS</div>
        <div className="flex gap-1">{swords.map((x) => <Slot key={x.it.id} {...x} />)}</div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ settings */
function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="flex items-center gap-3 py-1 border-b border-cyan-300/10"><div className="w-40 shrink-0 text-[12px] text-cyan-100/80">{label}</div><div className="flex-1 flex items-center gap-2">{children}</div></div>;
}
function Settings({ g, onClose }: { g: Game; onClose: () => void }) {
  const [s, setS] = useState<GraphicsSettings>({ ...g.settings });
  const upd = (p: Partial<GraphicsSettings>, custom = true) => { const n = { ...s, ...p, ...(custom ? { preset: 'custom' as const } : {}) }; setS(n); g.applySettings(n); localStorage.setItem('fruits1090.gfx', JSON.stringify(n)); };
  const slider = (k: keyof GraphicsSettings, min: number, max: number, step: number, unit = '') => (
    <><input className="sf-range" type="range" min={min} max={max} step={step} value={s[k] as number} onChange={(e) => upd({ [k]: parseFloat(e.target.value) } as any)} /><span className="font-orb text-[10px] w-14 text-right text-cyan-200">{(s[k] as number).toFixed(step < 1 ? 2 : 0)}{unit}</span></>
  );
  const toggle = (k: keyof GraphicsSettings) => (
    <button onClick={() => upd({ [k]: !s[k] } as any)} className="sf-btn text-[10px] px-3 py-1" style={{ background: s[k] ? 'linear-gradient(180deg, rgba(30,140,190,.9), rgba(10,60,95,.9))' : undefined }}>{s[k] ? 'ON' : 'OFF'}</button>
  );
  const [tab, setTab] = useState<'gfx' | 'game'>('gfx');
  return (
    <div className="absolute inset-0 bg-black/55 flex items-center justify-center pointer-events-auto z-30" onPointerDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sf-panel w-[min(640px,94vw)] max-h-[88vh] overflow-y-auto p-4 hex-grid-bg">
        <div className="flex items-center justify-between mb-3">
          <div className="font-orb text-sm tracking-[0.3em] text-cyan-200 sf-glow">SYSTEM CONFIGURATION</div>
          <button onClick={onClose} className="sf-btn px-3 py-1 text-xs">CLOSE</button>
        </div>
        <div className="flex gap-2 mb-3">
          {(['gfx', 'game'] as const).map((t) => <button key={t} onClick={() => setTab(t)} className="sf-btn px-3 py-1 text-[10px]" style={{ background: tab === t ? 'linear-gradient(180deg, rgba(30,140,190,.9), rgba(10,60,95,.9))' : undefined }}>{t === 'gfx' ? 'ADVANCED GRAPHICS' : 'GAMEPLAY'}</button>)}
        </div>
        {tab === 'gfx' ? (
          <div>
            <Row label="Quality Preset">
              {(['low', 'medium', 'high', 'ultra'] as const).map((p) => <button key={p} onClick={() => upd({ ...PRESETS[p], preset: p }, false)} className="sf-btn text-[10px] px-2 py-1" style={{ background: s.preset === p ? 'linear-gradient(180deg, rgba(30,140,190,.9), rgba(10,60,95,.9))' : undefined }}>{p.toUpperCase()}</button>)}
              {s.preset === 'custom' && <span className="font-orb text-[10px] text-amber-200">CUSTOM</span>}
            </Row>
            <Row label="Render Scale">{slider('renderScale', 0.4, 1.5, 0.05, 'x')}</Row>
            <Row label="Anti-Aliasing (MSAA)">{toggle('antialias')}</Row>
            <Row label="Shadows">{toggle('shadows')}
              <select value={s.shadowRes} onChange={(e) => upd({ shadowRes: parseInt(e.target.value) })} className="bg-[#061524] border border-cyan-300/40 text-cyan-100 text-[11px] px-1 py-0.5">{[512, 1024, 2048, 4096].map((r) => <option key={r} value={r}>{r}px</option>)}</select>
            </Row>
            <Row label="Bloom / Glow">{toggle('bloom')}{slider('bloomStrength', 0, 2, 0.05)}</Row>
            <Row label="Lightning Glow Layer">{toggle('boltGlow')}</Row>
            <Row label="Dynamic Light Flashes">{toggle('lightFlashes')}</Row>
            <Row label="Particle Density">{slider('particleDensity', 0.1, 2, 0.05, 'x')}</Row>
            <Row label="Debris Density">{slider('debrisDensity', 0, 2, 0.05, 'x')}</Row>
            <Row label="Atmospheric Fog">{toggle('fog')}</Row>
            <Row label="Draw Distance">{slider('drawDistance', 800, 12000, 100, 'm')}</Row>
            <Row label="Exposure">{slider('exposure', 0.5, 2, 0.05)}</Row>
            <Row label="Field of View">{slider('fov', 40, 100, 1, '°')}</Row>
            <Row label="Camera Shake (XYZ only)">{slider('shakeScale', 0, 2, 0.05, 'x')}</Row>
            <Row label="Show FPS">{toggle('showFps')}</Row>
          </div>
        ) : (
          <div>
            <Row label="Damage Numbers">{toggle('damageNumbers')}</Row>
            <Row label="Enemy Count">{slider('enemyCount', 0, 150, 1)}</Row>
            <Row label="Touch Controls">{(['auto', 'on', 'off'] as const).map((m) => <button key={m} onClick={() => upd({ touchControls: m })} className="sf-btn text-[10px] px-2 py-1" style={{ background: s.touchControls === m ? 'linear-gradient(180deg, rgba(30,140,190,.9), rgba(10,60,95,.9))' : undefined }}>{m.toUpperCase()}</button>)}</Row>
            <Row label="Enemy Spawning"><button onClick={() => { g.spawning = !g.spawning; setS({ ...s }); }} className="sf-btn text-[10px] px-3 py-1">{g.spawning ? 'ON' : 'OFF'}</button></Row>
            <Row label="Spawn Units">
              <button onClick={() => g.enemies.spawn('boss')} className="sf-btn text-[10px] px-2 py-1">BOSS</button>
              <button onClick={() => { for (let i = 0; i < 3; i++) g.enemies.spawn('elite'); }} className="sf-btn text-[10px] px-2 py-1">3 ELITES</button>
              <button onClick={() => { for (let i = 0; i < 20; i++) g.enemies.spawn('normal'); }} className="sf-btn text-[10px] px-2 py-1">+20</button>
              <button onClick={() => { [...g.enemies.list].forEach((e) => g.enemies.kill(e)); }} className="sf-btn text-[10px] px-2 py-1">CLEAR</button>
            </Row>
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ help */
function Help({ onClose }: { onClose: () => void }) {
  const rows: [string, string][] = [
    ['Move', 'WASD / Arrows · Left stick · Joystick'], ['Jump / Sprint', 'Space / Shift · A button'], ['Attack (M1)', 'Left click (guns: click each shot) · X button · ATK'],
    ['Skills', 'Z X C V B F G N M L K J · Mobile: USE · Pad: D-pad select + B/Y'], ['Equip slot', '1–9, 0, - · click slot · LB/RB'], ['Camera orbit', 'Right-drag · Q/E · Right stick · 1-finger drag'],
    ['Zoom (4–300m)', 'Wheel · Touchpad pinch · +/- PageUp/PageDown [ ] · LT/RT · D-pad L/R · 2-finger pinch · on-screen ±'], ['Panels', 'H: skill panel · Esc: settings'],
  ];
  return (
    <div className="absolute inset-0 bg-black/55 flex items-center justify-center pointer-events-auto z-30" onPointerDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sf-panel w-[min(560px,94vw)] p-4">
        <div className="font-orb text-sm tracking-[0.3em] text-cyan-200 sf-glow mb-3">CONTROL MATRIX</div>
        {rows.map(([a, b]) => <div key={a} className="flex gap-3 py-1 border-b border-cyan-300/10 text-[12px]"><div className="w-32 font-orb text-[10px] text-cyan-300 pt-0.5">{a.toUpperCase()}</div><div className="flex-1 text-cyan-50/85">{b}</div></div>)}
        <button onClick={onClose} className="sf-btn px-4 py-1 text-xs mt-3">ACKNOWLEDGE</button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ mobile */
function Joystick({ g }: { g: Game }) {
  const base = useRef<HTMLDivElement>(null); const [k, setK] = useState({ x: 0, y: 0 }); const id = useRef<number | null>(null);
  const move = (e: React.PointerEvent) => { const r = base.current!.getBoundingClientRect(); let x = (e.clientX - (r.left + r.width / 2)) / (r.width / 2), y = (e.clientY - (r.top + r.height / 2)) / (r.height / 2); const L = Math.hypot(x, y); if (L > 1) { x /= L; y /= L; } setK({ x, y }); g.joy.x = x; g.joy.y = -y; };
  const end = () => { id.current = null; setK({ x: 0, y: 0 }); g.joy.x = 0; g.joy.y = 0; };
  return (
    <div ref={base} className="absolute left-5 bottom-24 w-32 h-32 rounded-full pointer-events-auto border border-cyan-300/40" style={{ background: 'radial-gradient(circle, rgba(94,242,255,.12), rgba(4,14,26,.5))', touchAction: 'none' }}
      onPointerDown={(e) => { id.current = e.pointerId; (e.target as HTMLElement).setPointerCapture(e.pointerId); move(e); }} onPointerMove={(e) => id.current === e.pointerId && move(e)} onPointerUp={end} onPointerCancel={end}>
      <div className="absolute w-12 h-12 rounded-full border border-cyan-200 left-1/2 top-1/2" style={{ transform: `translate(calc(-50% + ${k.x * 40}px), calc(-50% + ${k.y * 40}px))`, background: 'rgba(94,242,255,.35)', boxShadow: '0 0 12px #5ef2ff' }} />
    </div>
  );
}

/* ------------------------------------------------------------ HUD */
export default function HUD({ g }: { g: Game }) {
  useTick(33);
  const [panel, setPanel] = useState(true); const [settings, setSettings] = useState(false); const [help, setHelp] = useState(false);
  useEffect(() => { g.onUi = (ev) => { if (ev === 'togglePanel') setPanel((p) => !p); if (ev === 'settings') setSettings((s) => !s); }; }, [g]);
  const P = g.player; const hpF = P.hp / P.maxHp;
  const buffs: [string, number, string][] = [['ALARM BUFFER', g.buffs.alarm - g.time, '#ff3347'], ['ICE BOMBARD', g.buffs.ice - g.time, '#8fe6ff'], ['HELL FURY', g.buffs.fire - g.time, '#ff6a14']];
  return (
    <div className="absolute inset-0 pointer-events-none select-none">
      {/* status */}
      <div className="absolute left-2 top-2 sf-panel px-3 py-2 w-[250px] max-w-[46vw]">
        <div className="flex items-center justify-between"><span className="font-orb text-[10px] tracking-[0.25em] text-cyan-200 sf-glow">OPERATOR</span><span className="font-orb text-[9px] text-cyan-300/60">1090 FRUITS</span></div>
        <div className="mt-1 h-3 slot relative overflow-hidden border border-cyan-300/30 bg-[#04101c]">
          <div className="absolute inset-y-0 left-0 transition-[width] duration-150" style={{ width: `${hpF * 100}%`, background: hpF > 0.5 ? 'linear-gradient(90deg,#1de9b6,#5ef2ff)' : hpF > 0.25 ? 'linear-gradient(90deg,#ffb300,#ffd84a)' : 'linear-gradient(90deg,#ff1744,#ff6070)' }} />
          <div className="absolute inset-0 flex items-center justify-center font-orb text-[8.5px] text-white">{Math.ceil(P.hp)} / {P.maxHp}</div>
        </div>
        {g.item?.id === 'gblade' && (
          <div className="mt-1 h-2 relative overflow-hidden bg-[#0c0618] border border-purple-400/40"><div className="absolute inset-y-0 left-0" style={{ width: `${g.bladeCharge}%`, background: 'linear-gradient(90deg,#5a12c8,#e7b6ff)' }} /><div className="absolute inset-0 text-center font-orb text-[7px] leading-[8px] text-white">LIGHTNING CHARGE {Math.round(g.bladeCharge)}%</div></div>
        )}
        {buffs.filter((b) => b[1] > 0).map(([n, t, c]) => <div key={n} className="mt-1 flex justify-between font-orb text-[9px]" style={{ color: c }}><span className="sf-pulse">▲ {n}</span><span>{t.toFixed(1)}s</span></div>)}
        {P.invT > 0 && <div className="mt-1 font-orb text-[9px] text-cyan-200 sf-pulse">◆ INVINCIBLE</div>}
      </div>
      {/* stats */}
      <div className="absolute right-2 top-2 flex items-start gap-2 pointer-events-auto">
        <div className="sf-panel px-3 py-1.5 font-orb text-[9.5px] leading-[15px] text-cyan-100/85 min-w-[130px]">
          {g.settings.showFps && <div className="flex justify-between"><span className="text-cyan-300/70">FPS</span><span style={{ color: g.fps > 50 ? '#5ef2ff' : g.fps > 30 ? '#ffd84a' : '#ff6070' }}>{g.fps}</span></div>}
          <div className="flex justify-between"><span className="text-cyan-300/70">HOSTILES</span><span>{g.enemies.list.length}</span></div>
          <div className="flex justify-between"><span className="text-cyan-300/70">KILLS</span><span>{g.kills}</span></div>
          <div className="flex justify-between gap-3"><span className="text-cyan-300/70">DAMAGE</span><span>{fmt(g.totalDmg)}</span></div>
        </div>
        <div className="flex flex-col gap-1">
          <button onClick={() => setSettings(true)} className="sf-btn w-9 h-9 text-base" title="Settings (Esc)">⚙</button>
          <button onClick={() => setHelp(true)} className="sf-btn w-9 h-9 text-sm" title="Controls">?</button>
        </div>
      </div>
      {/* zoom (PC / laptop / TV / mobile / console) */}
      <div className="absolute left-2 top-1/2 -translate-y-1/2 sf-panel p-1.5 flex flex-col items-center gap-1 pointer-events-auto w-[46px]">
        <button onClick={() => g.zoomBy(0.8)} className="sf-btn w-8 h-7 text-sm">＋</button>
        <input type="range" min={4} max={300} step={1} value={g.zoomTarget} onChange={(e) => g.setZoom(parseFloat(e.target.value))} className="sf-range" style={{ writingMode: 'vertical-lr' as any, direction: 'rtl', width: 16, height: 110 }} />
        <button onClick={() => g.zoomBy(1.25)} className="sf-btn w-8 h-7 text-sm">－</button>
        <div className="font-orb text-[8px] text-cyan-200 text-center leading-tight">{g.zoom.toFixed(0)}m<br /><span className="text-cyan-300/50">/300</span></div>
      </div>
      <SkillPanel g={g} open={panel} setOpen={setPanel} />
      <Inventory g={g} />
      {g.touchMode && (
        <>
          <Joystick g={g} />
          <div className="absolute right-4 bottom-24 flex flex-col gap-2 items-end pointer-events-auto">
            <button onPointerDown={() => { g.m1Held = true; g.m1Queued = true; }} onPointerUp={() => (g.m1Held = false)} onPointerLeave={() => (g.m1Held = false)} className="sf-btn w-20 h-20 rounded-full text-xs font-bold" style={{ clipPath: 'none', borderRadius: 999 }}>ATK</button>
            <button onPointerDown={() => g.jump()} className="sf-btn w-14 h-14 text-[10px]" style={{ clipPath: 'none', borderRadius: 999 }}>JUMP</button>
          </div>
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 border border-cyan-200/70 rounded-full" style={{ boxShadow: '0 0 8px #5ef2ff' }} />
        </>
      )}
      {P.deadT > 0 && <div className="absolute inset-0 flex items-center justify-center"><div className="sf-panel px-8 py-4 font-orb text-xl tracking-[0.4em] text-red-300 sf-pulse">SYSTEM REBOOT</div></div>}
      {g.worldPause > 0 && <div className="absolute top-20 left-1/2 -translate-x-1/2 font-orb text-red-200 tracking-[0.6em] text-sm sf-pulse">— FATAL DESTRUCTION —</div>}
      {settings && <Settings g={g} onClose={() => setSettings(false)} />}
      {help && <Help onClose={() => setHelp(false)} />}
    </div>
  );
}
